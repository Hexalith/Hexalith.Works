using Hexalith.EventStore.Client.Streams;
ThreadPool.SetMinThreads(100,100);
var release = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
var callbacks = new List<TaskCompletionSource>();
int accepted=0;
try
{
    for (int i=0;i<20;i++)
    {
        var pending=new TaskCompletionSource<int>(TaskCreationOptions.RunContinuationsAsynchronously);
        var callbackEntered=new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var callbackDone=new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        callbacks.Add(callbackDone);
        using var deadline=new AuthoritativeStreamReadDeadline(TimeSpan.FromMilliseconds(100),TimeProvider.System,CancellationToken.None,TimeProvider.System.GetTimestamp());
        try
        {
            await deadline.ReadWithAdmissionAsync(token=>
            {
                Interlocked.Increment(ref accepted);
                token.Register(()=>
                {
                    pending.TrySetCanceled(token);
                    callbackEntered.TrySetResult();
                    release.Task.GetAwaiter().GetResult();
                    callbackDone.TrySetResult();
                });
                return pending.Task;
            });
        }
        catch(OperationCanceledException) {}
        await callbackEntered.Task.WaitAsync(TimeSpan.FromSeconds(3));
        await Task.Delay(20);
    }
    Console.WriteLine($"accepted={accepted}, callbacks still blocked={callbacks.Count(x=>!x.Task.IsCompleted)}, expected provider capacity=16");
}
finally
{
    release.TrySetResult();
    await Task.WhenAll(callbacks.Select(x=>x.Task)).WaitAsync(TimeSpan.FromSeconds(5));
}
