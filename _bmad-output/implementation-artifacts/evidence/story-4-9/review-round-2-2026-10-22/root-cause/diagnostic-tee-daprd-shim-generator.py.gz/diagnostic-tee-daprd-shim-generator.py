"""Create a diagnostic isolated daprd runtime: same Sentry translation, but tees daprd output (debug level) to per-app logs."""
import hashlib, json, sys
from pathlib import Path

base = Path(__file__).with_name("shim_base.py").read_text()
marker = 'if __name__ == "__main__":'
assert base.count(marker) == 1
tail = r'''
def _tee_executor(runtime, argv):
    import signal, time
    arguments = list(argv[1:])
    if "--log-level" in arguments:
        arguments[arguments.index("--log-level") + 1] = "debug"
    else:
        arguments += ["--log-level", "debug"]
    app = arguments[arguments.index("--app-id") + 1] if "--app-id" in arguments else "unknown"
    logs = Path(__file__).resolve().parents[2] / "logs"
    logs.mkdir(exist_ok=True)
    log = (logs / (app + "-" + str(os.getpid()) + ".log")).open("ab", buffering=0)
    log.write(("ARGS " + json.dumps(arguments) + "\n").encode())
    read, write = os.pipe()
    child = os.fork()
    if child == 0:
        os.dup2(write, 1); os.dup2(write, 2); os.close(read); os.close(write)
        os.execv(runtime, [runtime, *arguments])
    os.close(write)
    def forward(signum, frame):
        try: os.kill(child, signum)
        except ProcessLookupError: pass
    for s in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):
        signal.signal(s, forward)
    with os.fdopen(read, "rb", buffering=0) as stream:
        while True:
            try:
                chunk = stream.read(65536)
            except InterruptedError:
                continue
            if not chunk: break
            log.write(chunk)
            try: os.write(1, chunk)
            except OSError: pass
    _, status = os.waitpid(child, 0)
    sys.exit(os.waitstatus_to_exitcode(status) if hasattr(os, "waitstatus_to_exitcode") else 1)

'''
main = '''if __name__ == "__main__":
    try:
        execute(Path(__file__).resolve().parents[2], sys.argv[1:], executor=_tee_executor)
    except (OSError, ValueError, KeyError, TypeError) as error:
        print("Isolated daprd refused: " + str(error), file=sys.stderr)
        sys.exit(1)
'''
source = base[:base.index(marker)] + tail + main
directory, runtime, port = Path(sys.argv[1]), Path(sys.argv[2]).resolve(strict=True), int(sys.argv[3])
directory.mkdir(parents=True, exist_ok=False)
shim = directory / ".dapr/bin/daprd"
shim.parent.mkdir(parents=True)
shim.write_text(source)
shim.chmod(0o700)
digest = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
binding = {"runtime": str(runtime), "runtimeSha256": digest(runtime), "shimSha256": digest(shim), "sentryAddress": "127.0.0.1:" + str(port)}
(directory / "binding.json").write_text(json.dumps(binding, indent=2) + "\n")
print(json.dumps(binding))
