#!/usr/bin/env bash
# usage: redis_watch.sh OUTDIR DURATION_SECONDS ; attaches to newly created works-sdk415-* Redis fixtures
out="$1"; duration="$2"; mkdir -p "$out"; end=$(( $(date +%s) + duration )); seen=""
while [ "$(date +%s)" -lt "$end" ]; do
  for name in $(docker ps --filter "name=works-sdk415-" --format '{{.Names}}' 2>/dev/null); do
    case " $seen " in *" $name "*) ;; *)
      seen="$seen $name"
      ( docker exec "$name" redis-cli MONITOR > "$out/$name.monitor" 2>&1 & )
      ( while docker ps --filter "name=$name" -q | grep -q .; do
          { date -u +%FT%T.%3NZ; docker exec "$name" redis-cli INFO errorstats; docker exec "$name" redis-cli INFO memory | grep -E "used_memory_human|maxmemory"; docker exec "$name" redis-cli INFO commandstats | grep -E "failed_calls=[1-9]|rejected_calls=[1-9]"; docker exec "$name" redis-cli CONFIG GET maxmemory; docker exec "$name" redis-cli CONFIG GET proto-max-bulk-len; } >> "$out/$name.info" 2>&1
          sleep 2; done ) &
      docker logs -f "$name" > "$out/$name.docker.log" 2>&1 &
    ;; esac
  done
  sleep 1
done
