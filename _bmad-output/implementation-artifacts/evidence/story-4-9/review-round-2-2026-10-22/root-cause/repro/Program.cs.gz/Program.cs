using System.Diagnostics;
using Dapr.Client;
using Hexalith.EventStore.Client.Projections;
using Microsoft.Extensions.Options;

// usage: Repro <daprGrpcPort> <retainManifestForRecovery:true|false> <batches>
string grpc = args[0];
bool retain = bool.Parse(args[1]);
int batches = int.Parse(args[2]);
string run = Guid.NewGuid().ToString("N")[..8];
using DaprClient client = new DaprClientBuilder().UseGrpcEndpoint("http://127.0.0.1:" + grpc).Build();
var store = new DaprReadModelStore(client, Options.Create(new ReadModelBatchOptions()));
string sdk = typeof(DaprReadModelStore).Assembly.GetName().Version!.ToString();
for (int i = 0; i < batches; i++)
{
    var scope = new ReadModelBatchScope("statestore", "tenant-repro", "work", "repro-family", "repro-family", $"batch-{run}-{i}");
    var batch = new ReadModelBatch(scope,
    [
        ReadModelBatchOperation.Write($"repro:{run}:{i}:a", new Doc("a", i), ReadModelBatchConcurrency.CreateOnly),
        ReadModelBatchOperation.Write($"repro:{run}:{i}:b", new Doc("b", i), ReadModelBatchConcurrency.CreateOnly),
    ]) { RetainManifestForRecovery = retain };
    var watch = Stopwatch.StartNew();
    ReadModelBatchResult result = await store.ExecuteAsync(batch, CancellationToken.None);
    Console.WriteLine($"sdk={sdk} retain={retain} batch={i} status={result.Status} result={result} elapsedMs={watch.ElapsedMilliseconds}");
}

internal sealed record Doc(string Name, int Index);
