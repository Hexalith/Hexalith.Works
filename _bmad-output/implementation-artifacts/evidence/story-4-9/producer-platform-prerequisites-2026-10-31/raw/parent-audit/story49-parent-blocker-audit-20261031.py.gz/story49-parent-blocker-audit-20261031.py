"""Read-only audit of the recorded Story 4.9 prerequisite failures."""
from pathlib import Path
import collections
import gzip
import hashlib
import json
import re
import subprocess
import xml.etree.ElementTree as ET

LIVE = Path('/home/administrator/projects/hexalith/works')
RUN = Path('/tmp/story49-qualification-20261031-pMAQI0/source-qualified-3-129')
WORKS = RUN / 'baseline/works'
SDK = WORKS / 'references/Hexalith.EventStore'
PLATFORM = LIVE / 'references/Hexalith.Platform'
OUTPUT = Path('/tmp/story49-parent-blocker-audit-20261031.json')

def require(value, message):
    if not value:
        raise ValueError(message)

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def revision(root):
    return subprocess.check_output(['git', '-C', str(root), 'rev-parse', 'HEAD'], text=True).strip()

def bound(path):
    raw = path.read_bytes()
    return {'path': str(path), 'sha256': sha(raw), 'bytes': len(raw)}

report = {'status': 'audit-incomplete', 'scope': 'Selected disposable source graph; current Platform source inspected only for missing-prerequisite trace. No current live workspace, parity, rollback, hosted CI or production acceptance.'}
try:
    report['worksRevision'] = revision(WORKS)
    report['sdkRevision'] = revision(SDK)
    report['currentPlatformTraceRevision'] = revision(PLATFORM)
    require(report['sdkRevision'] == 'c02afa0fce310ccdb696232f18829df96cba088e', 'Unexpected selected SDK producer')
    expected = {
        'Hexalith.Works.UnitTests.xml': {'Pass': 597},
        'Hexalith.Works.PropertyTests.xml': {'Pass': 3},
        'Hexalith.Works.ArchitectureTests-owned-layout.xml': {'Pass': 404},
        'Hexalith.Works.IntegrationTests-owned-layout.xml': {'Pass': 1089, 'Fail': 71, 'NotRun': 7},
    }
    report['executedXml'] = {}
    for name, counts in expected.items():
        path = RUN / name
        tests = list(ET.parse(path).getroot().iter('test'))
        actual = dict(collections.Counter(test.get('result') for test in tests))
        require(actual == counts, 'Unexpected XML results: ' + name)
        item = bound(path) | {'counts': actual}
        if 'IntegrationTests' in name:
            failures = dict(collections.Counter(test.get('type') for test in tests if test.get('result') == 'Fail'))
            require(failures == {'Hexalith.Works.IntegrationTests.WorksSdkEndpointCancellationTests': 11, 'Hexalith.Works.IntegrationTests.WorksSdkProtectedHttpTests': 59, 'Hexalith.Works.IntegrationTests.WorksPlatformFleetRestoreTests': 1}, 'Unexpected integration failure partition')
            item['failureClasses'] = failures
            item['notRunMethods'] = [test.get('method') for test in tests if test.get('result') == 'NotRun']
        report['executedXml'][name] = item
    service = SDK / 'src/Hexalith.EventStore.DomainService'
    routing = SDK / 'src/Hexalith.EventStore.ServiceDefaults/Routing'
    guard = service / 'DomainRouteCatalogGuard.cs'
    authority = routing / 'RouteCatalogAuthority.cs'
    filter_path = service / 'DomainRouteCatalogFilter.cs'
    bootstrap = PLATFORM / 'src/Hexalith.Platform.Composition/PlatformRoutingCatalogBootstrap.cs'
    entry = PLATFORM / 'src/Hexalith.Platform.Composition/PlatformAppModel.cs'
    preview = PLATFORM / 'src/Hexalith.Platform.Composition/WorksPreviewModel.cs'
    require('An independently bound local catalog host identity and profile are required.' in authority.read_text(), 'Missing exact authority refusal')
    require('await authority.AcquireAsync(context.HttpContext.RequestAborted)' in guard.read_text(), 'Missing mandatory guard authority acquisition')
    require('WorksProcessDispositionRequest' not in guard.read_text(), 'Disposition request is now admitted; reassess blocker')
    require('Results.StatusCode(503)' in filter_path.read_text(), 'Missing refusal transport binding')
    require('if (options.Mapping.Mode != WorkspaceMode.Source)' in bootstrap.read_text(), 'Package mode refusal changed; reassess blocker')
    require('Run-scoped catalog package/CI composition is unavailable until the EventStore owner SDK and adapters ship and the Builds catalog pins are updated.' in bootstrap.read_text(), 'Missing exact package prerequisite refusal')
    require('if (works) WorksPreviewModel.Compose(builder);' in entry.read_text(), 'Works composition selection changed')
    require('PlatformRoutingCatalogBootstrap' not in preview.read_text(), 'Works bootstrap changed; reassess enrollment blocker')
    report['sourceTrace'] = [bound(path) for path in (guard, authority, filter_path, bootstrap, entry, preview)]
    packet = LIVE / '_bmad-output/implementation-artifacts/evidence/story-4-9/prerequisite-2026-10-31'
    manifest_path = packet / 'manifest.json'
    manifest = json.loads(manifest_path.read_text())
    for item in manifest['files']:
        path = packet / item['path']
        stored = path.read_bytes()
        decoded = gzip.decompress(stored) if path.suffix == '.gz' else stored
        require(sha(stored) == item['sha256'], 'Stored packet digest mismatch: ' + item['path'])
        require(sha(decoded) == item['nativeSha256'] and len(decoded) == item['nativeBytes'], 'Decoded packet binding mismatch: ' + item['path'])
        require(Path(item['nativePath']).read_bytes() == decoded, 'Native packet bytes changed: ' + item['path'])
    report['prerequisitePacket'] = bound(manifest_path) | {'verifiedRecords': len(manifest['files'])}
    spec_path = '_bmad-output/implementation-artifacts/spec-4-9-migrate-works-hosting-to-the-platform-boundary.md'
    original = subprocess.check_output(['git', '-C', str(LIVE), 'show', '038f49080a86d312b30d12567f521c3954593569:' + spec_path])
    current = (LIVE / spec_path).read_bytes()
    block = rb'<frozen-after-approval\b[^>]*>.*?</frozen-after-approval>'
    original_block = re.search(block, original, re.S).group(0)
    current_block = re.search(block, current, re.S).group(0)
    require(original_block == current_block, 'Frozen intent changed')
    report['frozenIntent'] = {'unchangedFrom': '038f49080a86d312b30d12567f521c3954593569', 'sha256': sha(current_block)}
    report['status'] = 'blocked-preconditions-confirmed'
except Exception as error:
    report['status'] = 'audit-failed'
    report['error'] = str(error)
    raise
finally:
    OUTPUT.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'status': report['status'], 'output': str(OUTPUT), 'error': report.get('error')}))
