import subprocess,os,json,datetime,sys,hashlib,configparser
from pathlib import Path
ROOT=Path('/tmp/story49-qualification-20261031-pMAQI0/source-qualified-3-129');WORKS=ROOT/'baseline/works';records=[]
buildenv=os.environ.copy()|{'HexalithBuildsRoot':str(WORKS/'references/Hexalith.Builds'),'DOTNET_USE_POLLING_FILE_WATCHER':'1'};testenv={k:v for k,v in buildenv.items() if not k.startswith('Hexalith')}
def run(name,args,env=buildenv):
 print(name,flush=True);r={'name':name,'command':args,'cwd':str(WORKS),'startedAt':datetime.datetime.now(datetime.UTC).isoformat()}
 with (ROOT/(name+'.log')).open('w') as log:child=subprocess.run(args,cwd=WORKS,env=env,stdout=log,stderr=subprocess.STDOUT)
 r|={'exitCode':child.returncode,'finishedAt':datetime.datetime.now(datetime.UTC).isoformat()};records.append(r);(ROOT/'settled-commands.json').write_text(json.dumps(records,indent=2)+'\n')
 if child.returncode:sys.exit(child.returncode)
run('script-controls',['python3','-m','unittest','discover','-s','scripts/tests'])
art=ROOT/'default-debug-after-catalog'
run('debug-solution-restore',['dotnet','restore','Hexalith.Works.slnx','-p:Configuration=Debug','-p:UseHexalithProjectReferences=true','--artifacts-path',str(art),'-m:1'])
run('debug-solution-build',['dotnet','build','Hexalith.Works.slnx','--configuration','Debug','--no-restore','-p:UseHexalithProjectReferences=true','--artifacts-path',str(art),'-m','-v:minimal'])
run('default-assets-restore',['dotnet','restore','Hexalith.Works.slnx','-p:Configuration=Debug','-p:UseHexalithProjectReferences=true','-m:1'])
for project in ['Hexalith.Works.UnitTests','Hexalith.Works.PropertyTests','Hexalith.Works.ArchitectureTests','Hexalith.Works.IntegrationTests']:
 run(project,[str(art/'bin'/project/'debug'/project),'-noLogo','-result-xml',str(ROOT/(project+'.xml'))],env=testenv)
config=configparser.ConfigParser();config.read(WORKS/'.gitmodules');owners={'Works':WORKS}|{Path(config[s]['path']).name:WORKS/config[s]['path'] for s in config.sections()}
def git(repo,*args):return subprocess.check_output(['git','-C',str(repo),*args])
def inventory(repo):return {name:hashlib.sha256((repo/name).read_bytes()).hexdigest() for name in git(repo,'ls-files','-z').decode().split('\0') if name and not name.startswith('references/') and (repo/name).is_file()}
capture={'scope':'Source-compatible preserved story baseline; official SDK checkout 3.129.0 c02afa0fce310ccdb696232f18829df96cba088e and matching gitlink/manifest/markers; bounded Parties older/current-catalog fallback prerequisite; local fixture commit only. Does not qualify concurrent live workspace.','owners':{name:{'root':str(repo),'commit':git(repo,'rev-parse','HEAD').decode().strip(),'sourceFiles':inventory(repo),'workingPatch':git(repo,'diff','HEAD','--','.',' :(exclude)references').decode(errors='replace') if name=='Hexalith.Parties' else ''} for name,repo in owners.items()}}
(ROOT/'capture.json').write_text(json.dumps(capture,indent=2)+'\n');print('capture-sha256 '+hashlib.sha256((ROOT/'capture.json').read_bytes()).hexdigest(),flush=True)
print('full-and-ci-driver-started',flush=True);sys.exit(subprocess.run(['python3',str(ROOT/'qualify.py')],env=buildenv).returncode)
