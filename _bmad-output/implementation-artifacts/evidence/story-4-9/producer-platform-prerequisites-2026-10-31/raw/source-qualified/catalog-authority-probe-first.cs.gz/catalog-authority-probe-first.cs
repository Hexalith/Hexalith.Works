using System.Text.Json;
using Hexalith.EventStore.ServiceDefaults.Routing;
using Hexalith.Works.Runtime;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
await using var app = WorksHost.Build(["--environment=Development", "--Logging:LogLevel:Default=Error", "--Works:Query:PartiesGatewayBaseAddress=http://127.0.0.1:8999", "--EventStore:DomainService:AppId=works-sdk"]);
var options = app.Services.GetRequiredService<IOptions<RouteCatalogHostOptions>>().Value;
Console.WriteLine(JsonSerializer.Serialize(new { identityConfigured = options.Identity is not null, profile = options.Profile, stateStore = options.StateStore }));
try
{
    await using var lease = await app.Services.GetRequiredService<IRouteCatalogAuthority>().AcquireAsync();
    Console.WriteLine("Unexpected authority admission.");
    return 1;
}
catch (RouteCatalogUnavailableException exception)
{
    Console.WriteLine(JsonSerializer.Serialize(new { exception = exception.GetType().FullName, exception.Message, category = exception.Category.ToString() }));
    return exception.Category == RouteCatalogRefusalReason.Configuration && exception.Message == "An independently bound local catalog host identity and profile are required." ? 0 : 2;
}
