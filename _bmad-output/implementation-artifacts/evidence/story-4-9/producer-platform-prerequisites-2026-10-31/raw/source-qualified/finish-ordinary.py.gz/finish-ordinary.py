from pathlib import Path
import subprocess,os,json,sys,datetime
ROOT=Path('/tmp/story49-qualification-20261031-pMAQI0/source-qualified-3-129');WORKS=ROOT/'baseline/works';env={k:v for k,v in os.environ.items() if not k.startswith('Hexalith')};env['DOTNET_USE_POLLING_FILE_WATCHER']='1';records=[]
for project in ['Hexalith.Works.ArchitectureTests','Hexalith.Works.IntegrationTests']:
 command=[str(WORKS/'.artifacts/ordinary-qualification'/project/project),'-noLogo','-result-xml',str(ROOT/(project+'-owned-layout.xml'))];record={'project':project,'command':command,'cwd':str(WORKS),'startedAt':datetime.datetime.now(datetime.UTC).isoformat()}
 print(project,flush=True)
 with (ROOT/(project+'-owned-layout.log')).open('w') as log:child=subprocess.run(command,cwd=WORKS,env=env,stdout=log,stderr=subprocess.STDOUT)
 record|={'exitCode':child.returncode,'finishedAt':datetime.datetime.now(datetime.UTC).isoformat()};records.append(record);(ROOT/'ordinary-owned-layout-commands.json').write_text(json.dumps(records,indent=2)+'\n')
 if child.returncode:sys.exit(child.returncode)
