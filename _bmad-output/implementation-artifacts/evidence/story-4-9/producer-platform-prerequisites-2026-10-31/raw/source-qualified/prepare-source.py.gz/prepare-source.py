import subprocess,os,json,datetime,sys,hashlib,configparser
from pathlib import Path
ROOT=Path('/tmp/story49-qualification-20261031-pMAQI0/source-qualified-3-129');WORKS=ROOT/'baseline/works';records=[]
env=os.environ.copy()|{'HexalithBuildsRoot':str(WORKS/'references/Hexalith.Builds'),'DOTNET_USE_POLLING_FILE_WATCHER':'1'}
def run(name,args,required=True):
 print(name,flush=True);r={'name':name,'command':args,'cwd':str(WORKS),'startedAt':datetime.datetime.now(datetime.UTC).isoformat()}
 with (ROOT/(name+'.log')).open('w') as log:child=subprocess.run(args,cwd=WORKS,env=env,stdout=log,stderr=subprocess.STDOUT)
 r|={'exitCode':child.returncode,'finishedAt':datetime.datetime.now(datetime.UTC).isoformat()};records.append(r);(ROOT/'preparation-commands.json').write_text(json.dumps(records,indent=2)+'\n')
 if required and child.returncode:sys.exit(child.returncode)
 return child.returncode
run('fixture-status',['git','status','--short','--branch'])
run('fixture-remotes',['git','remote','-v'])
run('fixture-history',['git','log','--oneline','--max-count=8'])
run('npm-ci',['npm','ci','--ignore-scripts'])
run('fixture-commitlint',['node',str(WORKS/'node_modules/@commitlint/cli/cli.js'),'--edit',str(ROOT/'fixture-commit-message.txt')])
paths=['Directory.Build.props','Directory.Packages.props','tests/Hexalith.Works.IntegrationTests/Hexalith.Works.IntegrationTests.csproj','tools/source-debug-dependencies.json','docs/boundary-decision-record.md','docs/eventstore-api-surface-constraints.md','references/Hexalith.EventStore','references/Hexalith.Builds']
run('fixture-stage',['git','add','--',*paths])
run('fixture-commit',['git','commit','--file',str(ROOT/'fixture-commit-message.txt')])
run('fixture-final-status',['git','status','--short','--branch'])
run('source-preflight',['python3','scripts/verify-source-debug.py','--check-only','--artifacts-path',str(ROOT/'source-preflight')])
run('default-debug-consumer',['dotnet','build','tests/Hexalith.Works.IntegrationTests/Hexalith.Works.IntegrationTests.csproj','--configuration','Debug','-p:UseHexalithProjectReferences=true','--artifacts-path',str(ROOT/'default-debug'),'-m:1','-v:minimal'])
run('script-controls',['python3','-m','unittest','discover','-s','scripts/tests'])
config=configparser.ConfigParser();config.read(WORKS/'.gitmodules');owners={'Works':WORKS}|{Path(config[s]['path']).name:WORKS/config[s]['path'] for s in config.sections()}
def git(repo,*args):return subprocess.check_output(['git','-C',str(repo),*args])
def inventory(repo):return {name:hashlib.sha256((repo/name).read_bytes()).hexdigest() for name in git(repo,'ls-files','-z').decode().split('\0') if name and not name.startswith('references/') and (repo/name).is_file()}
capture={'scope':'Actually compatible default source graph: disposable fixture commit only; official SDK 3.129.0 c02afa0fce310ccdb696232f18829df96cba088e; two source-pair release versions, SDK source revision/gitlink and current markers bound. Live evolving workspace is outside qualification.','owners':{name:{'root':str(repo),'commit':git(repo,'rev-parse','HEAD').decode().strip(),'sourceFiles':inventory(repo)} for name,repo in owners.items()}}
(ROOT/'capture.json').write_text(json.dumps(capture,indent=2)+'\n');print('capture-sha256 '+hashlib.sha256((ROOT/'capture.json').read_bytes()).hexdigest(),flush=True)
print('full-and-ci-driver-started',flush=True);sys.exit(subprocess.run(['python3',str(ROOT/'qualify.py')],env=env).returncode)
