import datetime,hashlib,importlib.util,json,os,subprocess,sys
from pathlib import Path
ROOT=Path('/tmp/story49-qualification-20261031-pMAQI0/source-qualified-3-129')
WORKS=ROOT/'baseline/works'
spec=importlib.util.spec_from_file_location('story49_coordinator',WORKS/'scripts/verify-platform-parity-ci.py')
coordinator=importlib.util.module_from_spec(spec);spec.loader.exec_module(coordinator)
command,environment,record,snapshot=coordinator.bootstrap(WORKS,ROOT/'full')
command[command.index('--profile')+1]='full'
environment.pop('GH_TOKEN',None)
if not environment.get('GITHUB_TOKEN'):
 token=subprocess.run(['gh','auth','token'],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,text=True,timeout=10)
 if token.returncode==0:environment['GITHUB_TOKEN']=token.stdout.strip()
summary={'scope':'Preserved committed story baseline plus source-compatible 3.129.0 pin/source-pair/marker inputs with a local disposable fixture commit; does not qualify concurrent live workspace','startedAt':datetime.datetime.now(datetime.UTC).isoformat(),'fullCommand':command,'fullEnvironmentPins':{k:environment[k] for k in environment if k.startswith('Hexalith') or k=='DOTNET_USE_POLLING_FILE_WATCHER'},'producerReadTokenPresent':bool(environment.get('GITHUB_TOKEN'))}
(ROOT/'invocation.json').write_text(json.dumps(summary,indent=2)+'\n')
print('full-started '+str(ROOT/'full-driver.log'),flush=True)
with (ROOT/'full-driver.log').open('w') as log:result=subprocess.run(command,cwd=WORKS,env=environment,stdout=log,stderr=subprocess.STDOUT)
summary['fullExitCode']=result.returncode
if result.returncode==0:
 coordinator.require_unchanged_coordinators(record['coordinatorSha256'])
 if snapshot.origin_files(Path(record['platformOrigin']))!=record['platformSourceFiles']:raise RuntimeError('Platform source drift before actual CI')
 ci=['bash',str(WORKS/'scripts/verify-platform-parity-ci.sh'),'--artifacts-path',str(ROOT/'ci')]
 summary['ciCommand']=ci
 print('ci-started '+str(ROOT/'ci-driver.log'),flush=True)
 with (ROOT/'ci-driver.log').open('w') as log:ciresult=subprocess.run(ci,cwd=WORKS,env=environment,stdout=log,stderr=subprocess.STDOUT)
 summary['ciExitCode']=ciresult.returncode
summary['finishedAt']=datetime.datetime.now(datetime.UTC).isoformat()
summary['status']='full-and-actual-ci-passed' if summary.get('ciExitCode')==0 else 'nonqualifying; complete current gate not established'
(ROOT/'qualification-result.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary),flush=True)
sys.exit(summary.get('ciExitCode',result.returncode))
