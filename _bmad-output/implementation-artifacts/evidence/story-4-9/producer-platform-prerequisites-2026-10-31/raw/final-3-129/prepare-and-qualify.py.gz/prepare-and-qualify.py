import subprocess,os,json,datetime,sys
from pathlib import Path
ROOT=Path('/tmp/story49-qualification-20261031-pMAQI0/final-3-129');WORKS=ROOT/'baseline/works';records=[]
env=os.environ.copy()|{'HexalithBuildsRoot':str(WORKS/'references/Hexalith.Builds'),'DOTNET_USE_POLLING_FILE_WATCHER':'1'}
def run(name,args):
 print(name,flush=True);r={'name':name,'command':args,'cwd':str(WORKS),'startedAt':datetime.datetime.now(datetime.UTC).isoformat()}
 with (ROOT/(name+'.log')).open('w') as log:child=subprocess.run(args,cwd=WORKS,env=env,stdout=log,stderr=subprocess.STDOUT)
 r|={'exitCode':child.returncode,'finishedAt':datetime.datetime.now(datetime.UTC).isoformat()};records.append(r);(ROOT/'preparation-commands.json').write_text(json.dumps(records,indent=2)+'\n');return child.returncode
if run('npm-ci',['npm','ci','--ignore-scripts'])!=0:sys.exit(1)
if run('script-controls',['python3','-m','unittest','discover','-s','scripts/tests'])!=0:sys.exit(1)
print('full-and-ci-driver-started',flush=True)
sys.exit(subprocess.run(['python3',str(ROOT/'qualify.py')],env=env).returncode)
