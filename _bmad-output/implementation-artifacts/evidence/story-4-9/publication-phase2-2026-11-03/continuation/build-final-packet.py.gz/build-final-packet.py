"""Preserve bounded diagnostic evidence after both canonical gates and independent audits pass."""
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import shutil

base = Path('/tmp/story49-qualification-20261103-pga3llo6')
works = Path('/home/administrator/projects/hexalith/works')
state = json.loads((base / 'state.json').read_text())
full = Path(state['fullArtifacts'])
ci = Path(state['ciArtifacts'])
for root in (full, ci):
    ledger = json.loads((root / 'gate/ledger.json').read_text())
    if ledger['status'] != 'passed-disposable-synthetic-parity-and-rollback':
        raise ValueError('Canonical qualification remains incomplete: ' + str(root))
    audit = json.loads((root / 'parent-audit.json').read_text())
    if audit['status'] != 'passed':
        raise ValueError('Independent audit remains incomplete: ' + str(root))

packet = works / '_bmad-output/implementation-artifacts/evidence/story-4-9/published-qualification-2026-11-03'
packet.mkdir()
records = []


def keep(source, relative):
    source = Path(source)
    data = source.read_bytes()
    target = packet / (relative + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    stored = gzip.compress(data, mtime=0)
    target.write_bytes(stored)
    records.append({'path': target.relative_to(packet).as_posix(),
                    'sha256': hashlib.sha256(stored).hexdigest(),
                    'nativePath': str(source),
                    'nativeSha256': hashlib.sha256(data).hexdigest(),
                    'nativeBytes': len(data)})


suffixes = {'.json', '.jsonl', '.xml', '.trx', '.log', '.txt', '.md', '.py', '.diff', '.patch', '.stdout', '.stderr'}
for path in sorted(base.iterdir()):
    if path.is_file() and path.suffix in suffixes and path.name not in {'README-draft.md', 'README-final.md'}:
        keep(path, 'continuation/' + path.name)
for path in sorted((base / 'merge-steering').rglob('*')):
    if path.is_file() and path.suffix in suffixes:
        keep(path, 'merge-steering/' + path.relative_to(base / 'merge-steering').as_posix())
for name in ('platform-merge-tuple-artifact', 'platform-merge-catalog-artifacts'):
    root = base / name
    for path in sorted(root.rglob('*')):
        relative = path.relative_to(root)
        if path.is_file() and path.suffix in suffixes and not {'published', 'assets'}.intersection(relative.parts):
            keep(path, name + '/' + relative.as_posix())

source_root = works / '.artifacts/story49-published-source-20261103/solution'
for path in sorted(source_root.iterdir()):
    if path.is_file() and path.suffix in {'.json', '.log'}:
        keep(path, 'ordinary-source-gate/' + path.name)
for name in ('preflight', 'final', 'recorded'):
    root = works / ('.artifacts/story49-published-pair-' + name + '-20261103')
    for path in sorted(root.iterdir()):
        if path.is_file() and path.suffix in {'.json', '.log'}:
            keep(path, 'original-source-pair-' + name + '/' + path.name)

roots = [('full-attempt1-refused', Path('/tmp/story49-published-full-20261103-jz15ssts/full')),
         ('full', full), ('actual-ci', ci)]
for label, root in roots:
    for path in sorted(root.iterdir()):
        if path.is_file() and path.suffix in suffixes:
            keep(path, label + '/' + path.name)
    for name in ('invocation.json', 'command-outcome.json'):
        path = root.parent / name
        if path.is_file():
            keep(path, label + '/' + name)
    gate = root / 'gate'
    for path in sorted(gate.iterdir()):
        if path.is_file() and path.suffix in suffixes:
            keep(path, label + '/gate/' + path.name)
    # Keep launch-binding receipts and logs, never keys, runtime binaries or private fleet snapshots.
    for runtime in sorted(gate.glob('isolated-daprd*')):
        if runtime.is_dir():
            for path in sorted(runtime.iterdir()):
                if path.is_file() and path.suffix in {'.json', '.jsonl', '.log'}:
                    keep(path, label + '/gate/' + runtime.name + '/' + path.name)

tool = Path((base / 'final-tool-root.txt').read_text().strip())
receipt = tool.parents[3] / 'artifact-identity.json'
if not receipt.is_file():
    raise ValueError('Expected exact published-tool identity receipt is missing: ' + str(receipt))
keep(receipt, 'published-tool/artifact-identity.json')
shutil.copyfile(base / 'README-final.md', packet / 'README.md')
manifest = {'status': 'passed-disposable-synthetic-parity-and-rollback',
            'createdAtUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'scope': 'published owner adoption, ordinary source suites, fresh full and actual shipped CI entry point; no hosted Works run or production admission',
            'files': records,
            'plainFiles': [{'path': 'README.md', 'sha256': hashlib.sha256((packet / 'README.md').read_bytes()).hexdigest()}]}
(packet / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(str(packet), len(records))
