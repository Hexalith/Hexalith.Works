"""Read-only bounded gate progress for the continuation evidence."""
import json
from pathlib import Path
import sys

root = Path(sys.argv[1])
ledger = root / 'gate/ledger.json'
data = json.loads(ledger.read_text())
rows = data.get('rows', {})
print(json.dumps({
    'root': str(root), 'status': data['status'], 'failure': data.get('failure'),
    'commands': [{key: command[key] for key in ('name', 'exitCode', 'log') if key in command}
                 for command in data.get('commands', [])],
    'checks': data.get('checks', {}),
    'rowStatus': {key: value['status'] for key, value in rows.items()},
    'passedProofs': sum(sum(value.get('requiredProofs', {}).values()) for value in rows.values()),
    'actualStarts': len(data.get('actualStarts', [])) if isinstance(data.get('actualStarts'), list) else None,
    'rollbackKeys': sorted(data.get('rollback', {})),
}, indent=2))
