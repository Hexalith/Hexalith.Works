# Story 4.9 — published owner adoption and final qualification

This continuation follows the immutable `resume-2026-11-03` and
`publication-phase1-2026-11-03` packets. Their refusal, publication, reset,
review, and wait records remain historical evidence. The later user instruction
“merge branch” superseded the earlier wait choice. The root agent announced and
used the account's owner exemption with an exact-head guard to merge Platform
PR 15. No code-owner approval is claimed and no protection setting was changed.
The exact steering, commitlint, command, and merge result are retained separately.

The genuine published tuple is Builds **4.43.3** at
`fc743715f7d0993392dee34b2ef9c4eb85cdd399`, Platform source release **v1.1.4** at
`0635826905d88049bc8a9531206178e289ebb316`, and public EventStore **4.0.4** at
`326bfef884543cdbcaf96de7f4c4ad378dbad6d7`. The compatible newer SDK selection
was preserved; 4.0.2 remains the verified minimum containing the needed producer
fix. Builds publication and its exact signed package, embedded catalog, official
inventory, and producer-run identities are retained in phase 1. Platform was
published only after successful tuple run **41623840840** and catalog run
**41623613559** on the actual merged revision. Its source/tag release was
published at **2026-11-03T11:13:37Z**, following the existing manual convention.

The original Platform checkout was aligned to that revision after validating and
saving its nine-file overlay in selective stash
`07dce7643f01c07c6be285551600303108a20804`. No nested dependencies were
initialized. Works adopted the genuine SDK 4.0.4 pins and kept the reviewed local
SDK source `98a298a084ec6dedecf99e0abefd649051038376` distinct from the public
producer. The source/pin identity preflight passed in the original workspace;
exact command outcomes and a replay with recorded nonsecret root/mode values are
retained. This identity preflight does not establish source/package behavioral
equivalence.

Final-input ordinary source verification passed all **136** source-gate commands
with zero build warnings/errors, **597** unit, **3** property, **404** architecture,
and **1,403** integration facts. All executed facts passed with zero errors,
failures, or skips. The nine explicit integration facts were deliberately NotRun
in the ordinary suite and are required in the complete canonical qualification.
The Works script suite passed **126/126**. Ruff, Python bytecode compilation,
Bash syntax, and the CRLF-policy-aware whitespace check passed. Shellcheck was
unavailable and is not claimed. The independent parent ordinary audit and exact
XML/commands are retained.

The first final full attempt correctly refused the copy's missing twenty official
`src/**/.artifacts/ui-test-obj` inputs before any live lane. The Works bootstrap
was corrected to preserve nested canonical artifact paths while excluding root
output trees and retaining run-owned dependency links. Its regression passed,
and both the unchanged owner checker and an independent official-tree audit
confirmed all 2,597 exact source/build inputs. Only the bootstrap and its Python
regression changed after the ordinary suites; the independent diff audit binds
that unchanged runtime scope. The first refusal remains intact.

Final canonical qualification is in progress. Full uses both Debug source and
Release package model suites; the actual shipped CI entry point will run after
full succeeds. Each must independently bind all eleven matrix rows and 44 proof
kinds, complete-fleet rollback, all nine explicit facts, and final source,
consumer, runtime, archive, and launcher closure. No final parity acceptance is
claimed by this draft.

Works changes remain reviewable in its working tree. There is no root Works
commit or push and no new hosted Works run is claimed. Qualification is confined
to disposable synthetic fixtures; production preview and agent admission remain
closed.
