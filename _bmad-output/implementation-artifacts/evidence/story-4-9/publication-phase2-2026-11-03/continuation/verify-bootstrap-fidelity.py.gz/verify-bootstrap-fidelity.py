import importlib.util
import json
from pathlib import Path
import sys
import tempfile
works=Path('/home/administrator/projects/hexalith/works')
base=Path('/tmp/story49-qualification-20261103-pga3llo6')
spec=importlib.util.spec_from_file_location('parity',works/'scripts/verify-platform-parity-ci.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
artifacts=Path(tempfile.mkdtemp(prefix='story49-bootstrap-fidelity-20261103-'))
export=Path('/tmp/story49-public404-20261103-09lkkd9x/export/Hexalith.EventStore-326bfef884543cdbcaf96de7f4c4ad378dbad6d7')
_,_,record,_=module.bootstrap(works,artifacts/'bootstrap',export)
sys.dont_write_bytecode=True
sys.path.insert(0,str(works/'references/Hexalith.Platform/eng'))
import verify_works_producer as producer
failed=json.loads(Path('/tmp/story49-published-full-20261103-jz15ssts/full/gate/ledger.json').read_text())
packages=failed['publishedProducers']
snapshot=producer.runtime_source_snapshot(record['sdkRoot'])
qualification=producer.qualify_runtime_source(snapshot,packages,tag='v4.0.4')
paths=[name for name in snapshot['sourceFiles'] if '/.artifacts/ui-test-obj/' in name]
if len(paths)!=20:raise ValueError('Expected all twenty exact official nested artifact inputs')
result={'status':'passed','bootstrap':record,'qualification':qualification,'nestedOfficialInputs':{name:snapshot['sourceFiles'][name] for name in paths},'strictOwnerVerifierUnchanged':True}
(base/'bootstrap-fidelity-public-producer.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'runtimeFileCount':qualification['runtimeFileCount'],'nestedOfficialInputs':len(paths),'artifacts':str(artifacts)},indent=2))
