import hashlib,json,subprocess
from pathlib import Path
root=Path('/home/administrator/projects/hexalith/works/references/Hexalith.Platform')
base=Path('/tmp/story49-qualification-20261103-pga3llo6')
previous=Path('/tmp/story49-publication-20261103-evyasum6')
expected=json.loads((previous/'original-platform-overlay-sha256.json').read_text())
def git(*args):return subprocess.check_output(['git','-C',str(root),*args])
assert set(git('diff','--name-only').decode().splitlines())==set(expected)
assert not git('diff','--cached','--name-only').strip()
for name,digest in expected.items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
(base/'original-platform-overlay-before-adoption.diff').write_bytes(git('diff','--binary'))
# Retain the exact original overlay rather than replaying superseded capability versions.
subprocess.run(['git','-C',str(root),'stash','push','-m','fix(works): retain original overlay before published adoption','--',*expected],check=True)
stash=git('rev-parse','refs/stash').decode().strip()
(base/'original-platform-overlay-stash.json').write_text(json.dumps({'stashRevision':stash,'files':expected,'restoration':'retained backup; changes now included or superseded by the qualified published owner source'},indent=2)+'\n')
subprocess.run(['git','-C',str(root),'fetch','origin','main'],check=True)
assert git('rev-parse','origin/main').decode().strip()=='0635826905d88049bc8a9531206178e289ebb316'
subprocess.run(['git','-C',str(root),'-c','submodule.recurse=false','merge','--ff-only','origin/main'],check=True)
assert git('rev-parse','HEAD').decode().strip()=='0635826905d88049bc8a9531206178e289ebb316'
assert not git('status','--porcelain').strip()
print('Original Platform now clean at exact published source; original nine-file overlay retained as '+stash)
