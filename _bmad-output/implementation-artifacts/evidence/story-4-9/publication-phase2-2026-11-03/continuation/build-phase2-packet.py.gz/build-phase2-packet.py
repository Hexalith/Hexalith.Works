import datetime,gzip,hashlib,json,shutil
from pathlib import Path
base=Path('/tmp/story49-qualification-20261103-pga3llo6');works=Path('/home/administrator/projects/hexalith/works');sdk=Path('/tmp/story49-sdk-probe-20261103-dyovt25_');packet=works/'_bmad-output/implementation-artifacts/evidence/story-4-9/publication-phase2-2026-11-03';packet.mkdir();records=[]
def keep(source,relative):
 source=Path(source);data=source.read_bytes();stored=gzip.compress(data,mtime=0);target=packet/(relative+'.gz');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(stored);records.append({'path':target.relative_to(packet).as_posix(),'sha256':hashlib.sha256(stored).hexdigest(),'nativePath':str(source),'nativeSha256':hashlib.sha256(data).hexdigest(),'nativeBytes':len(data)})
suffixes={'.json','.jsonl','.xml','.trx','.log','.txt','.md','.py','.mjs','.diff','.patch','.stdout','.stderr'}
for p in sorted(base.iterdir()):
 if p.is_file() and p.suffix in suffixes and p.name!='README-phase2.md':keep(p,'continuation/'+p.name)
for name in ['merge-steering','platform-merge-tuple-artifact','platform-merge-catalog-artifacts']:
 root=base/name
 for p in sorted(root.rglob('*')):
  relative=p.relative_to(root)
  if p.is_file() and p.suffix in suffixes and not {'published','assets'}.intersection(relative.parts):keep(p,name+'/'+relative.as_posix())
for name in ['preflight','final','recorded']:
 root=works/('.artifacts/story49-published-pair-'+name+'-20261103')
 for p in sorted(root.iterdir()):
  if p.is_file() and p.suffix in {'.json','.log'}:keep(p,'original-source-pair-'+name+'/'+p.name)
root=works/'.artifacts/story49-published-source-20261103/solution'
for p in sorted(root.iterdir()):
 if p.is_file() and p.suffix in {'.json','.log'}:keep(p,'ordinary-source-gate/'+p.name)
for label,root in [('full-attempt1-refused',Path('/tmp/story49-published-full-20261103-jz15ssts/full')),('full-attempt2-refused',Path('/tmp/story49-published-full-20261103-o3q0a32r/full'))]:
 ledger=json.loads((root/'gate/ledger.json').read_text())
 if ledger['status']!='incomplete' or not ledger.get('failure'):raise ValueError('Expected preserved nonqualifying full attempt')
 for p in [root.parent/'invocation.json',*sorted(root.iterdir()),*sorted((root/'gate').iterdir())]:
  if p.is_file() and p.suffix in suffixes:keep(p,label+'/'+('gate/' if p.parent.name=='gate' else '')+p.name)
 for runtime in sorted((root/'gate').glob('isolated-daprd*')):
  if runtime.is_dir():
   for p in sorted(runtime.iterdir()):
    if p.is_file() and p.suffix in {'.json','.jsonl','.log'}:keep(p,label+'/gate/'+runtime.name+'/'+p.name)
for p in sorted(sdk.iterdir()):
 if p.is_file() and p.suffix in suffixes:keep(p,'sdk-prerequisite/'+p.name)
for name in ['src/Hexalith.EventStore/HealthChecks/DaprActorPlacementProbe.cs','tests/Hexalith.EventStore.Server.Tests/HealthChecks/DaprActorPlacementProbeAuthenticationTests.cs']:
 keep(sdk/'owner'/name,'sdk-prerequisite/candidate-source/'+name)
tool=Path((base/'final-tool-root.txt').read_text().strip());keep(tool.parents[3]/'artifact-identity.json','published-tool/artifact-identity.json')
shutil.copyfile(base/'README-phase2.md',packet/'README.md');handoff=packet/'handoff';handoff.mkdir();shutil.copyfile(sdk/'sdk-placement-token-fix.patch',handoff/'sdk-placement-token-fix.patch')
plain=['README.md','handoff/sdk-placement-token-fix.patch'];manifest={'status':'nonqualifying-checkpoint; SDK publication authorized and resuming','createdAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'published Builds4.43.3/Platform1.1.4 adoption, ordinary tests, two preserved full refusals and tested unpublished SDK prerequisite; no full/CI acceptance','files':records,'plainFiles':[{'path':name,'sha256':hashlib.sha256((packet/name).read_bytes()).hexdigest()} for name in plain]};(packet/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(str(packet),len(records))
