Bind Platform to published Builds 4.43.3, source fc743715f7d0993392dee34b2ef9c4eb85cdd399, and its SDK 4.0.4 catalog.

Selected-child preparation now uses the parent SDK's actual build context while preserving exact assembly and loaded-module identity checks. The unusable nested scalar workload-status grant is withdrawn, preserving denial of the two-parameter endpoint and narrowing an unmatched one-segment prefix. Historical 3.126.0 proof records remain explicitly historical.

The exact release source 0635826905d88049bc8a9531206178e289ebb316 passes hosted tuple preflight 41623840840 (153 required facts) and all four catalog-builder jobs in 41623613559. Published Builds signatures, source, catalog, Tooling and inventory identities are bound in eng/builds-tuple.json.

Fresh Works ordinary, full, actual CI and rollback qualification follow separately. This source release does not claim production preview or agent eligibility.
