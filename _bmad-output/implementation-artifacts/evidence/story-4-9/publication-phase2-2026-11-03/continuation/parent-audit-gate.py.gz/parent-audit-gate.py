import argparse
import copy
import hashlib
import importlib
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

parser = argparse.ArgumentParser()
parser.add_argument('artifacts', type=Path)
parser.add_argument('--profile', choices=['full', 'ci'], required=True)
parser.add_argument('--expected-sdk-version', required=True)
parser.add_argument('--expected-sdk-source', required=True)
parser.add_argument('--expected-platform-source', required=True)
args = parser.parse_args()
artifacts = args.artifacts.resolve()
gate = artifacts / 'gate'
ledger_path = gate / 'ledger.json'
j = json.loads(ledger_path.read_text())
bootstrap = json.loads((artifacts / 'bootstrap.json').read_text())
platform = Path(bootstrap['platformRoot'])
works = Path(bootstrap['worksRoot'])
errors = []
def require(condition, message):
    if not condition:
        errors.append(message)
def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
require(j['status'] == 'passed-disposable-synthetic-parity-and-rollback', 'terminal qualification status')
require(j['profile']['name'] == args.profile, 'selected profile')
require(j['profile']['consumerConfigurations'] == (['Debug', 'Release'] if args.profile == 'full' else ['Release']), 'profile consumer configurations')
require(j['selectedSdk']['version'] == args.expected_sdk_version, 'selected independently verified public SDK version')
require(j['runtimeProducerQualification']['repositoryCommit'] == args.expected_sdk_source, 'actual public SDK producer')
require(j['runtimeProducerQualification']['matchesPublishedProducer'] is True, 'exact public producer source qualification')
require(bootstrap['platformCommit'] == args.expected_platform_source, 'actual merged Platform revision')
require(set(j['rows']) == {'R' + str(i) for i in range(1, 12)}, 'all eleven rows')
phases_list = [json.loads(line) for line in (gate / 'persisted-states.jsonl').read_text().splitlines() if line]
phases = {record['phase']: record for record in phases_list}
require(len(phases_list) == len(phases), 'persisted phase uniqueness')
for name, row in j['rows'].items():
    require(row['status'] == 'passed', name + ' passed')
    require(row['producer']['version'] == args.expected_sdk_version, name + ' public producer version')
    require(row['producer']['repositoryCommit'] == args.expected_sdk_source, name + ' public source')
    require(row['producer']['source'] == 'https://api.nuget.org/v3/index.json', name + ' official feed')
    require(set(row['requiredProofs']) == {'persisted', 'negative', 'restart', 'rollback'}, name + ' four proof kinds')
    for kind, proof in row['requiredProofs'].items():
        require(proof['passed'] is True and bool(proof['evidence']), name + ' ' + kind + ' passed with evidence')
        for evidence in proof['evidence']:
            actual = phases.get(evidence['phase'])
            require(actual is not None, name + ' actual persisted phase')
            if actual is not None:
                require(hashlib.sha256(json.dumps(actual, sort_keys=True).encode()).hexdigest() == evidence['recordSha256'], name + ' actual phase bytes')
    relative = row['consumer']
    source = platform / relative[2:] if relative.startswith('P/') else works / relative
    require(digest(source) == row['consumerSha256'], name + ' consumed source bytes')
require(j['rollback']['complete'] is True, 'complete fleet rollback')
check_files = {
    'Debug': 'platform-debug.xml', 'Release': 'platform-release.xml',
    'supportingConsumer': 'works-consumer-supporting.xml',
    'selectedRuntimeBinaries': 'selected-runtime-binaries.xml', 'platformTelemetry': 'platform-telemetry.xml',
    'retainedStartupPreflight': 'retained-preflight.xml', 'liveRecovery': 'platform-recovery.xml',
    'liveHistorical': 'platform-historical.xml', 'liveHa': 'platform-ha.xml',
    'liveMtls': 'platform-mtls.xml', 'liveProjection': 'platform-projection.xml',
}
expected_checks = set(check_files) - ({'Debug'} if args.profile == 'ci' else set())
require(expected_checks <= set(j['checks']), 'every required test lane present')
if args.profile == 'ci':
    require('Debug' not in j['checks'], 'CI Release-only lane')
xml_counts = {}
executed = {}
for name in expected_checks:
    check = j['checks'][name]
    xml_path = gate / check_files[name]
    require(digest(xml_path) == check['sha256'], name + ' recorded XML hash')
    root = ET.parse(xml_path).getroot()
    tests = list(root.iter('test'))
    require(len(tests) == check['total'] == check['passed'] and len(tests) > 0, name + ' exact XML executed count')
    require(check['skipped'] == 0 and all(test.get('result') == 'Pass' for test in tests), name + ' all executed and passed')
    for assembly in root.iter('assembly'):
        for key in ['errors', 'failed', 'skipped', 'not-run']:
            require(assembly.get(key, '0') == '0', name + ' assembly ' + key)
    xml_counts[name] = len(tests)
    for test in tests:
        executed[test.get('method')] = {'xml': str(xml_path), 'type': test.get('type'), 'result': test.get('result')}
required_facts = {
    'ActualSelectedRuntimeBinariesCaptureWithoutMutation',
    'ActualPreviewComposesExporterKeysAndRefusesForeignFixtureTelemetry',
    'ArchivedTopologyReachesHealthyReadiness',
    'SuccessfulCallbacksRegisterSdkReminderAndProcessWithoutPeriodicRecovery',
    'SdkRemindersAndCascadeConvergeThroughPersistedReceiptsAcrossRestart',
    'PlatformLifecycleTreeClaimFilteringAndSecuritySurviveRestart',
    'TwoWorksHostsRecoverLostFiringAfterPrimaryStopsWithoutDuplicateEffect',
    'Mtls_allows_event_store_and_denies_an_unauthorized_caller_at_works_process',
    'ActualPlatformSharedRebuildAndConcurrentCatchUpPreserveCompleteFamily',
}
require(required_facts <= set(executed), 'all named frozen-matrix live facts executed')
for command in j['commands']:
    expected_exit = 1 if command['name'] == 'agents-full-refusal' else 0
    require(command['exitCode'] == expected_exit, 'command exit: ' + command['name'])
    if command.get('log') and command.get('sha256'):
        require(digest(gate / command['log']) == command['sha256'], 'command log hash: ' + command['name'])
sys.dont_write_bytecode = True
sys.path.insert(0, str(platform / 'eng'))
owner = importlib.import_module('verify_works_host')
owner.require_unchanged_inputs(copy.deepcopy(j), works, platform, Path(bootstrap['platformSourceBinding']),
    tuple(j['controlPlanePortSelection']['excludedEphemeralRange']),
    tuple(tuple(value) for value in j['controlPlanePortSelection']['excludedReservedRanges']))
rebound = owner.bind_persisted_outcomes(gate / 'persisted-states.jsonl', copy.deepcopy(j['rows']), j['actualStarts'])
require(rebound == j['rollback'], 'independent complete proof-predicate and rollback rebinding')
result = {
    'status': 'passed' if not errors else 'failed', 'errors': errors,
    'profile': args.profile, 'ledger': str(ledger_path), 'ledgerSha256': digest(ledger_path),
    'rows': len(j['rows']), 'proofs': sum(len(row['requiredProofs']) for row in j['rows'].values()),
    'uniquePersistedPhases': len(phases), 'actualStarts': len(j['actualStarts']),
    'rollbackComplete': j['rollback']['complete'], 'xmlExecutedPassCounts': xml_counts,
    'requiredExecutedFacts': {name: executed.get(name) for name in sorted(required_facts)},
    'strictOwnerFinalClosureIndependentlyRechecked': True,
    'allProofPredicatesAndRollbackIndependentlyRebound': True,
    'runtimeArtifacts': len(j['runtimeArtifacts']),
}
output = artifacts / 'parent-audit.json'
output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key != 'requiredExecutedFacts'}, indent=2))
raise SystemExit(1 if errors else 0)
