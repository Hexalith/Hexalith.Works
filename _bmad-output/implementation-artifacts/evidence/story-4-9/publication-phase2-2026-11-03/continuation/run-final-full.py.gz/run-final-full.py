import importlib.util
import json
import os
from pathlib import Path
import subprocess
import tempfile

works = Path('/home/administrator/projects/hexalith/works')
artifacts = Path(tempfile.mkdtemp(prefix='story49-published-full-20261103-'))
(artifacts / 'tmp').mkdir()
os.environ['TMPDIR'] = str(artifacts / 'tmp')
specification = importlib.util.spec_from_file_location('coordinator', works / 'scripts/verify-platform-parity-ci.py')
module = importlib.util.module_from_spec(specification)
specification.loader.exec_module(module)
actual_platform = subprocess.check_output(['git','-C',str(works / 'references/Hexalith.Platform'),'rev-parse','HEAD']).decode().strip()
if actual_platform != '0635826905d88049bc8a9531206178e289ebb316':
    raise ValueError('Final Platform source differs from the qualified published merge')
command, environment, record, snapshot = module.bootstrap(works, artifacts / 'full', Path('/tmp/story49-public404-20261103-09lkkd9x/export/Hexalith.EventStore-326bfef884543cdbcaf96de7f4c4ad378dbad6d7'))
command[command.index('--profile') + 1] = 'full'
environment['HexalithBuildsPublishedToolRoot'] = Path('/tmp/story49-qualification-20261103-pga3llo6/final-tool-root.txt').read_text().strip()
cache = artifacts / 'packages'
cache.mkdir()
environment.update({'NUGET_PACKAGES':str(cache), 'RestorePackagesPath':str(cache), 'RestoreSources':'https://api.nuget.org/v3/index.json'})
(artifacts / 'invocation.json').write_text(json.dumps({'command': command, 'worksRoot': str(works), 'artifacts': str(artifacts), 'publishedBuildsToolRoot': environment['HexalithBuildsPublishedToolRoot'], 'nugetPackages':str(cache), 'restoreSources':environment['RestoreSources']}, indent=2) + '\n')
print(str(artifacts), flush=True)
result = subprocess.run(command, env=environment)
if result.returncode == 0:
    if snapshot.origin_files(Path(record['platformOrigin'])) != record['platformSourceFiles']:
        raise ValueError('Platform source changed during full qualification')
    module.require_unchanged_coordinators(record['coordinatorSha256'])
print('fullExitCode=' + str(result.returncode), flush=True)
raise SystemExit(result.returncode)
