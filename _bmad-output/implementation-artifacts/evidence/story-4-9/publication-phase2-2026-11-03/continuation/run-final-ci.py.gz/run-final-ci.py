"""Invoke the shipped Works CI entry point after the independently recorded full run."""
import json
import os
from pathlib import Path
import subprocess
import tempfile

base = Path('/tmp/story49-qualification-20261103-pga3llo6')
full = Path('/tmp/story49-published-full-20261103-o3q0a32r/full/gate/ledger.json')
if json.loads(full.read_text())['status'] != 'passed-disposable-synthetic-parity-and-rollback':
    raise ValueError('The canonical full ledger must pass before actual CI qualification')
works = Path('/home/administrator/projects/hexalith/works')
artifacts = Path(tempfile.mkdtemp(prefix='story49-published-ci-20261103-'))
temporary = artifacts / 'tmp'
temporary.mkdir()
cache = artifacts / 'packages'
cache.mkdir()
environment = os.environ.copy()
environment.update({
    'TMPDIR': str(temporary),
    'NUGET_PACKAGES': str(cache),
    'RestorePackagesPath': str(cache),
    'RestoreSources': 'https://api.nuget.org/v3/index.json',
    'HexalithBuildsPublishedToolRoot': (base / 'final-tool-root.txt').read_text().strip(),
})
command = [
    'bash', 'scripts/verify-platform-parity-ci.sh',
    '--runtime-sdk-root', '/tmp/story49-public404-20261103-09lkkd9x/export/Hexalith.EventStore-326bfef884543cdbcaf96de7f4c4ad378dbad6d7',
    '--artifacts-path', str(artifacts / 'ci'),
]
record = {'command': command, 'cwd': str(works), 'artifacts': str(artifacts),
          'explicitEnvironment': {key: environment[key] for key in (
              'TMPDIR', 'NUGET_PACKAGES', 'RestorePackagesPath', 'RestoreSources',
              'HexalithBuildsPublishedToolRoot')},
          'fullLedger': str(full)}
(artifacts / 'invocation.json').write_text(json.dumps(record, indent=2) + '\n')
print(str(artifacts), flush=True)
result = subprocess.run(command, env=environment, cwd=works)
record['exitCode'] = result.returncode
(artifacts / 'command-outcome.json').write_text(json.dumps(record, indent=2) + '\n')
print('actualCiExitCode=' + str(result.returncode), flush=True)
raise SystemExit(result.returncode)
