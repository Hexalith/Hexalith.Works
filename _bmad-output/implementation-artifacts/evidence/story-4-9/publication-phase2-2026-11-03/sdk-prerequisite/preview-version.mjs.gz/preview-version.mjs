import fs from 'node:fs';
import { analyzeCommits } from './owner/node_modules/@semantic-release/commit-analyzer/index.js';
const document=JSON.parse(fs.readFileSync('/tmp/story49-qualification-20261103-pga3llo6/sdk-unpublished-main-compare.json','utf8'));
const commits=document.commits.map(row=>({hash:row.sha,message:row.commit.message}));
const messages=[];
const releaseType=await analyzeCommits({}, {cwd:'/tmp/story49-sdk-probe-20261103-dyovt25_/owner',commits,logger:{log:(...row)=>messages.push(row)}});
const result={scope:'owner commit-analyzer only; no semantic-release plugins, publication, or candidate authority',basePublishedVersion:'4.0.4',observedMain:'1aec4a7f466cfae7f590703fbde222d39f00d659',commitAnalyzerVersion:JSON.parse(fs.readFileSync('./owner/node_modules/@semantic-release/commit-analyzer/package.json','utf8')).version,commits,releaseType,normalReleaseVersionPreview:releaseType==='minor'?'4.1.0':null,qualification:'preview for these five observed commits only; future merged history and owning protected release remain authoritative',messages};
fs.writeFileSync('version-preview.json',JSON.stringify(result,null,2)+'\n');
process.stdout.write(JSON.stringify({releaseType,nextVersionPreview:result.normalReleaseVersionPreview})+'\n');
