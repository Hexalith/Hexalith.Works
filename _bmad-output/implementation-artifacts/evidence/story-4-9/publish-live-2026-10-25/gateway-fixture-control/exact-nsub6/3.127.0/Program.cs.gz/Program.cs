using System.Net;
using System.Net.Http.Json;
using Hexalith.EventStore.Client.Gateway;
using Hexalith.EventStore.Contracts.Streams;
using Microsoft.Extensions.Options;
using NSubstitute;

var assertions = Substitute.For<IEventStoreGatewayWorkloadAssertionSource>();
assertions.IssueAsync(Arg.Any<string>(), Arg.Any<string>(), Arg.Any<CancellationToken>()).Returns(ValueTask.FromResult<string?>("synthetic-bound-assertion"));
var handler = new ProbeHandler();
using var http = new HttpClient(handler) { BaseAddress = new Uri("https://eventstore.test/") };
var gateway = new EventStoreGatewayClient(http, Options.Create(new EventStoreGatewayClientOptions()), assertions);
string? exception = null;
try { await gateway.ReadWorkloadStreamAsync(new("tenant", "work", "item", 0), CancellationToken.None); }
catch (Exception error) { exception = error.GetType().Name + ": " + error.Message; }
Console.WriteLine(System.Text.Json.JsonSerializer.Serialize(new { httpCalls = handler.Calls, exception, assertionCalls = assertions.ReceivedCalls().Select(call => new { method = call.GetMethodInfo().Name, arguments = call.GetArguments().Length }) }));
