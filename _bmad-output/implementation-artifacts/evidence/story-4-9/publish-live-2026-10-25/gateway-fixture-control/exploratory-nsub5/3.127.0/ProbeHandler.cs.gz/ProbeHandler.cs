using System.Net;
using System.Net.Http.Json;
using Hexalith.EventStore.Contracts.Streams;
internal sealed class ProbeHandler : HttpMessageHandler
{
    internal int Calls { get; private set; }
    protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken token)
    {
        Calls++;
        return Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK) { Content = JsonContent.Create(new StreamReadPage("tenant", "work", "item", [], new StreamReadMetadata(0, null, null, 0, 0, false, null))) });
    }
}
