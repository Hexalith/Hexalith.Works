Complete-source HTTP, recovery-discovery and command-status fixtures fail the blocking tracked-content secret guard. Generate per-invocation channel tokens and pass the same values through receivers, clients and forwarding handlers. Generate the four private recovery canaries at their exact original lengths. Select the existing runtime signing key in an explicit scenario branch, so the credential assignment contains only its runtime value. All behavioral and no-disclosure assertions remain intact.

Validation:
- Original four-file repair: three clean Debug/source builds; 292 scanner/invoker, 23 complete-source and 250 read-model cases passed.
- After merging current main 4e91e552: final Debug/source Server and DomainService builds succeeded; 289 scanner/receiving-authentication and 11 transport cases passed.
- The unchanged full repository secret scan passes against the actual merged tracked inputs. Every executed focused case has zero failures, errors, skips or unexecuted results.

The newer command-status production change is preserved from main; this PR's own changes remain fixture-only.
