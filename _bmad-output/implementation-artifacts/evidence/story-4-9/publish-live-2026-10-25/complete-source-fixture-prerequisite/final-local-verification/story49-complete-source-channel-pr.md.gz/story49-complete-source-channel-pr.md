New complete-source HTTP and recovery-discovery fixtures fail the blocking tracked-content secret guard. Generate a channel token per invocation and pass the same value to the receiver and request path. Generate the four recovery canaries at their original lengths, preserving field names and the matching no-disclosure assertion.

Validation:
- Three Debug/source owner builds: zero warnings or errors.
- Secret scanner and Dapr invoker tests: 292/292 passed.
- Complete-source tests: 23/23 passed.
- Read-model batch tests: 250/250 passed.

All 565 focused cases executed with zero failures, errors, or skips.
