import datetime,json,subprocess,sys,xml.etree.ElementTree as ET
from pathlib import Path
owner=Path('/home/administrator/projects/hexalith/works/references/Hexalith.EventStore');out=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/tmp/story49-complete-source-fixture-checks');out.mkdir(exist_ok=False)
records=[]
def run(name,args):
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (out/(name+'.log')).open('w') as f:r=subprocess.run(args,cwd=owner,stdout=f,stderr=subprocess.STDOUT)
 records.append({'name':name,'command':args,'cwd':str(owner),'startedAt':start,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':r.returncode})
 (out/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
 print(name+': '+str(r.returncode),flush=True)
 if r.returncode:
  print((out/(name+'.log')).read_text()[-5000:],flush=True);raise SystemExit(r.returncode)
artifact='.artifacts/story49-publish-20261025'
for project,classes in [('Server',['Hexalith.EventStore.Server.Tests.Security.SecretsProtectionTests','Hexalith.EventStore.Server.Tests.DomainServices.DaprDomainServiceInvokerTests']),('DomainService',['Hexalith.EventStore.DomainService.Tests.CompleteCommandSourceTests']),('Client',['Hexalith.EventStore.Client.Tests.Projections.DaprReadModelBatchTests'])]:
 name='Hexalith.EventStore.'+project+'.Tests'
 run(project+'-build',['dotnet','build','tests/'+name+'/'+name+'.csproj','-c','Debug','-p:UseHexalithProjectReferences=true','--artifacts-path',artifact,'-m:1'])
 args=[artifact+'/bin/'+name+'/debug/'+name,'-noLogo']
 for cls in classes:args+=['-class',cls]
 args+=['-result-xml',str(out/(project+'-tests.xml'))]
 run(project+'-tests',args)
 assembly=ET.parse(out/(project+'-tests.xml')).getroot().find('assembly')
 assert assembly is not None and int(assembly.get('total','0'))>0
 assert all(assembly.get(k,'0')=='0' for k in ('failed','errors','skipped','not-run'))
 print(project+' cases: '+assembly.get('passed','?'),flush=True)
(out/'owner.patch').write_bytes(subprocess.check_output(['git','diff','HEAD'],cwd=owner))
