import base64,datetime,hashlib,json,os,re,shutil,ssl,subprocess,sys,tempfile,time,urllib.request
from pathlib import Path
import yaml
out=Path(sys.argv[1]);platform=Path(sys.argv[2]);raw=out/'raw-native';raw.mkdir(exist_ok=True);sessions={};ids=set();seen_inspect=set();rounds=0

def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def probe(url,basis):
 record={'at':stamp(),'url':url,'basis':basis}
 try:
  with urllib.request.urlopen(url,timeout=1) as response:
   data=response.read(8192);record.update(status=response.status,bodySha256=hashlib.sha256(data).hexdigest(),bodyLength=len(data),bodyText=data.decode(errors='replace')[:1000])
 except Exception as e:record.update(errorType=type(e).__name__,error=str(e))
 with (out/'owned-health-probes.jsonl').open('a') as f:f.write(json.dumps(record)+'\n')

def service_records(session):
 config=yaml.safe_load((session/'kubeconfig').read_text());cluster=config['clusters'][0]['cluster'];user=config['users'][0]['user'];ctx=ssl.create_default_context(cadata=base64.b64decode(cluster['certificate-authority-data']).decode())
 with tempfile.TemporaryDirectory(prefix='story49-owned-kube-client-') as temporary:
  t=Path(temporary)
  for name,key in [('cert','client-certificate-data'),('key','client-key-data')]:
   p=t/name;p.write_bytes(base64.b64decode(user[key]));p.chmod(0o600)
  ctx.load_cert_chain(str(t/'cert'),str(t/'key'))
  url=cluster['server']+'/apis/usvc-dev.developer.microsoft.com/v1/services';request=urllib.request.Request(url)
  with urllib.request.urlopen(request,context=ctx,timeout=1) as response:d=json.load(response)
 return [{'metadata':{'name':x['metadata']['name'],'uid':x['metadata'].get('uid')},'spec':x.get('spec'),'status':x.get('status')} for x in d['items'] if x['metadata']['name'].startswith('dapr-sentry')]

while True:
 try:
  events=[json.loads(x) for x in (out/'temporary-docker-events.jsonl').read_text().splitlines() if x]
  for e in events:
   attrs=e.get('Actor',{}).get('Attributes',{});mounts=attrs.get('com.microsoft.developer.usvc-dev.mountsLabel','')
   if 'src='+str(platform/'DaprComponents/sentry.yaml') in mounts:
    ids.add(e['Actor']['ID']);pid=attrs.get('com.microsoft.developer.usvc-dev.creatorProcessId')
    if pid not in sessions:
     try:
      env=dict(x.split(b'=',1) for x in (Path('/proc')/pid/'environ').read_bytes().split(b'\0') if b'=' in x)
      session=Path(env[b'DCP_SESSION_FOLDER'].decode());sessions[pid]=session
      with (out/'native-session-identities.jsonl').open('a') as f:f.write(json.dumps({'at':stamp(),'creatorPid':pid,'session':str(session),'sentryId':e['Actor']['ID'],'diagnosticSettings':{k.decode():v.decode() for k,v in env.items() if k in [b'DCP_DIAGNOSTICS_LOG_FOLDER',b'DCP_PRESERVE_EXECUTABLE_LOGS',b'DCP_DIAGNOSTICS_LOG_LEVEL']},'kubeconfigRetained':False})+'\n')
     except (FileNotFoundError,KeyError,PermissionError):pass
  for pid,session in list(sessions.items()):
   target=raw/session.name;target.mkdir(exist_ok=True)
   if not session.exists():continue
   for p in session.iterdir():
    if p.is_file() and (p.name.startswith('resource-') and p.suffix=='.log' or re.search(r'_(?:out|err|startout|starterr)(?:_|$)',p.name)):
     try:shutil.copyfile(p,target/p.name)
     except FileNotFoundError:pass
   if rounds%6==0:
    try:
     services=service_records(session)
     with (out/'owned-sentry-services.jsonl').open('a') as f:f.write(json.dumps({'at':stamp(),'session':str(session),'services':services})+'\n')
     for service in services:
      status=service.get('status') or {};spec=service.get('spec') or {};address=status.get('allocatedAddress','127.0.0.1');port=status.get('allocatedPort',spec.get('port'))
      if 'health' in service['metadata']['name'] and address in ['127.0.0.1','localhost','::1'] and isinstance(port,int) and port>0:probe('http://'+('['+address+']' if ':' in address else address)+':'+str(port)+'/healthz',{'kind':'owned DCP Sentry health service','service':service['metadata']['name'],'session':str(session)})
    except Exception as e:
     with (out/'native-observer-errors.jsonl').open('a') as f:f.write(json.dumps({'at':stamp(),'stage':'service-snapshot','session':str(session),'type':type(e).__name__,'message':str(e)})+'\n')
  if rounds%6==0:
   for cid in ids:
    r=subprocess.run(['docker','inspect',cid],capture_output=True,text=True)
    if r.returncode:continue
    d=json.loads(r.stdout)[0];safe={'at':stamp(),'id':cid,'name':d.get('Name'),'state':d.get('State'),'ports':d.get('NetworkSettings',{}).get('Ports'),'portBindings':d.get('HostConfig',{}).get('PortBindings'),'command':d.get('Config',{}).get('Cmd'),'healthcheck':d.get('Config',{}).get('Healthcheck'),'mounts':[{'type':x.get('Type'),'source':x.get('Source'),'destination':x.get('Destination'),'readWrite':x.get('RW')} for x in d.get('Mounts',[])]}
    with (out/'owned-sentry-inspect.jsonl').open('a') as f:f.write(json.dumps(safe)+'\n')
    for mapping in safe['ports'].get('8080/tcp') or []:
     host=mapping['HostIp'];port=mapping['HostPort']
     if host in ['0.0.0.0','127.0.0.1','::','::1']:probe('http://127.0.0.1:'+port+'/healthz',{'kind':'owned Sentry Docker published health port','containerId':cid})
 except Exception as e:
  with (out/'native-observer-errors.jsonl').open('a') as f:f.write(json.dumps({'at':stamp(),'stage':'observer','type':type(e).__name__,'message':str(e)})+'\n')
 if (out/'stop-native-observer').exists():break
 rounds+=1;time.sleep(0.5)
print('native sessions observed',len(sessions))
