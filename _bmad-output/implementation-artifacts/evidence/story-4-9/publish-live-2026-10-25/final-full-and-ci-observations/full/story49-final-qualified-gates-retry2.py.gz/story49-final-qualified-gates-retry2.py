import datetime,json,os,shutil,subprocess,sys,xml.etree.ElementTree as E
from pathlib import Path
root=Path('/home/administrator/projects/hexalith/works');base=Path('/tmp/story49-final-public-3.128.0-qualification-retry2');base.mkdir(exist_ok=True)
profile=sys.argv[1];assert profile in ('full','ci');artifacts=base/profile;assert not artifacts.exists()
expected={'Works':'bfbdbc1c166b7cd750db4d890d77c3f55bb01273','Builds':'f9142d8a845a16e54ee060e6a0250c773d00e0ba','Platform':'2c261d2517692ac45721099fcccf822f3821509e','EventStore':'c5d1c280d8c1c1a207cd159d817f614e93c93130','Tenants':'3b60914ace5201a711fb51c1036d3679e0512ec8'}
for owner,head in expected.items():
 r=root if owner=='Works' else root/'references'/('Hexalith.'+owner)
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==head,owner
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=r,text=True).strip(),owner
ordinary=json.loads(Path('/tmp/story49-final-consumer-ordinary/commands.json').read_text());assert [x['name'] for x in ordinary]==['default-restore','isolated-restore','source-build','unit','property','architecture','integration'];assert all(x['exitCode']==0 for x in ordinary)
for directory,name in [('story49-final-callback-native-diagnostic','callback'),('story49-final-restart-native-diagnostic','restart')]:
 diag=Path('/tmp')/directory;record=json.loads((diag/'command.json').read_text());assert record['exitCode']==0 and record['runtimeArtifactsVerifiedAfter']==441
 a=E.parse(diag/(name+'.xml')).getroot().find('assembly');assert int(a.get('passed'))==1 and all(int(a.get(k,'0'))==0 for k in ['failed','errors','skipped','not-run'])
if profile=='ci':
 assert json.loads((base/'full-process.json').read_text())['exitCode']==0
 assert json.loads((base/'full/gate/ledger.json').read_text())['status']=='passed-disposable-synthetic-parity-and-rollback'
 assert (base/'acceptance-audit-full.json').exists(),'complete closure/matrix audit must pass before actual CI'
command=['python3','/tmp/story49-resume-20261025-full-driver.py',str(artifacts)] if profile=='full' else ['bash','scripts/verify-platform-parity-ci.sh','--artifacts-path',str(artifacts)]
observations=base/(profile+'-observations');observations.mkdir(exist_ok=False)
environment=os.environ.copy();delta={'DcpPublisher__DiagnosticsLogFolder':str(observations/'native'),'DcpPublisher__PreserveExecutableLogs':'true','DcpPublisher__DiagnosticsLogLevel':'debug'};environment.update(delta)
started=datetime.datetime.now(datetime.timezone.utc).isoformat();events_path=base/(profile+'-docker-events.jsonl');observer_command=['docker','events','--since',started,'--filter','type=container','--format','{{json .}}'];native_command=['python3','/tmp/story49-capture-native-session.py',str(observations),str(artifacts/'workspace/platform'),str(events_path)]
record={'profile':profile,'command':command,'cwd':str(root),'startedAt':started,'selectedHeads':expected,'state':'running','dockerObserverCommand':observer_command,'nativeObserverCommand':native_command,'diagnosticEnvironmentDelta':delta,'observerPurpose':'read-only run-owned metadata/log capture and bounded owned /healthz observations; no assertions, deadlines or runtime/source bytes modified','previousAttempt':'/tmp/story49-final-public-3.128.0-qualification/full','previousAttemptQualifying':False};status=base/(profile+'-process.json');status.write_text(json.dumps(record,indent=2)+'\n')
for name in ['story49-final-qualified-gates-retry2.py','story49-resume-20261025-full-driver.py','story49-capture-native-session.py']:
 target=observations/name;shutil.copyfile(Path('/tmp')/name,target)
observer=native_observer=None;result=None
try:
 with events_path.open('w') as events,(base/(profile+'-docker-observer.stderr')).open('w') as errors,(observations/'observer.log').open('w') as native_log:
  observer=subprocess.Popen(observer_command,stdout=events,stderr=errors);native_observer=subprocess.Popen(native_command,stdout=native_log,stderr=subprocess.STDOUT)
  with (base/(profile+'-console.log')).open('w') as stream:result=subprocess.run(command,cwd=root,env=environment,stdout=stream,stderr=subprocess.STDOUT)
finally:
 (observations/'stop-native-observer').write_text('gate completed; final read-only snapshot then stop\n')
 if native_observer is not None:
  try:native_observer.wait(timeout=15)
  except subprocess.TimeoutExpired:native_observer.terminate();native_observer.wait(timeout=5)
 if observer is not None and observer.poll() is None:
  observer.terminate()
  try:observer.wait(timeout=5)
  except subprocess.TimeoutExpired:observer.kill();observer.wait(timeout=5)
record.update(exitCode=result.returncode if result else None,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),state='completed',dockerObserverExitCode=observer.returncode if observer else None,nativeObserverExitCode=native_observer.returncode if native_observer else None);status.write_text(json.dumps(record,indent=2)+'\n');print(profile,record['exitCode'],flush=True)
raise SystemExit(record['exitCode'] if record['exitCode'] is not None else 1)
