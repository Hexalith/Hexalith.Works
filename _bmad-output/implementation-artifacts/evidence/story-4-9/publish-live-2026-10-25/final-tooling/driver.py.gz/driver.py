import datetime,hashlib,json,os,subprocess
from pathlib import Path
root=Path('/home/administrator/projects/hexalith/works');out=Path('/tmp/story49-final-tooling');out.mkdir(exist_ok=False);records=[];environment=os.environ.copy()
def run(name,cmd,cwd=root):
 record={'name':name,'command':cmd,'cwd':str(cwd),'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with (out/(name+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=cwd,env=environment,stdout=log,stderr=subprocess.STDOUT)
 record.update(exitCode=r.returncode,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),outputSha256=hashlib.sha256((out/(name+'.log')).read_bytes()).hexdigest());records.append(record);(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(name,r.returncode,flush=True);assert r.returncode==0,name
package=out/'shellcheck-package';package.mkdir();run('download-shellcheck',['apt-get','download','shellcheck=0.11.0-2'],package);deb=next(package.glob('*.deb'));run('extract-shellcheck',['dpkg-deb','-x',str(deb),str(out/'shellcheck')]);environment.update(UV_TOOL_DIR=str(out/'uv-tools'),UV_TOOL_BIN_DIR=str(out/'bin'));run('install-ruff',['uv','tool','install','ruff==0.13.2']);environment['PATH']=str(out/'shellcheck/usr/bin')+os.pathsep+str(out/'bin')+os.pathsep+environment['PATH']
run('shellcheck-version',['shellcheck','--version']);run('ruff-version',['ruff','--version']);assert (out/'ruff-version.log').read_text().strip()=='ruff 0.13.2'
run('lint-scripts',['bash','scripts/lint-scripts.sh']);assert 'not installed' not in (out/'lint-scripts.log').read_text()
run('tooling-tests',['python3','-m','unittest','discover','-s','scripts/tests']);print('complete actual-linter and tooling verification',flush=True)
