from pathlib import Path
import zipfile,xml.etree.ElementTree as E,json,hashlib,re
root=Path('/tmp/story49-hosted-attempt1');ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'};rows=[];nonpassing=[]
with zipfile.ZipFile(root/'blocking-test-results.zip') as z:
 for name in z.namelist():
  if not name.endswith('.trx'):continue
  data=z.read(name);doc=E.fromstring(data);counters=doc.find('t:ResultSummary/t:Counters',ns);cases=[]
  for t in doc.findall('.//t:UnitTestResult',ns):
   item={'name':t.get('testName'),'result':t.get('outcome'),'testId':t.get('testId')};cases.append(item)
   if item['result']!='Passed':nonpassing.append({'file':name,**item,'message':' '.join(t.itertext()).strip()})
  rows.append({'path':name,'sha256':hashlib.sha256(data).hexdigest(),'counters':counters.attrib,'cases':cases})
assert len(rows)==4
expected={'Hexalith.Works.ArchitectureTests':398,'Hexalith.Works.IntegrationTests':1020,'Hexalith.Works.PropertyTests':3,'Hexalith.Works.UnitTests':597}
for r in rows:
 project=r['path'].split('/')[0];assert int(r['counters']['passed'])==expected[project]
 assert all(int(r['counters'].get(k,'0'))==0 for k in ['failed','error','timeout','aborted'])
assert len(nonpassing)==7 and all(x['result']=='NotExecuted' for x in nonpassing)
local=json.loads(Path('/tmp/story49-final-consumer-ordinary/commands.json').read_text());old=next(x['nonpassing'] for x in local if x['name']=='integration');assert {x['name'] for x in old}=={x['name'] for x in nonpassing}
result={'workflowRun':40230306221,'attempt':1,'head':'da76aea2ab2f650b71613d139d0145f2b509ad0f','ordinaryJobConclusion':'success','passed':sum(expected.values()),'nonexecutedCount':7,'nonexecuted':nonpassing,'nonexecutedClassification':'Exactly the same seven explicit topology facts as the local ordinary lane. They passed in local full and remain mandatory in hosted canonical CI; not counted as ordinary passes.','testInventories':rows,'profileJobExclusions':{'ci / aspire-tests':'optional reusable workflow lane not selected; actual Platform parity job remains mandatory','ci / performance-tests':'optional reusable workflow lane not selected; no parity credit'},'installerComparison':{'globalJsonVersion':'10.0.402','rollForward':'latestPatch','installerChannel':'10.0.4xx','actualInstalledSdk':'10.0.403','actualInstalledRuntime':'10.0.14','actionCommit':'a98b56852c35b8e3190ac28c8c2271da59106c68','ordinaryDownloadSucceeded':'https://builds.dotnet.microsoft.com/dotnet/Sdk/10.0.403/dotnet-sdk-10.0.403-linux-x64.tar.gz','failedOtherJobRoute':'https://dotnetorigin.blob.core.windows.net/dotnet/Sdk/10.0.403/dotnet-sdk-10.0.403-linux-x64.tar.gz','sourceOrWorkflowChanges':False}}
(root/'ordinary-result-audit.json').write_text(json.dumps(result,indent=2)+'\n');print('ordinary',result['passed'],'passes',len(nonpassing),'mapped explicit notexecuted')
