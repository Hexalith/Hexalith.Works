The public 3.127.0 SDK rejects repeated app-channel registration used by the preserved retained topology. Select the published 3.128.0 producer and validated catalog/Platform revisions, retain the exact archived topology, and record the complete current full-gate proof before hosted CI qualification.

The bounded prerequisite changes preserve the original user guards, package-origin assertions, exact stream-read assertion scope, and all recovery/security outcomes. Documentation distinguishes current SDK-only hosting and the consumed embedded plan from historical evidence. Original failures and byte-preserving evidence relocations remain reviewable.

Validation:
- Official package provenance and all 8 unchanged token regressions pass.
- Ordinary checks: 597 unit, 3 property (300 generated), 398 architecture, and 1,020 integration passes; seven explicit live facts accounted for separately.
- Canonical full at `bfbdbc1c166b7cd750db4d890d77c3f55bb01273`: 603 passes, no exclusions, 11 rows, 44 proof kinds, 32 persisted phases, complete rollback and final input closure.
- All 425 bound Works input bytes remain equal at this PR head; owner inputs and immutable archives are unchanged. Staged architecture 398/398, real shellcheck/ruff lint, and all 76 tooling tests pass.
- Two local actual-CI attempts failed (projection transport and Scheduler published-health readiness); causes remain unresolved and neither attempt qualifies. This PR must pass the complete actual hosted canonical CI profile, all ordinary checks, closure/equivalence audit and independent BMAD review before merge or story completion.
- An extra generic Builds authority diagnostic reproduces nine existing baseline declarations; it is not a Works CI command and is not claimed as passing.

Evidence and exact review scope: `_bmad-output/implementation-artifacts/evidence/story-4-9/publish-live-2026-10-25/README.md`. Builds PR 141 merged with the selected tree. Platform PR 7 still requires normal eligible code-owner review. No auto-merge is enabled; story and sprint remain in progress.
