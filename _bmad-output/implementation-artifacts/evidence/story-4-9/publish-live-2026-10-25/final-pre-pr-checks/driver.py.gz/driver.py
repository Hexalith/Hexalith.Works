from pathlib import Path
import subprocess,json,datetime,hashlib,xml.etree.ElementTree as E
root=Path('/home/administrator/projects/hexalith/works');out=Path('/tmp/story49-hosted-pr-final-checks');records=[]
commands=[('architecture',[str(root/'.artifacts/story49-final-consumer-3.128.0/bin/Hexalith.Works.ArchitectureTests/debug/Hexalith.Works.ArchitectureTests'),'-noLogo','-result-xml',str(out/'architecture.xml')]),('consumer-authority',['pwsh','-NoProfile','-File','references/Hexalith.Builds/Tools/validate-consumer-package-authority.ps1','-RepositoryRoot','.','-CatalogPath','references/Hexalith.Builds/Props/Directory.Packages.props']),('diff-check',['git','-c','core.whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol','diff','--cached','--check'])]
for name,command in commands:
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (out/(name+'.log')).open('w') as f:r=subprocess.run(command,cwd=root,stdout=f,stderr=subprocess.STDOUT)
 records.append({'name':name,'command':command,'cwd':str(root),'startedAt':start,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':r.returncode,'logSha256':hashlib.sha256((out/(name+'.log')).read_bytes()).hexdigest()});(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
xml=E.parse(out/'architecture.xml');a=xml.getroot().find('assembly');print('architecture',a.attrib,flush=True)
assert a.attrib['passed']=='398' and all(a.attrib.get(x,'0')=='0' for x in ['failed','errors','skipped','not-run'])
