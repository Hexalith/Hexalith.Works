from pathlib import Path
import subprocess,json,hashlib,shutil,xml.etree.ElementTree as ET
root=Path.cwd();out=Path('/tmp/story49-hosted-pr-final-checks');bounded=Path('/tmp/story49-hosted-pr-final-checks-bounded');bounded.mkdir(exist_ok=False)
message=out/'commit-message.txt';message.write_text('docs(hosting): retain public SDK full proof for hosted CI\n')
r=subprocess.run(['node','node_modules/@commitlint/cli/cli.js','--edit',str(message)],capture_output=True);(out/'commitlint.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0
(out/'commitlint.json').write_text(json.dumps({'command':['node','node_modules/@commitlint/cli/cli.js','--edit',str(message)],'installedVersion':json.loads((root/'node_modules/@commitlint/cli/package.json').read_text())['version'],'exitCode':r.returncode},indent=2)+'\n')
subprocess.run(['git','add','--','_bmad-output/implementation-artifacts/spec-4-9-migrate-works-hosting-to-the-platform-boundary.md','_bmad-output/implementation-artifacts/evidence/story-4-9/publish-live-2026-10-25/README.md'],check=True)
ledger=Path('/tmp/story49-final-public-3.128.0-qualification-retry2/full/gate/ledger.json');d=json.loads(ledger.read_text());verified=[]
for path,digest in d['canonicalSources']['Works']['sourceFiles'].items():
 before=subprocess.check_output(['git','show','bfbdbc1:'+path]);staged=subprocess.check_output(['git','show',':'+path]);actual=(root/path).read_bytes()
 assert before==staged==actual,path
 assert hashlib.sha256(actual).hexdigest()==digest,path
 verified.append({'path':path,'sha256':digest})
changes=subprocess.check_output(['git','diff','--cached','--raw','--no-abbrev','--no-renames'],text=True).splitlines()
paths=subprocess.check_output(['git','diff','--cached','--name-only'],text=True).splitlines()
allowed=['_bmad-output/implementation-artifacts/evidence/story-4-9/publish-live-2026-10-25/','_bmad-output/implementation-artifacts/spec-4-9-migrate-works-hosting-to-the-platform-boundary.md','docs/platform-hosting-cutover.md','docs/eventstore-api-surface-constraints.md']
assert all(any(p==a or a.endswith('/') and p.startswith(a) for a in allowed) for p in paths)
assert not set(paths).intersection(d['canonicalSources']['Works']['sourceFiles'])
(out/'precommit-input-equivalence.json').write_text(json.dumps({'qualifiedWorksRevision':d['canonicalSources']['Works']['commit'],'ledgerSha256':hashlib.sha256(ledger.read_bytes()).hexdigest(),'comparison':'Every bound Works source byte equals qualified commit blob, actual working file and staged blob. Canonical helper independently rechecks complete membership plus all dependency/runtime/archive/launcher inputs. Only unbound documents and evidence differ.','verifiedCanonicalInputs':verified,'unboundChangedPaths':paths,'exactGitRawChanges':changes,'gitlinksChanged':False,'scope':'Index before additive final-check evidence packet; final commit and actual hosted checkout require separately recorded exact input comparison. Local ledger remains bfb.'},indent=2)+'\n')
xml=ET.parse(out/'architecture.xml').getroot().find('assembly');assert xml.attrib['passed']=='398' and all(xml.attrib.get(x,'0')=='0' for x in ['failed','errors','skipped','not-run'])
(out/'architecture-result.json').write_text(json.dumps(xml.attrib,indent=2)+'\n')
for p in out.iterdir():
 if p.suffix in ['.json','.log','.xml','.txt']:shutil.copy2(p,bounded/p.name)
for s in ['/tmp/story49-full-closure-recheck-after-current-docs.json','/tmp/story49-preserved-packet-audit-before-hosted-pr.json']:
 p=Path(s);shutil.copy2(p,bounded/p.name)
shutil.copy2('/tmp/story49-final-pre-push-checks.py',bounded/'driver.py')
shutil.copy2(__file__,bounded/'prepare-review-evidence.py')
print('verified bound inputs',len(verified),'bounded final check files',len(list(bounded.iterdir())))
