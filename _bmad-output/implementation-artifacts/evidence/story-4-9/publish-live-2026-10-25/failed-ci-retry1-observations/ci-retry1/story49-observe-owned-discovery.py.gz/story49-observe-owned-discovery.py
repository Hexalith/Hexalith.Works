import datetime,hashlib,json,os,re,sqlite3,sys,time
from pathlib import Path
out=Path(sys.argv[1]);stop=out/'stop-native-observer';last={}
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def append(record):
 with (out/'owned-discovery-observations.jsonl').open('a') as f:f.write(json.dumps(record,sort_keys=True)+'\n')
while not stop.exists():
 folders=set()
 for p in (out/'raw-native').glob('*/resource-executable-*.log'):
  try:s=p.read_text()
  except OSError:continue
  folders.update(Path(x) for x in re.findall(r'(/tmp/works-sdk416-discovery-[A-Za-z0-9]+)/(?:[0-9]+-accesscontrol[^"\s]*)',s))
 for folder in sorted(folders):
  db=folder/'name-resolution.db';record={'at':utc(),'registryPath':str(db),'ownershipBasis':'Exact config directory from this diagnostic owned native sidecar launch records','liveDatabaseOpenedByObserver':False}
  try:
   stat=db.stat();identity=(os.major(stat.st_dev),os.minor(stat.st_dev),stat.st_ino)
   record['file']={'deviceMajor':identity[0],'deviceMinor':identity[1],'inode':identity[2],'bytes':stat.st_size,'modifiedNs':stat.st_mtime_ns}
   record['locks']=[]
   for line in Path('/proc/locks').read_text().splitlines():
    parts=line.split()
    for item in parts:
     if re.fullmatch(r'[0-9a-fA-F]+:[0-9a-fA-F]+:[0-9]+',item):
      a,b,c=item.split(':')
      if (int(a,16),int(b,16),int(c))==identity:record['locks'].append(line)
   record['relatedFileMetadata']={}
   for suffix in ['-journal','-wal','-shm']:
    p=Path(str(db)+suffix)
    if p.exists():
     x=p.stat();record['relatedFileMetadata'][suffix]={'bytes':x.st_size,'modifiedNs':x.st_mtime_ns,'inode':x.st_ino}
   key=(stat.st_mtime_ns,stat.st_size)
   if last.get(str(db))!=key and stat.st_size<=1048576:
    data=db.read_bytes();record['copiedSnapshot']={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'atomic':False,'limitation':'Raw file copy can overlap a writer; queried only after copying into an in-memory SQLite database. No live SQLite read transaction, DB connection or PRAGMA is opened. Observations are diagnostic, not authoritative committed rows.'}
    try:
     connection=sqlite3.connect(':memory:');connection.deserialize(data);connection.execute('PRAGMA query_only=ON');rows=connection.execute('SELECT app_id,address,last_update,unixepoch(CURRENT_TIMESTAMP)-last_update FROM hosts ORDER BY app_id,address').fetchall();connection.close()
     record['copiedSnapshot']['hostMetadata']=[{'appId':r[0],'address':r[1],'lastUpdateUnixSeconds':r[2],'observedAgeSeconds':r[3]} for r in rows]
    except sqlite3.Error as e:record['copiedSnapshot']['queryError']=str(e)
    last[str(db)]=key
  except (OSError,sqlite3.Error) as e:record['observationError']=str(e)
  append(record)
 time.sleep(.5)
