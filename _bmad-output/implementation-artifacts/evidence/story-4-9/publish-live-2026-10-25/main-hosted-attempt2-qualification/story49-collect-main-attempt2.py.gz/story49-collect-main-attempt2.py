"""Collect one completed hosted attempt without overwriting any older same-name artifact."""
from pathlib import Path
import datetime,hashlib,json,stat,subprocess,sys,zipfile
repo='Hexalith/Hexalith.Works';run_id=40231871761;attempt=2;expected='eb044d9e54e0c89b5eb320be6474fe7f264348c1';out=Path(sys.argv[1]);assert not out.exists()
def api(path):
 r=subprocess.run(['gh','api',path],capture_output=True);assert r.returncode==0,r.stderr.decode();return r.stdout
def when(s):return datetime.datetime.fromisoformat(s.replace('Z','+00:00'))
run_bytes=api(f'repos/{repo}/actions/runs/{run_id}/attempts/{attempt}');run=json.loads(run_bytes);assert run['run_attempt']==attempt and run['head_sha']==expected
if run['status']!='completed':raise SystemExit('Attempt2 still active; no output created or artifact downloaded')
job_bytes=api(f'repos/{repo}/actions/runs/{run_id}/attempts/{attempt}/jobs?per_page=100');jobs=json.loads(job_bytes);selected=[j for j in jobs['jobs'] if j['name']=='Platform R1–R11 parity and rollback'];assert len(selected)==1;job=selected[0];assert job['status']=='completed';start=when(job['started_at']);finish=when(job['completed_at'])
artifact_bytes=api(f'repos/{repo}/actions/runs/{run_id}/artifacts?per_page=100');artifacts=json.loads(artifact_bytes);assert artifacts['total_count']<=100
candidates=[a for a in artifacts['artifacts'] if a['name']=='works-platform-parity' and start<=when(a['created_at'])<=finish];assert len(candidates)==1,[(a['id'],a['name'],a['created_at']) for a in artifacts['artifacts']];chosen=candidates[0];assert chosen['workflow_run']['id']==run_id and chosen['workflow_run']['head_sha']==expected;assert not chosen['expired']
out.mkdir();(out/'workflow-attempt2.json').write_bytes(run_bytes);(out/'jobs-attempt2.json').write_bytes(job_bytes);(out/'artifacts-all-attempts.json').write_bytes(artifact_bytes)
archive=api(chosen['archive_download_url'].removeprefix('https://api.github.com/'));digest=hashlib.sha256(archive).hexdigest();name=f"artifact-{chosen['id']}-works-platform-parity.zip";archive_path=out/name;archive_path.write_bytes(archive);assert zipfile.is_zipfile(archive_path)
if chosen.get('digest'):assert chosen['digest']=='sha256:'+digest,('Artifact service digest mismatch',chosen['digest'],digest)
log=api(f'repos/{repo}/actions/runs/{run_id}/attempts/{attempt}/logs');log_path=out/'workflow-attempt2-logs.zip';log_path.write_bytes(log);assert zipfile.is_zipfile(log_path)
artifact=out/f"artifact-{chosen['id']}-works-platform-parity";artifact.mkdir()
with zipfile.ZipFile(archive_path) as z:
 for entry in z.infolist():
  p=Path(entry.filename);assert not p.is_absolute() and '..' not in p.parts and not stat.S_ISLNK(entry.external_attr>>16)
 z.extractall(artifact)
ledger=artifact/'gate/ledger.json';d=json.loads(ledger.read_text());assert d['worksConsumerSource']['commit']==expected
with zipfile.ZipFile(log_path) as z:
 names=[n for n in z.namelist() if '/' not in n and 'Platform R1' in n];assert len(names)==1;data=z.read(names[0]);lines=data.decode().splitlines();idx=next(i for i,l in enumerate(lines) if 'git log -1 --format=%H' in l);assert lines[idx+1].endswith(expected);checkout={'entry':names[0],'sha256':hashlib.sha256(data).hexdigest(),'lines':lines[idx:idx+2]}
record={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'workflowRun':run_id,'attempt':attempt,'head':expected,'workflowConclusion':run['conclusion'],'selectedJob':{'id':job['id'],'startedAt':job['started_at'],'completedAt':job['completed_at'],'conclusion':job['conclusion']},'selectedArtifact':chosen,'selection':'Exact name, exact run/head, nonexpired and created within this attempt2 parity job interval; exactly one candidate required','archivePath':str(archive_path),'archiveSha256':digest,'artifactDirectory':str(artifact),'ledgerSha256':hashlib.sha256(ledger.read_bytes()).hexdigest(),'actualCheckout':checkout,'otherArtifactsNotOverwritten':[{'id':a['id'],'name':a['name'],'createdAt':a['created_at']} for a in artifacts['artifacts'] if a['id']!=chosen['id']],'attempt1PreservedSeparately':'/tmp/story49-parent-hosted-main-eb044'}
(out/'attempt-artifact-binding.json').write_text(json.dumps(record,indent=2)+'\n')
files=[{'path':str(p.relative_to(out)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(out.rglob('*')) if p.is_file()];(out/'download-inventory.json').write_text(json.dumps(files,indent=2)+'\n');print('Collected attempt2 artifact',chosen['id'],'conclusion',run['conclusion'],'actual checkout',expected)
if run['conclusion']!='success':raise SystemExit(1)
cmd=['python3','/tmp/story49-audit-hosted-qualification.py',str(artifact),str(out/'acceptance-audit-full-hosted-main-attempt2.json')];r=subprocess.run(cmd,capture_output=True);(out/'audit.stdout').write_bytes(r.stdout);(out/'audit.stderr').write_bytes(r.stderr);(out/'audit-command.json').write_text(json.dumps({'command':cmd,'exitCode':r.returncode,'helperSha256':hashlib.sha256(Path(cmd[1]).read_bytes()).hexdigest()},indent=2)+'\n');print('Acceptance audit exit',r.returncode);raise SystemExit(r.returncode)
