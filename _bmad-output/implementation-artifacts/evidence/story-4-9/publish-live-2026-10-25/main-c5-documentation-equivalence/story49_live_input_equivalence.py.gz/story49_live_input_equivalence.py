"""Reuse a validated live proof only for the exact independently reviewed documentation advance."""
import hashlib,json,subprocess
from pathlib import Path

OWNER=Path('/home/administrator/projects/hexalith/works/references/Hexalith.EventStore')
EVIDENCE=Path('/tmp/story49-main-c5-docs')
PAIR=('b65d90fade545ecacc5263021c1d3e1bf0320f4e','c5d1c280d8c1c1a207cd159d817f614e93c93130')
DOCS={'_bmad-output/implementation-artifacts/2-13-dapr-notification-distribution-qualification.md','_bmad-output/implementation-artifacts/spec-2-13-dapr-notification-distribution-qualification.md'}

def reviewed_documentation_equivalence(pr_head,current_main):
    if (pr_head,current_main)!=PAIR:
        return None
    record=json.loads((EVIDENCE/'provenance.json').read_text())
    commands=json.loads((EVIDENCE/'live-preparation-commands.json').read_text())
    assert record['runtimeDocsNotConsumed'] and record['repoWideGuardsRerun']
    assert len(commands)==3 and all(x['exitCode']==0 for x in commands)
    def inventory(revision):
        result={}
        for line in subprocess.check_output(['git','ls-tree','-r','--full-tree',revision],cwd=OWNER,text=True).splitlines():
            metadata,name=line.split('\t',1)
            if name not in DOCS:
                result[name]=metadata
        return result
    prior=inventory(pr_head);current=inventory(current_main)
    assert prior==current, 'Reviewed documentation advance has different executable/dependency inputs'
    digest=hashlib.sha256(json.dumps(current,sort_keys=True).encode()).hexdigest()
    assert digest==record['unchangedInventorySha256'] and len(current)==record['unchangedEntries']
    return {'validatedPrHead':pr_head,'currentMain':current_main,'ignoredExactDocumentationPaths':sorted(DOCS),'unchangedEntries':len(current),'unchangedInventorySha256':digest,'runtimeDocsNotConsumed':True,'currentRepositoryGuardsPassed':True,'proof':'Passing PR live result reused only for this exact reviewed documentation-only advance; every other tracked blob, mode and gitlink is identical.'}
