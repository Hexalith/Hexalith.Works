import datetime,json,subprocess,time
from pathlib import Path
from story49_live_input_equivalence import reviewed_documentation_equivalence
base='repos/Hexalith/Hexalith.EventStore/'
required=('advisory','ci / build-and-test','ci / tenants-source-mode','codeql / analyze','commitlint / commitlint','dependency-review / dependency-review','live-sidecar')
def api(path,*args):return json.loads(subprocess.check_output(['gh','api',base+path,*args],text=True))
def runs(workflow,head,event):
 values=api('actions/workflows/'+workflow+'/runs','--method','GET','-f','head_sha='+head,'-f','event='+event,'-f','per_page=30')['workflow_runs']
 return [{'id':x['id'],'status':x['status'],'conclusion':x['conclusion']} for x in values if x['head_sha']==head and x['event']==event]
def checks(head,names):
 values=api('commits/'+head+'/check-runs','--method','GET','-f','per_page=100')['check_runs']
 return {name:next(({'id':x['id'],'status':x['status'],'conclusion':x['conclusion']} for x in sorted(values,key=lambda c:c['id'],reverse=True) if x['name']==name),None) for name in names}
def ok(x):return x and x['status']=='completed' and x['conclusion']=='success'
prior=None
while True:
 pr=api('pulls/375');head=api('git/ref/heads/main')['object']['sha']
 pr_checks=checks(pr['head']['sha'],required)
 main_checks=checks(head,[x for x in required if x!='dependency-review / dependency-review'])
 trees={'pr':api('git/commits/'+pr['head']['sha'])['tree']['sha'],'main':api('git/commits/'+head)['tree']['sha']}
 identical=trees['pr']==trees['main']
 documented_equivalence=reviewed_documentation_equivalence(pr['head']['sha'],head)
 reuse_pr_live=identical or documented_equivalence is not None
 pr_ci=runs('ci.yml',pr['head']['sha'],'pull_request')
 proofs={workflow:runs(workflow,head,'push') for workflow in ('ci.yml','commitlint.yml')}
 data={'main':head,'prHead':pr['head']['sha'],'prMerged':pr['merged'],'prRequired':pr_checks,'currentMainRequired':main_checks,'prCi':pr_ci,'mainProofs':proofs,'gitTrees':trees,'sameValidatedPrTree':identical,'reviewedDocumentationEquivalence':documented_equivalence,'reuseValidatedPrLiveProof':reuse_pr_live,'requireSeparateMainLive':not reuse_pr_live}
 summary=json.dumps(data,sort_keys=True)
 if summary!=prior:
  data['observedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
  with Path('/tmp/story49-publication-proof-monitor-pr375.jsonl').open('a') as f:f.write(json.dumps(data)+'\n')
  print(json.dumps(data),flush=True);prior=summary
 failures=[x for x in [*pr_checks.values(),*main_checks.values(),*(v[0] if v else None for v in [pr_ci,*proofs.values()])] if x and x['status']=='completed' and x['conclusion'] in ('failure','timed_out','action_required')]
 if failures:raise SystemExit('Required proof failed; investigate before publication: '+json.dumps(failures))
 if pr['merged'] and all(ok(x) for x in pr_checks.values()) and any(ok(x) for x in pr_ci) and all(any(ok(x) for x in v) for v in proofs.values()) and (reuse_pr_live or all(ok(x) for x in main_checks.values())):
  assert api('compare/'+pr['merge_commit_sha']+'...'+head)['status'] in ('identical','ahead')
  Path('/tmp/story49-publication-ready-pr375.json').write_text(json.dumps(data,indent=2)+'\n')
  print('Required publication proofs passed; exact PR/main tree comparison recorded; no release dispatched.',flush=True);break
 time.sleep(40)
