import datetime,json,subprocess,time,sys
from pathlib import Path
from story49_live_input_equivalence import reviewed_documentation_equivalence
repo='Hexalith/Hexalith.EventStore'
base='repos/'+repo+'/'
out=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/tmp/story49-release-dispatch')
def api(path,*args):return json.loads(subprocess.check_output(['gh','api',base+path,*args],text=True))
required=('advisory','ci / build-and-test','ci / tenants-source-mode','codeql / analyze','commitlint / commitlint','dependency-review / dependency-review','live-sidecar')
ready=json.loads(Path('/tmp/story49-publication-ready-pr375.json').read_text())
head=api('git/ref/heads/main')['object']['sha']
assert ready['main']==head,'Main advanced; wait for fresh exact-main proofs'
pr=api('pulls/375');assert pr['state']=='closed' and pr['merged']
checks=api('commits/'+pr['head']['sha']+'/check-runs','--method','GET','-f','per_page=100')['check_runs']
selected={name:next(x for x in sorted(checks,key=lambda c:c['id'],reverse=True) if x['name']==name) for name in required}
assert all(x['status']=='completed' and x['conclusion']=='success' for x in selected.values())
main_checks=api('commits/'+head+'/check-runs','--method','GET','-f','per_page=100')['check_runs']
main_selected={name:next(x for x in sorted(main_checks,key=lambda c:c['id'],reverse=True) if x['name']==name) for name in required if name!='dependency-review / dependency-review'}
assert not any(x['status']=='completed' and x['conclusion'] in ('failure','timed_out','action_required') for x in main_selected.values()), 'A current-main required check failed'
trees={'pr':api('git/commits/'+pr['head']['sha'])['tree']['sha'],'main':api('git/commits/'+head)['tree']['sha']}
documented_equivalence=reviewed_documentation_equivalence(pr['head']['sha'],head)
assert trees['pr']==trees['main'] or documented_equivalence is not None or all(x['status']=='completed' and x['conclusion']=='success' for x in main_selected.values()), 'Additional source-tree advance needs current required proofs including live-sidecar'
proofs={}
for workflow in ('ci.yml','commitlint.yml'):
 runs=api('actions/workflows/'+workflow+'/runs','--method','GET','-f','branch=main','-f','event=push','-f','head_sha='+head,'-f','per_page=100')['workflow_runs']
 good=[x for x in runs if x['head_sha']==head and x['head_branch']=='main' and x['event']=='push' and x['status']=='completed' and x['conclusion']=='success']
 assert good,(workflow,'Exact-main proof missing')
 proofs[workflow]=good[0]
assert api('compare/'+pr['merge_commit_sha']+'...'+head)['status'] in ('identical','ahead')
releases=api('actions/workflows/release.yml/runs','--method','GET','-f','per_page=30')['workflow_runs']
assert all(x['status']=='completed' for x in releases),'Existing release is active; do not duplicate'
assert api('actions/variables/HEXALITH_RELEASE_PUBLISH_ENABLED')['value']=='true'
environment=api('environments/production')
assert api('git/ref/heads/main')['object']['sha']==head,'Main advanced during proof audit'
out.mkdir(exist_ok=False)
record={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':head,'pullRequest':375,'requiredChecks':selected,'currentMainRequiredChecks':main_selected,'gitTrees':trees,'sameValidatedPrTree':trees['pr']==trees['main'],'reviewedDocumentationEquivalence':documented_equivalence,'mainProofs':proofs,'productionEnvironment':environment,'priorReleaseRuns':[{'id':x['id'],'status':x['status'],'head_sha':x['head_sha']} for x in releases]}
(out/'preflight.json').write_text(json.dumps(record,indent=2)+'\n')
result=subprocess.run(['gh','workflow','run','release.yml','--repo',repo,'--ref','main'],capture_output=True,text=True)
(out/'dispatch.json').write_text(json.dumps({'command':result.args,'exitCode':result.returncode,'stdout':result.stdout,'stderr':result.stderr},indent=2)+'\n')
assert result.returncode==0,result.stderr
prior={x['id'] for x in releases}
for _ in range(20):
 current=api('actions/workflows/release.yml/runs','--method','GET','-f','per_page=10')['workflow_runs']
 created=[x for x in current if x['id'] not in prior and x['event']=='workflow_dispatch']
 if created:
  (out/'created-runs.json').write_text(json.dumps(created,indent=2)+'\n')
  print(json.dumps([{'id':x['id'],'source':x['head_sha'],'status':x['status'],'url':x['html_url']} for x in created],indent=2));break
 time.sleep(3)
else:raise SystemExit('Dispatch returned success; run is not yet visible. Inspect before any retry.')
