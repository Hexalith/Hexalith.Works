import hashlib,json,sys,xml.etree.ElementTree as E
from pathlib import Path
base=Path('/tmp/story49-final-public-3.128.0-qualification-retry2'); root=Path('/home/administrator/projects/hexalith/works')
profiles=sys.argv[1:] or ['full','ci']; assert profiles==['full','ci']; profile_roots={'full':base/'full','ci':base/'ci-retry1'}; prefix='Hexalith.Works.IntegrationTests.'
methods={k:prefix+v for k,v in {'callback':'WorksSdkRecoveryPipelineSmokeTests.SuccessfulCallbacksRegisterSdkReminderAndProcessWithoutPeriodicRecovery','recovery':'WorksSdkRecoveryPipelineSmokeTests.SdkRemindersAndCascadeConvergeThroughPersistedReceiptsAcrossRestart','historical':'WorksPlatformHistoricalPipelineSmokeTests.PlatformLifecycleTreeClaimFilteringAndSecuritySurviveRestart','ha':'WorksPlatformHaPipelineSmokeTests.TwoWorksHostsRecoverLostFiringAfterPrimaryStopsWithoutDuplicateEffect','projection':'WorksPlatformProjectionPipelineSmokeTests.ActualPlatformSharedRebuildAndConcurrentCatchUpPreserveCompleteFamily','mtls':'WorksMtlsAuthorizationSmokeTests.Mtls_allows_event_store_and_denies_an_unauthorized_caller_at_works_process','retained':'WorksPlatformRetainedHostPreflightTests.ArchivedTopologyReachesHealthyReadiness'}.items()}
PHASE_METHOD = {'periodic-writers-disabled-readiness-degraded': 'callback', 'successful-callback-no-periodic-recovery': 'callback', 'disabled-recovery-otlp-alert-export': 'callback', 'callback-protected-scoped-disposition-audit-before-mutation': 'callback', 'platform-sdk-named-mode-legacy-route-refused': 'callback', 'platform-named-conflict-durable-quarantine-with-unchanged-family': 'callback', 'rescheduled-expiry-committed-current-witness': 'recovery', 'cascade-expiry-target-commit-before-checkpoint': 'recovery', 'cascade-expiry-restart-receipt-and-checkpoint': 'recovery', 'concurrent-sdk-reminder-reissue-after-lost-scheduler-wakeup': 'recovery', 'canonical-related-child-creation-gap': 'recovery', 'cascade-target-commit-before-checkpoint': 'recovery', 'five-child-persisted-target-receipts': 'recovery', 'cascade-restart-receipt-and-checkpoint': 'recovery', 'child-resume-noop-receipt-before-checkpoint': 'recovery', 'paged-process-candidates-pre-restart': 'recovery', 'complete-supported-process-coverage': 'recovery', 'child-resume-noop-restart-receipt-and-checkpoint': 'recovery', 'paged-process-restart-and-shared-store-owner-fencing': 'recovery', 'protected-scoped-disposition-audit-before-mutation': 'recovery', 'platform-initial-projection-convergence': 'recovery', 'platform-named-redelivery-capture-through-commit-complete-family': 'recovery', 'platform-query-and-explicit-receipt-replay': 'recovery', 'durable-recovery-alert-export-and-clear': 'recovery', 'complete-platform-fleet-snapshot': 'recovery', 'complete-restore-retained-host-query-and-receipt-replay': 'recovery', 'platform-executor-filtering-and-origin-tenant-publish-refusals': 'historical', 'platform-historical-lifecycle-tree-concurrent-claim-persisted': 'historical', 'platform-historical-restart-replay-and-family': 'historical', 'platform-two-host-ha-lost-firing-stale-callback-recovery': 'ha', 'platform-focused-initial-projection-convergence': 'projection', 'platform-focused-projection-rebuild': 'projection'}

def owner(phase):
 if phase not in PHASE_METHOD:raise ValueError("Unknown persisted phase has no explicit test owner: "+phase)
 return methods[PHASE_METHOD[phase]]
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def normalized_paths(d,profile):
 return {k.replace(str(profile_roots[profile]/'workspace/platform'),'<platform-export>'):v for k,v in d.items()}
lanes={};inputs={}
for profile in profiles:
 gate=profile_roots[profile]/'gate'; ledger_path=gate/'ledger.json'; d=json.loads(ledger_path.read_text())
 assert d['status']=='passed-disposable-synthetic-parity-and-rollback'
 assert d['profile']['name']==profile
 assert d['profile']['consumerConfigurations']==(['Debug','Release'] if profile=='full' else ['Release'])
 assert d['selectedSdk']['version']=='3.128.0'
 assert set(d['rows'])=={f'R{i}' for i in range(1,12)}
 assert d['rollback']['complete']
 persisted=[json.loads(x) for x in (gate/'persisted-states.jsonl').read_text().splitlines() if x]
 observed_phases=[x['phase'] for x in persisted]
 assert len(observed_phases)==len(set(observed_phases)), 'Duplicate persisted phases'
 assert set(observed_phases)==set(PHASE_METHOD), {'unknown':sorted(set(observed_phases)-set(PHASE_METHOD)), 'missing':sorted(set(PHASE_METHOD)-set(observed_phases))}
 inventories=[];tests={}
 for p in sorted(gate.glob('*.xml')):
  document=E.parse(p); assemblies=document.findall('assembly');assert assemblies,p
  for a in assemblies:
   assert all(int(a.get(k,'0'))==0 for k in ['failed','errors','skipped','not-run']),p
  entries=[{'name':t.get('name'),'method':t.get('type')+'.'+t.get('method'),'outcome':t.get('result')} for t in document.findall('.//test')]
  assert entries,p
  assert all(t['outcome']=='Pass' for t in entries),p
  for t in entries:tests[t['method']]=str(p.relative_to(base))
  inventories.append({'path':str(p.relative_to(base)),'sha256':digest(p),'assemblies':[dict(a.attrib) for a in assemblies],'tests':entries})
 assert set(methods.values()).issubset(tests),set(methods.values())-set(tests)
 rows={}
 for row,x in d['rows'].items():
  assert x['status']=='passed',row
  assert set(x['requiredProofs'])=={'persisted','negative','restart','rollback'}
  proofs={}
  for proof,e in x['requiredProofs'].items():
   assert e['passed'],(row,proof);facts=[]
   for state in e['evidence']:
    method=owner(state['phase']);assert method in tests,method
    facts.append({'test':method,'resultXml':tests[method],'phase':state['phase'],'persistedRecordSha256':state['recordSha256'],'assertedFields':state['fields']})
   assert facts,(row,proof)
   proofs[proof]=facts
  rows[row]={'title':x['title'],'producer':x['producer'],'consumer':x['consumer'],'consumerSha256':x['consumerSha256'],'proofs':proofs}
 inputs[profile]={'works':d['worksConsumerSource']['sourceFiles'],'platform':d['platformSourceSnapshot']['sourceFiles'],'platformRelevant':d['platformSourceSnapshot']['currentRelevantSourceFiles'],'dependencyInputs':d['platformSourceSnapshot']['dependencyInputs'],'fixtures':d['fixtureSources'],'linkedFixtures':normalized_paths(d['linkedFixtureSources']['sourceFiles'],profile),'canonicalWorks':d['canonicalSources']['Works']['sourceFiles'],'canonicalPlatform':d['canonicalSources']['Platform']['sourceFiles'],'verifierSha256':d['verifierSha256'],'verifierHelpers':d['verifierHelpers']}
 ordinary=json.loads(Path('/tmp/story49-final-consumer-ordinary/commands.json').read_text())
 exclusions=next(x['nonpassing'] for x in ordinary if x['name']=='integration')
 assert len(exclusions)==7 and all(x['result']=='NotRun' and x['name'] in tests for x in exclusions)
 lanes[profile]={'ledger':str(ledger_path.relative_to(base)),'ledgerSha256':digest(ledger_path),'profile':d['profile'],'rows':rows,'rollback':d['rollback'],'actualFleetStarts':len(d['actualStarts']),'retainedPreflightStarts':len(d['retainedPreflightStarts']),'persistedRecords':sum(bool(x) for x in (gate/'persisted-states.jsonl').read_text().splitlines()),'testInventories':inventories,'ordinaryExplicitExclusionsMatchedToPassingLiveFacts':exclusions,'agentsFull':'expected-unavailable; never credited as Works prerequisite or parity'}
if len(profiles)==2:
 assert inputs['full']==inputs['ci'],[k for k in inputs['full'] if inputs['full'][k]!=inputs['ci'][k]]
result={'scope':'11 AD-20 rows and 44 proof kinds in each complete profile; named executed facts and exact persisted records. Synthetic disposable qualification only.','profiles':lanes,'sameBoundInputMembershipAndBytesAcrossProfiles':len(profiles)==2,'inputInventorySizes':{p:{k:len(v) if isinstance(v,dict) else v for k,v in x.items()} for p,x in inputs.items()},'frozenScenarios':{'Migration gate':'canonical refusal controls and separately bound retained preflight; no incomplete gate accepted','Shared rebuild':{'tests':[methods['projection'],methods['recovery']],'rows':['R3','R4','R9']},'Redelivery/restart':{'tests':[methods['recovery'],methods['ha']],'rows':['R3','R6','R7','R9','R11']},'Unauthorized request':{'tests':[methods['historical'],methods['mtls'],methods['recovery']],'rows':['R5','R8','R10','R11'],'assertionsAndHttpReadinessDeadlinesUnchanged':True}}}
phase_attribution={}
for phase,key in PHASE_METHOD.items():
 locations=[]
 for source in sorted((root/'tests/Hexalith.Works.IntegrationTests').glob('*.cs')):
  for line,text in enumerate(source.read_text().splitlines(),1):
   if '"'+phase+'"' in text:locations.append({'source':str(source.relative_to(root)),'line':line,'sourceSha256':digest(source)})
 assert locations, 'Phase literal lacks source provenance: '+phase
 attribution={'test':methods[key],'sourceLocations':locations}
 if key in ('callback','recovery'):
  folder='callback' if key=='callback' else 'restart';focus=Path('/tmp/story49-final-'+folder+'-native-diagnostic');stream=focus/'persisted-states.jsonl';command=focus/'command.json';data=json.loads(command.read_text())
  assert data['exitCode']==0 and methods[key] in data['command']
  assert phase in [json.loads(x)['phase'] for x in stream.read_text().splitlines()]
  attribution['focusedOwnershipEvidence']={'stream':str(stream),'streamSha256':digest(stream),'command':str(command),'commandSha256':digest(command),'singleExecutedMethod':methods[key]}
 else:
  expected_file=key_to_source={'historical':'WorksPlatformHistoricalPipelineSmokeTests.cs','ha':'WorksPlatformHaPipelineSmokeTests.cs','projection':'WorksPlatformProjectionPipelineSmokeTests.cs'}
  assert any(x['source'].endswith(key_to_source[key]) for x in locations)
 phase_attribution[phase]=attribution
result['explicitPhaseToMethodAttribution']=phase_attribution
result['unknownPhasePolicy']='Refuse; every one of the32 emitted phases has explicit source/test ownership'
def migration_refusals(profile):
 import subprocess,re
 gate=profile_roots[profile]/'gate';ledger=json.loads((gate/'ledger.json').read_text())
 command=next(c for c in ledger['commands'] if c['name']=='evidence-gate-tests')
 assert command['exitCode']==0 and command['command'][:3]==['python3','-m','unittest']
 log=gate/command['log'];assert digest(log)==command['sha256']
 ran=re.search(r'\nRan (\d+) tests in [^\n]+\n\nOK\s*$',log.read_text());assert ran, 'Complete passing unittest summary required'
 loader_source='''import hashlib,inspect,json,unittest,sys
suite=unittest.defaultTestLoader.loadTestsFromNames(sys.argv[1:])
def flatten(suite):
 for item in suite:
  if isinstance(item,unittest.TestSuite):yield from flatten(item)
  else:yield item
result=[]
for test in flatten(suite):
 method=getattr(type(test),test._testMethodName);source=inspect.getsourcefile(method);lines,line=inspect.getsourcelines(method)
 with open(source,'rb') as f:source_hash=hashlib.sha256(f.read()).hexdigest()
 result.append({'id':test.id(),'source':source,'sourceSha256':source_hash,'line':line,'methodSourceSha256':hashlib.sha256(''.join(lines).encode()).hexdigest(),'declaredSkipped':bool(getattr(type(test),'__unittest_skip__',False) or getattr(method,'__unittest_skip__',False))})
print(json.dumps(result,indent=2))
'''
 loader_command=['python3','-c',loader_source,*command['command'][3:]]
 inventory_output=subprocess.check_output(loader_command,cwd=command['cwd'])
 inventory=json.loads(inventory_output);assert len(inventory)==int(ran.group(1))==151
 assert len({x['id'] for x in inventory})==len(inventory) and not any(x['declaredSkipped'] for x in inventory)
 inventory_path=base/('migration-refusal-full-ci-retry1-'+profile+'-unittest-inventory.json');inventory_path.write_bytes(inventory_output)
 loader_path=base/('migration-refusal-full-ci-retry1-'+profile+'-unittest-inventory-command.json');loader_path.write_text(json.dumps({'command':loader_command,'cwd':command['cwd'],'exitCode':0,'purpose':'Enumerate unchanged exact unittest modules; no tests re-executed and no diagnostic execution counted as acceptance','output':str(inventory_path),'outputSha256':digest(inventory_path)},indent=2)+'\n')
 selected={
 'test_verify_works_host.WorksEvidenceGateTests.test_skipped_failed_error_and_not_run_counts_are_refused':'Each skipped, failed, error and not-run count raises ValueError.',
 'test_verify_works_host.WorksEvidenceGateTests.test_empty_filtered_or_nonpassing_execution_is_refused':'Empty execution, nonpassing facts and missing required methods raise ValueError.',
 'test_verify_works_host.WorksEvidenceGateTests.test_duplicate_missing_or_unbound_phases_cannot_accept_rows':'Every missing required phase, duplicate phase, missing retained restore start and malformed state raises ValueError.',
 'test_verify_works_host.WorksEvidenceGateTests.test_retained_startup_preflight_cannot_supply_platform_or_rollback_parity':'Retained readiness alone cannot be credited as target parity or complete rollback.',
 'test_verify_works_host.WorksEvidenceGateTests.test_focused_projection_rebuild_is_a_required_r4_outcome':'Missing focused projection rebuild refuses R4 acceptance.',
 'test_works_verifier_inputs.FinalInputClosureTests.test_works_source_bytes_membership_and_revision_are_rechecked':'Changed Works source bytes, membership or revision refuses final closure.',
 'test_works_verifier_inputs.FinalInputClosureTests.test_every_artifact_family_is_rechecked':'Changed runtime or adapter artifact refuses final closure.',
 'test_works_verifier_inputs.FinalInputClosureTests.test_retained_topology_sources_are_rechecked':'Changed archived topology refuses final closure.',
 'test_works_verifier_inputs.FinalInputClosureTests.test_snapshot_verification_failure_is_preserved':'Canonical snapshot verification failure propagates instead of accepting the ledger.'}
 named=[]
 for test_id,expectation in selected.items():
  entry=next(x for x in inventory if x['id']==test_id)
  assert entry['sourceSha256']==digest(Path(entry['source']))
  named.append({**entry,'assertedRefusal':expectation})
 retained_xml=next(x for x in lanes[profile]['testInventories'] if any(t['method']==methods['retained'] for t in x['tests']))
 return {'executedCommand':command,'executedOutput':str(log),'executedOutputSha256':digest(log),'fullModuleInventory':str(inventory_path),'fullModuleInventorySha256':digest(inventory_path),'inventoryCommand':str(loader_path),'inventoryCommandSha256':digest(loader_path),'executionBasis':'Exact full unittest module command exited zero; final summary has 151 tests and OK without skips; unchanged loader inventory has exactly the same 151 unique non-skipped facts. Named selected facts therefore executed in that command.','namedRefusalFacts':named,'retainedReadiness':{'test':methods['retained'],'resultXml':retained_xml['path'],'resultSha256':retained_xml['sha256'],'source':'tests/Hexalith.Works.IntegrationTests/WorksPlatformRetainedHostPreflightTests.cs','sourceSha256':digest(root/'tests/Hexalith.Works.IntegrationTests/WorksPlatformRetainedHostPreflightTests.cs')},'historicalCutoverAcceptanceUnchanged':True}
result['frozenScenarios']['Migration gate']={'requirement':'Incomplete rows/lanes/closure cannot qualify; independently executed retained topology remains usable.','profiles':{profile:migration_refusals(profile) for profile in profiles}}

result['profileArtifactRoots']={k:str(v) for k,v in profile_roots.items()}; result['failedCiAttemptPreservedWithoutCredit']=str(base/'ci');out=base/'acceptance-audit-full-ci-retry1.json';assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n');print(out,'profiles',len(lanes),'rows',sum(len(x['rows']) for x in lanes.values()))
