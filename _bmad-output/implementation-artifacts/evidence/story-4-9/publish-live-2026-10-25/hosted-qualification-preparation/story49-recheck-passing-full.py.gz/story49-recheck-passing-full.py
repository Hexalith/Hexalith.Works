import datetime,hashlib,json,sys
from pathlib import Path
base=Path('/tmp/story49-final-public-3.128.0-qualification-retry2');path=base/'full/gate/ledger.json';d=json.loads(path.read_text());assert d['status']=='passed-disposable-synthetic-parity-and-rollback'
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
original=digest(path);platform=Path(d['platformSourceSnapshot']['root']);sys.path.insert(0,str(platform/'eng'));import verify_works_host as verifier
selection=d['controlPlanePortSelection'];verifier.require_unchanged_inputs(d,Path(d['worksConsumerSource']['root']),platform,Path(d['platformSourceSnapshot']['manifest']),tuple(selection['excludedEphemeralRange']),tuple(tuple(x) for x in selection['excludedReservedRanges']))
assert digest(path)==original
record={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':['python3',str(Path(__file__))],'result':'original canonical final-input closure re-executed successfully against passing full ledger','ledger':str(path),'ledgerSha256':original,'ledgerBytesUnmodified':True,'verifierSource':str(platform/'eng/verify_works_host.py'),'verifierSha256':digest(platform/'eng/verify_works_host.py'),'runtimeArtifactCount':len(d['runtimeArtifacts']),'worksCanonicalInputCount':len(d['canonicalSources']['Works']['sourceFiles']),'allRequiredSourceRuntimeArchiveLauncherInputMembershipAndBytesRechecked':True}
out=Path(sys.argv[1]);out.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
