import hashlib,json,re,sys
from pathlib import Path
base=Path('/tmp/story49-final-public-3.128.0-qualification-retry2')
out=Path(sys.argv[1]);out.mkdir(exist_ok=False);records=[]
patterns=[('private-key',re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----.*?-----END (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',re.S)),('jwt',re.compile(rb'eyJ[A-Za-z0-9_-]{12,}\.[A-Za-z0-9_-]{12,}\.[A-Za-z0-9_-]{12,}')),('credential-assignment',re.compile(rb'(?i)(?:DAPR_API_TOKEN|APP_API_TOKEN|DAPR_APP_API_TOKEN|SigningKey|Password|ClientSecret|PrivateKey)\s*["\x27]?\s*[:=]\s*["\x27]?[^\s,"\x27}]{8,}')),('bearer-credential',re.compile(rb'(?i)Authorization\s*:\s*Bearer\s+[^\s,"\x27}]{8,}'))]
def retain(source,target):
 data=source.read_bytes();original=hashlib.sha256(data).hexdigest();redactions=[]
 for kind,pattern in patterns:
  def replace(m):
   digest=hashlib.sha256(m.group()).hexdigest();redactions.append({'kind':kind,'matchedSha256':digest,'bytes':len(m.group())});return ('[REDACTED '+kind+' '+digest+']').encode()
  data=pattern.sub(replace,data)
 target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data);records.append({'source':str(source),'path':str(target.relative_to(out)),'originalSnapshotSha256':original,'retainedSha256':hashlib.sha256(data).hexdigest(),'originalBytes':source.stat().st_size,'retainedBytes':len(data),'redactions':redactions})
for profile in ['ci-retry1']:
 source=base/(profile+'-observations');target=out/profile
 process=json.loads((base/(profile+'-process.json')).read_text());assert process['state']=='completed',profile
 for p in source.iterdir():
  if p.is_file() and p.name!='stop-native-observer':retain(p,target/p.name)
 for session in (source/'raw-native').glob('*'):
  selected=set()
  for p in session.glob('resource-executable-*.log'):
   if re.search(rb'"Executable":\s*"/(?:works(?:-ha)?|eventstore(?:-admin|-operations)?)-dapr-cli-',p.read_bytes()):
    selected.add(p);uid=p.name[len('resource-executable-'):-len('.log')];selected.update(session.glob(uid+'_out*'));selected.update(session.glob(uid+'_err*'))
  for p in session.iterdir():
   if p.name.startswith(('dapr-sentry-','dapr-placement-mtls-','dapr-scheduler-mtls-')) and p.is_file():selected.add(p)
   elif p.name.startswith('resource-service-') and any(x in p.read_bytes() for x in [b'dapr-sentry-health', b'dapr-scheduler-mtls-health']):selected.add(p)
  for p in sorted(selected):retain(p,target/'native-selected'/session.name/p.name)
summary={'scope':'Observational metadata for failed second local actual CI; Scheduler readiness failure is retained and receives no acceptance credit. No assertion/deadline change.','nativeStreamScope':'Last observed selected sidecar/control-plane resource stream snapshots, copied while live. No claim of every final teardown line.','credentialReview':{'excluded':'kubeconfig, environment/config payloads, native controller debug payloads, application stdout, broader temporary Docker stream','patterns':[x[0] for x in patterns],'redactions':sum(len(x['redactions']) for x in records),'compressionIsNotSanitization':True},'files':records}
(out/'retention-and-redaction.json').write_text(json.dumps(summary,indent=2)+'\n');print('files',len(records),'redactions',summary['credentialReview']['redactions'],'bytes',sum(p.stat().st_size for p in out.rglob('*') if p.is_file()))
