import hashlib
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

gate = Path(sys.argv[1])
output = Path(sys.argv[2])
assert not output.exists(), output
ledger_path = gate / 'ledger.json'
ledger = json.loads(ledger_path.read_text())
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
assert ledger['status'] == 'passed-disposable-synthetic-parity-and-rollback'
assert ledger['selectedSdk']['version'] == '3.128.0'
assert ledger['rollback']['complete'] is True
records = [json.loads(line) for line in (gate / 'persisted-states.jsonl').read_text().splitlines() if line]
phases = {record['phase']: record for record in records}
assert len(records) == len(phases) == 32
assert len(ledger['actualStarts']) == 11
assert set(ledger['rows']) == {f'R{i}' for i in range(1, 12)}
tests = {}
inventories = []
passed = 0
for xml in sorted(gate.glob('*.xml')):
    root = ET.parse(xml).getroot()
    assemblies = root.findall('assembly')
    assert assemblies, xml
    for assembly in assemblies:
        assert all(int(assembly.get(key, '0')) == 0 for key in ('failed', 'errors', 'skipped', 'not-run')), xml
        passed += int(assembly.get('passed'))
    facts = root.findall('.//test')
    assert facts and all(test.get('result') == 'Pass' for test in facts), xml
    for fact in facts:
        tests.setdefault(fact.get('type') + '.' + fact.get('method'), []).append(xml.name)
    inventories.append({'path': xml.name, 'sha256': digest(xml), 'cases': len(facts)})
assert passed == (603 if ledger['profile']['name'] == 'full' else 459), passed
bindings = []
for name, row in ledger['rows'].items():
    assert row['status'] == 'passed'
    producer = row['producer']
    assert producer['version'] == '3.128.0'
    assert producer['repositoryCommit'] == 'c5d1c280d8c1c1a207cd159d817f614e93c93130'
    assert producer['source'] == 'https://api.nuget.org/v3/index.json'
    assert producer['api'] and row['consumer'] and row['consumerSha256']
    assert set(row['requiredProofs']) == {'persisted', 'negative', 'restart', 'rollback'}
    for kind, proof in row['requiredProofs'].items():
        assert proof['passed'] is True and proof['evidence']
        for evidence in proof['evidence']:
            record = phases[evidence['phase']]
            assert evidence['recordSha256'] == hashlib.sha256(json.dumps(record, sort_keys=True).encode()).hexdigest()
            assert evidence['fields']
            for field in evidence['fields']:
                value = record['state']
                if field != '<state>':
                    for part in field.split('.'):
                        value = value[int(part)] if isinstance(value, list) else value[part]
                assert value is not None, (name, kind, field)
        bindings.append({'row': name, 'kind': kind, 'phases': [e['phase'] for e in proof['evidence']]})
assert len(bindings) == 44
expected_sources = {'platform-focused-projection-rebuild': 11, 'platform-named-redelivery-capture-through-commit-complete-family': 12}
for phase, source_count in expected_sources.items():
    state = phases[phase]['state']
    concurrent = state['concurrentDelivery']
    assert concurrent['actualNewDeliveryDuringCapture'] is True
    assert concurrent['oldGenerationStayedReadable'] is True
    assert concurrent['automaticCatchUpAfterCommit'] is True
    assert concurrent['redeliveryLogicalCount'] == 1
    assert concurrent['after']['Digest'] == concurrent['expectedDigest']
    assert concurrent['after']['Generation'] > concurrent['before']['Generation']
    assert state['negatives']['wrongOrigin'] in (401, 403)
    assert state['negatives']['wrongOperation'] == 403
    assert len(state['sources']) == source_count
    assert state['after']['Digest'] == state['before']['Digest']
    assert state['after']['Generation'] > state['before']['Generation']
output.write_text(json.dumps({'ledgerSha256': digest(ledger_path), 'profile': ledger['profile'], 'worksCommit': ledger['worksConsumerSource']['commit'], 'passes': passed, 'xml': inventories, 'rows': 11, 'proofs': bindings, 'persistedPhases': 32, 'fleetStarts': 11, 'rollbackComplete': True, 'runtimeArtifacts': len(ledger['runtimeArtifacts']), 'independentConcurrentDeliveryAndSecurityAssertions': 'passed'}, indent=2) + '\n')
print(output)
