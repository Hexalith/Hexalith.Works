import hashlib,json,re,sys,xml.etree.ElementTree as E
from pathlib import Path
fullroot=Path('/tmp/story49-final-public-3.128.0-qualification-retry2/full')
full=json.loads((fullroot/'gate/ledger.json').read_text())
fullaudit=json.loads(Path('/tmp/story49-final-public-3.128.0-qualification-retry2/acceptance-audit-full.json').read_text())
artifact=Path(sys.argv[1]);out=Path(sys.argv[2]);assert not out.exists()
gate=artifact/'gate';ledger=gate/'ledger.json';ci=json.loads(ledger.read_text());bootstrap=json.loads((artifact/'bootstrap.json').read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(fullroot/'gate/ledger.json')=='4ccc47e8bf5f505d31717af4f52d4c6f5c49c2c781a6284854c368a387f9c266'
assert ci['status']=='passed-disposable-synthetic-parity-and-rollback'
assert ci['profile']['name']=='ci' and ci['profile']['consumerConfigurations']==['Release']
assert ci['selectedSdk']['version']=='3.128.0' and ci['rollback']['complete']
assert set(ci['rows'])=={f'R{i}' for i in range(1,12)}
comparisons={}
def same(name,a,b):
 assert a==b,name
 comparisons[name]={'equal':True,'entries':len(a) if isinstance(a,(dict,list)) else None,'sha256':hashlib.sha256(json.dumps(a,sort_keys=True).encode()).hexdigest()}
for key in ['fixtureSources','verifierSha256','verifierHelpers','platformConsumerSources','publishedProducers']:
 same(key,full[key],ci[key])
for name in ['Works','Platform']:
 same('canonical'+name,full['canonicalSources'][name]['sourceFiles'],ci['canonicalSources'][name]['sourceFiles'])
same('worksConsumer',full['worksConsumerSource']['sourceFiles'],ci['worksConsumerSource']['sourceFiles'])
for key in ['sourceFiles','currentRelevantSourceFiles','dependencyInputs']:
 same('platformSnapshot.'+key,full['platformSourceSnapshot'][key],ci['platformSourceSnapshot'][key])
for key in ['baselineCommit','archiveSha256','manifestSha256','sourceFiles']:
 same('retainedHost.'+key,full['retainedHostSource'][key],ci['retainedHostSource'][key])
same('sourceProducerMembership',sorted(full['sourceProducers']),sorted(ci['sourceProducers']))
for key in full['sourceProducers']:
 same('sourceProducer.'+key,full['sourceProducers'][key]['sourceFiles'],ci['sourceProducers'][key]['sourceFiles'])
def normalized_linked(d):
 prefixes=[(d['platformSourceSnapshot']['root'],'<platform-export>'),(d['worksConsumerSource']['root'],'<works>')]
 result={}
 for path,digest in d['linkedFixtureSources']['sourceFiles'].items():
  matches=[(prefix,label) for prefix,label in prefixes if path.startswith(prefix+'/')]
  assert len(matches)==1,('unmapped or ambiguous linked input',path,matches)
  prefix,label=matches[0];key=label+path[len(prefix):];assert key not in result;result[key]=digest
 return result
same('linkedFixturesExactPrefixNormalization',normalized_linked(full),normalized_linked(ci))
assert ci['platformSourceSnapshot']['originCommit']==full['platformSourceSnapshot']['originCommit']=='2c261d2517692ac45721099fcccf822f3821509e'
assert ci['runtimeProducerQualification']['repositoryCommit']=='c5d1c280d8c1c1a207cd159d817f614e93c93130'
assert ci['runtimeProducerQualification']['matchesPublishedProducer']
same('runtimeProducerSourceInventory',full['runtimeProducerQualification']['sourceInventorySha256'],ci['runtimeProducerQualification']['sourceInventorySha256'])
localbootstrap=json.loads((fullroot/'bootstrap.json').read_text())
same('coordinatorBytes',localbootstrap['coordinatorSha256'],bootstrap['coordinatorSha256'])
same('bootstrapRootDependencyMembership',sorted(localbootstrap['rootDependencies']),sorted(bootstrap['rootDependencies']))
assert bootstrap['platformCommit']=='2c261d2517692ac45721099fcccf822f3821509e'
assert bootstrap['sdkCommit']=='c5d1c280d8c1c1a207cd159d817f614e93c93130'
# Inventory every result, including methods behind the seven ordinary explicit facts.
tests={};inventories=[];total=0
for p in sorted(gate.glob('*.xml')):
 assemblies=E.parse(p).getroot().findall('assembly');assert assemblies,p
 entries=[]
 for a in assemblies:
  assert all(int(a.get(k,'0'))==0 for k in ['failed','errors','skipped','not-run']),p
  total+=int(a.get('passed'))
 for t in E.parse(p).findall('.//test'):
  assert t.get('result')=='Pass',p
  method=t.get('type')+'.'+t.get('method');tests[method]=str(p.relative_to(artifact));entries.append({'name':t.get('name'),'method':method,'result':t.get('result')})
 assert entries,p
 inventories.append({'path':str(p.relative_to(artifact)),'sha256':sha(p),'assemblies':[dict(a.attrib) for a in assemblies],'tests':entries})
assert total==459,(total,'expected Release144 + supporting306 + nine live test cases')
ordinary=fullaudit['profiles']['full']['ordinaryExplicitExclusionsMatchedToPassingLiveFacts']
assert len(ordinary)==7 and all(x['name'] in tests for x in ordinary)
phase_owners=fullaudit['explicitPhaseToMethodAttribution'];states=[json.loads(x) for x in (gate/'persisted-states.jsonl').read_text().splitlines() if x];byphase={x['phase']:x for x in states}
assert len(states)==len(byphase)==32 and set(byphase)==set(phase_owners)
rows={}
for row,value in ci['rows'].items():
 assert value['status']=='passed' and set(value['requiredProofs'])=={'persisted','negative','restart','rollback'}
 proofs={}
 for kind,proof in value['requiredProofs'].items():
  assert proof['passed'] and proof['evidence'];facts=[]
  for e in proof['evidence']:
   phase=e['phase'];assert phase in phase_owners;method=phase_owners[phase]['test'];assert method in tests
   assert e['recordSha256']==hashlib.sha256(json.dumps(byphase[phase],sort_keys=True).encode()).hexdigest()
   facts.append({'test':method,'resultXml':tests[method],**e})
  proofs[kind]=facts
 rows[row]={'title':value['title'],'producer':value['producer'],'consumer':value['consumer'],'consumerSha256':value['consumerSha256'],'proofs':proofs}
# Full-module execution plus exact unchanged test sources establishes every named refusal ran.
command=next(c for c in ci['commands'] if c['name']=='evidence-gate-tests');old=next(c for c in full['commands'] if c['name']=='evidence-gate-tests')
assert command['exitCode']==0 and command['command']==old['command']
log=gate/command['log'];assert sha(log)==command['sha256'];assert re.search(r'\nRan 151 tests in [^\n]+\n\nOK\s*$',log.read_text())
migration=fullaudit['frozenScenarios']['Migration gate']['profiles']['full'];named=[]
for test in migration['namedRefusalFacts']:
 name=Path(test['source']).name;assert ci['verifierHelpers'][name]==test['sourceSha256'];assert not test['declaredSkipped']
 named.append({**test,'source':ci['platformSourceSnapshot']['root']+'/eng/'+name})
result={'scope':'Passing local full plus subsequent complete actual hosted ci; synthetic disposable qualification only','localFull':{'ledger':str(fullroot/'gate/ledger.json'),'sha256':sha(fullroot/'gate/ledger.json'),'worksCommit':full['worksConsumerSource']['commit']},'hostedCi':{'ledger':str(ledger),'sha256':sha(ledger),'worksCommit':ci['worksConsumerSource']['commit'],'profile':ci['profile'],'testPasses':total,'testInventories':inventories,'rows':rows,'rollback':ci['rollback'],'persistedPhases':len(states),'actualStarts':len(ci['actualStarts']),'runtimeArtifactCount':len(ci['runtimeArtifacts']),'ordinaryExplicitFactsMapped':ordinary,'agentsFull':ci['checks']['agentsFull']},'boundSourceFixtureHelperMembershipAndBytes':comparisons,'pathNormalization':'Only exact ledger-declared Works and Platform-export prefixes in linked-input keys; hashes and relative membership unchanged; unrecognized/ambiguous prefix refuses. No line-ending or content normalization.','migrationGate':{'namedRefusalFacts':named,'executedCommand':command,'outputSha256':sha(log),'basis':'Hosted exact 151-test module command passed with no skips; module membership and every helper byte match the independently enumerated full inventory.','retainedReadiness':migration['retainedReadiness']['test'],'retainedReadinessResultXml':tests[migration['retainedReadiness']['test']]},'explicitPhaseToMethodAttribution':phase_owners,'unknownPhasePolicy':'Refuse','frozenScenarios':{k:v for k,v in fullaudit['frozenScenarios'].items() if k!='Migration gate'},'runtimeClosureScope':'Each canonical ledger verifies its own executed runtime bytes and launcher closure. Internal build outputs are not asserted byte-identical across machines; public producer package and consumed assembly hashes are exact equal.','exactHostedGitTreeAudit':'Separate required PR/checkout commit/tree record must bind ledger Works revision to actual hosted checkout and final PR head.'}
# Bind each frozen scenario separately to executed full and hosted result inventories.
full_test_results={t['method']:{'resultXml':inventory['path'],'resultXmlSha256':inventory['sha256']} for inventory in fullaudit['profiles']['full']['testInventories'] for t in inventory['tests']}
ci_test_results={t['method']:{'resultXml':inventory['path'],'resultXmlSha256':inventory['sha256']} for inventory in inventories for t in inventory['tests']}
scenario_records={}
for name,requirement in fullaudit['frozenScenarios'].items():
 if name=='Migration gate':continue
 profile_records={}
 for label,lookup,selected_rows in [('full',full_test_results,fullaudit['profiles']['full']['rows']),('ci',ci_test_results,rows)]:
  executed=[]
  for method in requirement['tests']:
   assert method in lookup,(name,label,method)
   executed.append({'test':method,**lookup[method],'outcome':'Pass'})
  profile_records[label]={'executedMethods':executed,'requiredRows':{row:selected_rows[row] for row in requirement['rows']},'ledgerSha256':sha(fullroot/'gate/ledger.json') if label=='full' else sha(ledger)}
 scenario_records[name]={'requirementMapping':requirement,'profiles':profile_records}
hosted_migration=result['migrationGate']
result['migrationGate']={'profiles':{'full':migration,'ci':hosted_migration},'historicalCutoverAcceptanceUnchanged':True}
scenario_records['Migration gate']={'requirement':'Incomplete rows/lanes/closure cannot qualify; separately executed retained topology remains usable.','profiles':{'full':migration,'ci':hosted_migration}}
result['frozenScenarios']=scenario_records
result['scenarioProofScope']='Every frozen scenario has distinct full and actual hosted ci execution/result bindings. Full-only historical proof is never represented as hosted execution.'
out.write_text(json.dumps(result,indent=2)+'\n');print(out,'rows',len(rows),'proofs',sum(len(x['proofs']) for x in rows.values()),'passes',total)
