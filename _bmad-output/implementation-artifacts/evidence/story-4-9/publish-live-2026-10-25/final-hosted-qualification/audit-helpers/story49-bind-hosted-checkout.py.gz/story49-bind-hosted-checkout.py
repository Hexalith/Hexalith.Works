from pathlib import Path
import json,hashlib,zipfile,re,subprocess,datetime
out=Path('/tmp/story49-hosted-attempt2');ledger_path=out/'works-platform-parity/gate/ledger.json';ledger=json.loads(ledger_path.read_text());checkout=ledger['worksConsumerSource']['commit'];assert checkout=='f7a4fdf9b72e2b298fbe7ea8a41e00bd2a8b30da'
with zipfile.ZipFile(out/'workflow-logs.zip') as z:
 matches=[]
 for name in z.namelist():
  data=z.read(name)
  if '/' not in name and 'Platform R1' in name and b'--format=%H' in data:
   matches.append((name,data))
 assert len(matches)==1,[x[0] for x in matches]
 name,data=matches[0];lines=data.decode().splitlines();positions=[i for i,l in enumerate(lines) if 'git log -1 --format=%H' in l];assert len(positions)==1
 line=lines[positions[0]+1];assert line.endswith(checkout),line
 (out/'actual-parity-job.log').write_bytes(data)
 head='da76aea2ab2f650b71613d139d0145f2b509ad0f';main='eb044d9e54e0c89b5eb320be6474fe7f264348c1'
 pr=json.loads(Path('/tmp/story49-works-pr5-external-merge/pr.json').read_text());merge=json.loads(Path('/tmp/story49-works-pr5-external-merge/merge-commit.json').read_text())
 assert checkout==json.loads(Path('/tmp/story49-works-hosted-pr/hosted-git-binding-preflight.json').read_text())['currentSyntheticMergeCommit']
 tree=subprocess.check_output(['git','rev-parse',head+'^{tree}'],text=True).strip();assert tree==subprocess.check_output(['git','rev-parse',checkout+'^{tree}'],text=True).strip()==merge['tree']['sha']
 record={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'workflowRun':40230306221,'attempt':2,'eventHead':head,'actualCheckout':checkout,'ledgerSha256':hashlib.sha256(ledger_path.read_bytes()).hexdigest(),'jobLogArchiveEntry':name,'jobLogSha256':hashlib.sha256(data).hexdigest(),'checkoutLogLines':lines[positions[0]:positions[0]+2],'prHeadTree':tree,'actualCheckoutTree':tree,'externalMainMerge':main,'externalMainMergeTree':tree,'allThreeTreesExactlyEqual':True,'qualifiedFullWorksRevision':'bfbdbc1c166b7cd750db4d890d77c3f55bb01273','fullToActualHostedInputAudit':'acceptance-audit-full-hosted-ci-with-builds.json','fullToFinalHead425BlobAudit':'/tmp/story49-works-hosted-pr/bound-input-equivalence.json','localFullLedgerNotRelabeled':True,'mainHostedRunStatus':'still running; its actual result remains separate','externalMergeIsNotReviewCompletion':True}
 (out/'actual-checkout-binding.json').write_text(json.dumps(record,indent=2)+'\n');print('exact hosted checkout bound',checkout,'ledger',record['ledgerSha256'])
