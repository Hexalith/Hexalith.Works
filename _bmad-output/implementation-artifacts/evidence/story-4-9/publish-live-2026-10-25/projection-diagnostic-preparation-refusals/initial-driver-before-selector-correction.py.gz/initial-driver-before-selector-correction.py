import datetime,hashlib,importlib.util,json,os,subprocess,sys
from pathlib import Path
root=Path('/home/administrator/projects/hexalith/works');base=Path('/tmp/story49-final-public-3.128.0-qualification-retry2');gate=base/'ci/gate';out=Path('/tmp/story49-final-projection-native-diagnostic');out.mkdir(exist_ok=False)
state=json.loads((base/'ci-process.json').read_text());assert state['state']=='completed' and state['exitCode']!=0,'prior owned fleet must finish first'
d=json.loads((gate/'ledger.json').read_text());assert d['status']!='passed-disposable-synthetic-parity-and-rollback'
for owner,sha in state['selectedHeads'].items():
 r=root if owner=='Works' else root/'references'/('Hexalith.'+owner)
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==sha
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=r,text=True).strip()
def runtime_hashes_match():
 mismatches=[p for p,h in d['runtimeArtifacts'].items() if hashlib.sha256(Path(p).read_bytes()).hexdigest()!=h]
 assert not mismatches,mismatches
 return len(d['runtimeArtifacts'])
count=runtime_hashes_match();spec=importlib.util.spec_from_file_location('owned_isolated_daprd',base/'ci/workspace/platform/eng/isolated_daprd.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
isolated=out/'isolated-daprd';binding=module.prepare(isolated,d['isolatedRuntime']['runtime'],d['controlPlanePorts']['sentry']);assert all(binding[k]==d['isolatedRuntime'][k] for k in binding)
bootstrap=json.loads((base/'ci/bootstrap.json').read_text());bootstrap_pins={name.replace('.', '')+'Root':bootstrap['rootDependencies'][name] for name in ['Hexalith.Builds','Hexalith.Commons','Hexalith.Parties','Hexalith.Tenants','Hexalith.PolymorphicSerializations']};bootstrap_pins.update(HexalithEventStoreRoot=bootstrap['sdkRoot'],DOTNET_USE_POLLING_FILE_WATCHER='1')
environment=os.environ.copy();environment.update(bootstrap_pins);environment.update(d['runtimeEnvironment'])
delta={'WORKS_PLATFORM_HOST_EVIDENCE':str(out/'host-starts.jsonl'),'WORKS_SDK_PROOF_EVIDENCE_PATH':str(out/'persisted-states.jsonl'),'WORKS_PLATFORM_DAPRD_RUNTIME_PATH':str(isolated),'DcpPublisher__DiagnosticsLogFolder':str(out/'native'),'DcpPublisher__PreserveExecutableLogs':'true','DcpPublisher__DiagnosticsLogLevel':'debug'};environment.update(delta)
original=next(x for x in d['commands'] if x['name']=='platform-projection')['command'];cmd=[str(x) for x in original];i=cmd.index('-class');cmd[i]='-method';cmd[i+1]='Hexalith.Works.IntegrationTests.WorksPlatformProjectionPipelineSmokeTests.ActualPlatformSharedRebuildAndConcurrentCatchUpPreserveCompleteFamily';cmd[cmd.index('-result-xml')+1]=str(out/'projection.xml')
record={'classification':'focused diagnostic only; not full or CI qualification','command':cmd,'cwd':str(root),'selectedHeads':state['selectedHeads'],'baselineEnvironment':d['runtimeEnvironment'],'bootstrapEnvironmentPins':bootstrap_pins,'environmentDelta':delta,'documentedDiagnosticsSource':'Installed Aspire.Hosting 13.6.3 XML DcpOptions.DiagnosticsLogFolder and PreserveExecutableLogs; DcpPublisher configuration binding','runtimeArtifactsVerifiedBefore':count,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'assertionsAndTimeoutsChanged':False}
(out/'command.json').write_text(json.dumps(record,indent=2)+'\n')
observer=None;native_observer=None;discovery_observer=None
try:
 with (out/'temporary-docker-events.jsonl').open('w') as events,(out/'docker-observer.stderr').open('w') as err:
  observer=subprocess.Popen(['docker','events','--since',record['startedAt'],'--filter','type=container','--format','{{json .}}'],stdout=events,stderr=err)
  native_observer=subprocess.Popen(['python3','/tmp/story49-capture-native-session.py',str(out),str(base/'ci/workspace/platform')],stdout=(out/'native-observer.log').open('w'),stderr=subprocess.STDOUT)
  discovery_observer=subprocess.Popen(['python3','/tmp/story49-observe-owned-discovery.py',str(out)],stdout=(out/'discovery-observer.log').open('w'),stderr=subprocess.STDOUT)
  with (out/'projection.log').open('w') as log:r=subprocess.run(cmd,cwd=root,env=environment,stdout=log,stderr=subprocess.STDOUT)
finally:
 (out/'stop-native-observer').write_text('test command completed; observer stops after its final read-only snapshot\n')
 if native_observer is not None:
  try:native_observer.wait(timeout=15)
  except subprocess.TimeoutExpired:native_observer.terminate();native_observer.wait(timeout=5)
 if discovery_observer is not None:
  try:discovery_observer.wait(timeout=5)
  except subprocess.TimeoutExpired:discovery_observer.terminate();discovery_observer.wait(timeout=5)
 if observer and observer.poll() is None:
  observer.terminate()
  try:observer.wait(timeout=5)
  except subprocess.TimeoutExpired:observer.kill();observer.wait(timeout=5)
record.update(exitCode=r.returncode,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),runtimeArtifactsVerifiedAfter=runtime_hashes_match());(out/'command.json').write_text(json.dumps(record,indent=2)+'\n');print('focused diagnostic exit',r.returncode,flush=True);raise SystemExit(r.returncode)
