A successful publication-index transition advances the independent journal anchor before the actor repeats its admission check. The authority still compared the request's predecessor with that new anchor, so a committed dispatch returned no progress. Accept the repeated check only when the proposed successor exactly matches the already anchored state by full digest and retains the expected next revision. Authentication, current enrollment evidence, and independent receipt checks still run.

The existing complete-inventory/receipt test fails with the original committed fixture. Add coverage that requires successful committed-state verification and refuses changed authority or poison state without altering the index or journal.

Also generate the new source-authority fixture credentials at runtime and enroll ServiceDefaults.Tests in the existing blocking unit-test list. These repair the unchanged secret scanner and release manifest guard failures observed on current main.

Validation: Debug/source builds completed without warnings or errors; 261 secret-scanner and source-publication authority cases passed; command-source authority 3/3; release-package manifest 127/127. The original committed fixture reproduces the dispatch failure (1/1), and the new negative cases exercise authenticated admission directly as well as the actor and verify unchanged persisted index/journal state.
