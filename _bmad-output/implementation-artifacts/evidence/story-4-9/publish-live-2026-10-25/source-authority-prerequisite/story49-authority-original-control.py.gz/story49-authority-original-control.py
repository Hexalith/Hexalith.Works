import subprocess
from pathlib import Path
owner=Path('/home/administrator/projects/hexalith/works/references/Hexalith.EventStore')
source=owner/'tests/Hexalith.EventStore.Server.Tests/Streams/SourcePublicationAuthorityFixture.cs'
changed=source.read_bytes()
original=subprocess.check_output(['git','show','HEAD:'+str(source.relative_to(owner))],cwd=owner)
try:
    source.write_bytes(original)
    with open('/tmp/story49-authority-original-build.log','w') as log:
        result=subprocess.run(['dotnet','build','tests/Hexalith.EventStore.Server.Tests/Hexalith.EventStore.Server.Tests.csproj','-c','Debug','-p:UseHexalithProjectReferences=true','--artifacts-path','.artifacts/story49-publish-20261025','-m:1'],cwd=owner,stdout=log,stderr=subprocess.STDOUT)
    if result.returncode: raise SystemExit(result.returncode)
    with open('/tmp/story49-authority-original-test.log','w') as log:
        result=subprocess.run(['.artifacts/story49-publish-20261025/bin/Hexalith.EventStore.Server.Tests/debug/Hexalith.EventStore.Server.Tests','-noLogo','-method','*CompleteInventoryIncludesZeroAgentSourcesAndOnlyIndependentConsecutiveReceiptsAdvance','-result-xml','/tmp/story49-authority-original-test.xml'],cwd=owner,stdout=log,stderr=subprocess.STDOUT)
    print('Original fixture test exit:', result.returncode)
    print(Path('/tmp/story49-authority-original-test.log').read_text()[-2400:])
finally:
    source.write_bytes(changed)
