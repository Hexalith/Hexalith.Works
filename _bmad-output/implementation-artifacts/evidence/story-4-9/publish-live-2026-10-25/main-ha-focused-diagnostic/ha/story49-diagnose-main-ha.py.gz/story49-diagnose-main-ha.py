import datetime,hashlib,importlib.util,json,os,subprocess,sys
from pathlib import Path
root=Path('/home/administrator/projects/hexalith/works');base=Path('/tmp/story49-final-public-3.128.0-qualification-retry2');gate=base/'full/gate';out=Path('/tmp/story49-main-ha-native-diagnostic-run1');out.mkdir(exist_ok=False)
state=json.loads((base/'full-process.json').read_text());assert state['state']=='completed' and state['exitCode']==0
d=json.loads((gate/'ledger.json').read_text());assert d['status']=='passed-disposable-synthetic-parity-and-rollback'
current={}
for owner,sha in state['selectedHeads'].items():
 r=root if owner=='Works' else root/'references'/('Hexalith.'+owner);current[owner]=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()
 if owner!='Works':assert current[owner]==sha
sys.path.insert(0,str(base/'full/workspace/platform/eng'));import verify_works_host as verifier
before={}
def exact_inputs():
 for name,baseline in d['canonicalSources'].items():
  now=verifier.canonical_source_snapshot(Path(baseline['root']));assert now['sourceFiles']==baseline['sourceFiles'],name;assert now['inventorySha256']==baseline['inventorySha256'],name
 for path,digest in d['runtimeArtifacts'].items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest,path
 for name,digest in d['fixtureSources'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
 return {'runtimeArtifacts':len(d['runtimeArtifacts']),'canonicalWorksInputs':len(d['canonicalSources']['Works']['sourceFiles']),'fixtures':len(d['fixtureSources'])}
before=exact_inputs();module=__import__('isolated_daprd');isolated=out/'isolated-daprd';binding=module.prepare(isolated,d['isolatedRuntime']['runtime'],d['controlPlanePorts']['sentry']);assert all(binding[k]==d['isolatedRuntime'][k] for k in binding)
pins=json.loads((base/'full/full-invocation.json').read_text())['environmentPins'];environment=os.environ.copy();environment.update(pins);environment.update(d['runtimeEnvironment'])
delta={'WORKS_PLATFORM_HOST_EVIDENCE':str(out/'host-starts.jsonl'),'WORKS_SDK_PROOF_EVIDENCE_PATH':str(out/'persisted-states.jsonl'),'WORKS_PLATFORM_DAPRD_RUNTIME_PATH':str(isolated),'DcpPublisher__DiagnosticsLogFolder':str(out/'native'),'DcpPublisher__PreserveExecutableLogs':'true','DcpPublisher__DiagnosticsLogLevel':'debug'};environment.update(delta)
cmd=list(next(x for x in d['commands'] if x['name']=='platform-ha')['command']);assert cmd[cmd.index('-method')+1]=='Hexalith.Works.IntegrationTests.WorksPlatformHaPipelineSmokeTests.TwoWorksHostsRecoverLostFiringAfterPrimaryStopsWithoutDuplicateEffect';cmd[cmd.index('-result-xml')+1]=str(out/'ha.xml')
record={'classification':'one unchanged focused HA diagnostic; no full/CI acceptance credit','command':cmd,'cwd':str(root),'qualifiedFullHeads':state['selectedHeads'],'currentHeads':current,'qualifiedFullLedgerSha256':hashlib.sha256((gate/'ledger.json').read_bytes()).hexdigest(),'baselineEnvironment':d['runtimeEnvironment'],'bootstrapEnvironmentPins':pins,'environmentDelta':delta,'documentedDiagnosticsSource':'Installed Aspire.Hosting 13.6.3 DcpOptions.DiagnosticsLogFolder and PreserveExecutableLogs; same existing DcpPublisher settings as prior diagnostics','inputHashesVerifiedBefore':before,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'assertionsAndTimeoutsChanged':False,'sourceAndRuntimeBytesChanged':False,'nativeCaptureHelperSha256':hashlib.sha256(Path('/tmp/story49-capture-native-session.py').read_bytes()).hexdigest(),'safeProcessObserverSha256':hashlib.sha256(Path('/tmp/story49-observe-owned-ha-processes.py').read_bytes()).hexdigest()}
(out/'command.json').write_text(json.dumps(record,indent=2)+'\n');observer=None;native=None;process=None;r=None
try:
 with (out/'temporary-docker-events.jsonl').open('w') as events,(out/'docker-observer.stderr').open('w') as err:
  observer=subprocess.Popen(['docker','events','--since',record['startedAt'],'--filter','type=container','--format','{{json .}}'],stdout=events,stderr=err)
  native=subprocess.Popen(['python3','/tmp/story49-capture-native-session.py',str(out),str(base/'full/workspace/platform')],stdout=(out/'native-observer.log').open('w'),stderr=subprocess.STDOUT)
  process=subprocess.Popen(['python3','/tmp/story49-observe-owned-ha-processes.py',str(out)],stdout=(out/'process-observer.log').open('w'),stderr=subprocess.STDOUT)
  with (out/'ha.log').open('w') as log:r=subprocess.run(cmd,cwd=root,env=environment,stdout=log,stderr=subprocess.STDOUT)
finally:
 (out/'stop-native-observer').write_text('owned test finished; read-only observers stop\n')
 for p in [native,process]:
  if p:
   try:p.wait(timeout=15)
   except subprocess.TimeoutExpired:p.terminate();p.wait(timeout=5)
 if observer and observer.poll() is None:observer.terminate();observer.wait(timeout=5)
record.update(exitCode=r.returncode if r else None,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),inputHashesVerifiedAfter=exact_inputs());(out/'command.json').write_text(json.dumps(record,indent=2)+'\n');print('focused HA diagnostic exit',record['exitCode'],flush=True);raise SystemExit(record['exitCode'])
