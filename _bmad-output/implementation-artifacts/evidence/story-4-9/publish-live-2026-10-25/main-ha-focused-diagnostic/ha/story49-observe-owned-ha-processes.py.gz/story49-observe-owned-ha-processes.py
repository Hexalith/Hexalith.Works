import datetime,hashlib,json,os,re,sys,time
from pathlib import Path
out=Path(sys.argv[1]);known={};seen=set()
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def argument(args,key):
 for i,x in enumerate(args):
  if x==key and i+1<len(args):return args[i+1]
  if x.startswith(key+'='):return x[len(key)+1:]
 return None
while not (out/'stop-native-observer').exists():
 try:
  launches=out/'isolated-daprd/launches.jsonl'
  if launches.exists():
   for line in launches.read_text().splitlines():
    try:d=json.loads(line);known[d['config']]=d['appId']
    except (ValueError,KeyError):pass
  rows=[]
  for p in Path('/proc').iterdir():
   if not p.name.isdigit():continue
   try:
    args=[x.decode(errors='replace') for x in (p/'cmdline').read_bytes().split(b'\0') if x];config=argument(args,'--config')
    if config not in known:continue
    app=argument(args,'--app-id');exe=os.readlink(p/'exe');stat=(p/'stat').read_text();fields=stat[stat.rfind(')')+2:].split();inodes=set()
    for fd in (p/'fd').iterdir():
     try:
      link=os.readlink(fd);match=re.fullmatch(r'socket:\[(\d+)\]',link)
      if match:inodes.add(match.group(1))
     except (FileNotFoundError,PermissionError):pass
    sockets=[]
    for family in ['tcp','tcp6']:
     for line in (p/'net'/family).read_text().splitlines()[1:]:
      cols=line.split()
      if cols[9] in inodes:sockets.append({'family':family,'localAddressHex':cols[1],'remoteAddressHex':cols[2],'stateHex':cols[3],'inode':cols[9]})
    rows.append({'pid':int(p.name),'parentPid':int(fields[1]),'state':fields[0],'startTimeTicks':int(fields[19]),'executable':exe,'appId':app,'configPath':config,'ports':{k:argument(args,k) for k in ['--dapr-http-port','--dapr-grpc-port','--dapr-internal-grpc-port','--app-port']},'ownedSockets':sockets})
   except (FileNotFoundError,ProcessLookupError,PermissionError):pass
  with (out/'owned-process-listeners.jsonl').open('a') as f:f.write(json.dumps({'at':stamp(),'knownOwnedConfigs':len(known),'processes':rows})+'\n')
 except Exception as e:
  with (out/'owned-process-observer-errors.jsonl').open('a') as f:f.write(json.dumps({'at':stamp(),'errorType':type(e).__name__,'message':str(e)})+'\n')
 time.sleep(1)
