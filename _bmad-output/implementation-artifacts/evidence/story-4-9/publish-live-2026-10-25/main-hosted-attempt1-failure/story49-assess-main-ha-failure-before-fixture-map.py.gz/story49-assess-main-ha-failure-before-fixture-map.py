from pathlib import Path
import json,hashlib,re,datetime,xml.etree.ElementTree as ET,zipfile,subprocess
root=Path('/home/administrator/projects/hexalith/works');raw=Path('/tmp/story49-parent-hosted-main-eb044');g=raw/'works-platform-parity/gate';passed=Path('/tmp/story49-hosted-attempt2/works-platform-parity/gate');out=Path('/tmp/story49-main-ha-failure-diagnosis');out.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
m=json.loads((g/'ledger.json').read_text());p=json.loads((passed/'ledger.json').read_text());assert m['status']=='incomplete';assert m['worksConsumerSource']['commit']=='eb044d9e54e0c89b5eb320be6474fe7f264348c1'
binding={}
for key in ['sourceProducers','platformConsumerSources','fixtureSources','linkedFixtureSources','verifierSha256','verifierHelpers','qualifiedToolchain','platformSourceSnapshot']:
 assert m[key]==p[key],key;binding[key]={'exactEqual':True}
for key in ['worksConsumerSource']:
 assert set(m[key])==set(p[key]);diff=[k for k in m[key] if m[key][k]!=p[key][k]];assert diff==['commit'],diff;binding[key]={'onlyDifference':'commit','main':m[key]['commit'],'passingPr':p[key]['commit'],'sourceFiles':len(m[key]['sourceFiles']),'inventorySha256':m[key]['inventorySha256']}
assert set(m['canonicalSources'])==set(p['canonicalSources'])
for name in m['canonicalSources']:
 x=m['canonicalSources'][name];y=p['canonicalSources'][name]
 if name=='Works':assert [k for k in x if x[k]!=y[k]]==['commit']
 else:assert x==y,name
binding['canonicalSources']={'onlyDifference':'Works.commit; all inventory membership and bytes equal'}
xml=[];fail=None;passes=0
for path in sorted(g.glob('*.xml')):
 tree=ET.parse(path);assemblies=tree.findall('.//assembly');counts={k:sum(int(a.get(k,'0')) for a in assemblies) for k in ['passed','failed','errors','skipped','not-run']};passes+=counts['passed'];xml.append({'path':str(path),'sha256':sha(path),'counts':counts})
 for test in tree.findall('.//test'):
  if test.get('result')=='Fail':assert fail is None;fail=test
assert passes==456;assert fail is not None
message=fail.find('failure/message').text;headers=re.findall(r'(?m)^([^\n]+) startup output:',message);assert 'eventstore-dapr-cli' not in headers
health=[]
for line in message[message.index('eventstore startup output:'):message.index('works startup output:')].splitlines()[1:]:
 try:record=json.loads(json.loads('"'+line[29:]+'"'))
 except (ValueError,json.JSONDecodeError):continue
 if record.get('Category','').endswith('DefaultHealthCheckService') or record.get('Category','').endswith('ProjectionDeliveryRetryWorker'):
  health.append({'timestamp':line[:28].strip(),'category':record['Category'],'eventId':record.get('EventId'),'message':record.get('Message')})
(out/'eventstore-bounded-health-observations.json').write_text(json.dumps(health,indent=2)+'\n')
starts=[json.loads(x) for x in (g/'host-starts.jsonl').read_text().splitlines()];phases=[json.loads(x)['phase'] for x in (g/'persisted-states.jsonl').read_text().splitlines()];launches=[json.loads(x) for x in (g/'isolated-daprd/launches.jsonl').read_text().splitlines()];owned=[x for x in launches if '/works-sdk416-discovery-axrliR/' in x['config']];assert len(owned)==5;assert sorted(x['appId'] for x in owned)==['eventstore','eventstore-admin','eventstore-operations','works','works']
(out/'failed-ha-owned-launch-records.json').write_text(json.dumps(owned,indent=2)+'\n')
with zipfile.ZipFile(raw/'workflow-logs.zip') as z:
 names=[n for n in z.namelist() if '/' not in n and 'Platform R1' in n];assert len(names)==1;data=z.read(names[0]);lines=data.decode().splitlines();idx=next(i for i,l in enumerate(lines) if 'git log -1 --format=%H' in l);assert lines[idx+1].endswith(m['worksConsumerSource']['commit']);checkout={'archiveEntry':names[0],'jobLogSha256':hashlib.sha256(data).hexdigest(),'lines':lines[idx:idx+2]}
sourcefiles=['tests/Hexalith.Works.IntegrationTests/WorksPlatformHaPipelineSmokeTests.cs','tests/Hexalith.Works.IntegrationTests/WorksAppHostSmokeHarness.cs','tests/Hexalith.Works.IntegrationTests/WorksAppHostTestReadiness.cs']
sources=[]
for name in sourcefiles:
 content=(root/name).read_bytes();assert hashlib.sha256(content).hexdigest()==m['worksConsumerSource']['sourceFiles'][name];dest=out/Path(name).name;dest.write_bytes(content);sources.append({'path':name,'sha256':sha(dest)})
record={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'workflow':{'run':40231871761,'attempt':1,'conclusion':'failure','url':'https://github.com/Hexalith/Hexalith.Works/actions/runs/40231871761','exactMain':m['worksConsumerSource']['commit'],'checkout':checkout},'rawEvidenceRoot':str(raw),'downloadInventorySha256':sha(raw/'download-inventory.json'),'ledger':{'path':str(g/'ledger.json'),'sha256':sha(g/'ledger.json'),'status':'incomplete','failure':m['failure'],'acceptanceCredit':False},'failedMethod':dict(fail.attrib),'firstFailureLine':message.splitlines()[0],'failureCategory':'EventStore startup readiness failed before HA test-body admission','observations':{'eventstoreState':'Running','eventstoreHealth':'Unhealthy','eventstoreExitCode':'none','failedSidecarEndpoint':'localhost:31273','directlyObserved':'EventStore metadata requests refused; Dapr sidecar health reports not responsive; statestore and projection protocol/evidence health remain unverified.','sidecarNativeStreamCaptured':False,'capturedResourceLogs':headers,'launchRecords':'Five launcher records identify this owned HA discovery root and runtime/config hashes, including eventstore; they do not establish successful daprd startup, exit status, or root cause.','controlPlane':'Sentry/Placement/Scheduler readiness waits completed before EventStore wait. Sentry reload warnings are retained but do not establish cause.','causality':'No established port collision, credentials defect, Docker mapping defect, OOM, cancellation interference, or source defect. Later teardown is not causal proof.','artifactLimitation':'Harness StartupLogsAsync explicitly captures eight application/control-plane resources and last40lines each, omitting direct sidecar resources. No native DCP dump/sidecar stderr or process state is in uploaded artifacts.'},'executedResults':{'passes':456,'failures':1,'xml':xml,'retained':1,'recovery':4,'historical':1,'ha':{'passed':0,'failed':1},'persistedPhases':phases,'starts':len(starts),'notExecutedAfterFailure':['platform-mtls','platform-projection','final closure and accepted ledger construction'],'partialRecoveryRollbackRecordIsNotCompleteGateAcceptance':True},'sourceBindingsVsPassingPrCi':binding,'sources':sources,'passingPrHa':{'result':'Pass','seconds':105.125,'xml':str(passed/'platform-ha.xml'),'xmlSha256':sha(passed/'platform-ha.xml')},'smallestJustifiedNextAction':'A single unchanged focused HA diagnostic with the existing temporary native-DCP stdout/stderr capture and safe owned process/listener metadata, before any whole-profile retry. Preserve deadlines and assertions; never retain credential-bearing configuration/environment. This diagnostic can identify a reproduced startup refusal but cannot establish the past cause if it passes. No retry or edit executed by this assessment.','acceptanceState':'Prior full and primary hosted PR CI remain independently passed; this failed extra exact-main run remains nonqualifying and must be accounted for before final completion.'}
(out/'assessment.json').write_text(json.dumps(record,indent=2)+'\n')
files=[{'path':str(x.relative_to(out)),'sha256':sha(x),'bytes':x.stat().st_size} for x in sorted(out.rglob('*')) if x.is_file()];(out/'inventory.json').write_text(json.dumps(files,indent=2)+'\n');print(out, '456 passes, HA startup1failure, 29 phases; exact input comparison passed')
