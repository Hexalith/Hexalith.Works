import gzip,hashlib,json,sys
from pathlib import Path
root=Path('/mnt/wsl/story49-group3a-b1ye__ne');out=Path('/home/administrator/projects/hexalith/works/_bmad-output/implementation-artifacts/evidence/story-4-9/group3a-resume-2026-10-27');manifest=out/'qualification-manifest.json'
entries=json.loads(manifest.read_text())['files'] if manifest.exists() else []
known={e['path']:e for e in entries}
def keep(p,relative):
 data=p.read_bytes();native=hashlib.sha256(data).hexdigest();target=out/(relative+'.gz');key=str(target.relative_to(out))
 if key in known:
  assert known[key]['nativeSha256']==native,key
  return
 assert not target.exists(),target
 target.parent.mkdir(parents=True,exist_ok=True);stored=gzip.compress(data,mtime=0);target.write_bytes(stored)
 entry={'path':key,'sha256':hashlib.sha256(stored).hexdigest(),'nativePath':str(p),'nativeSha256':native,'nativeBytes':len(data)};entries.append(entry);known[key]=entry
for name in sys.argv[1:]:
 if name in ('full4','ci1'):
  attempt=root/name;d=json.loads((attempt/'gate/ledger.json').read_text());assert d['status']=='passed-disposable-synthetic-parity-and-rollback'
  for p in sorted(attempt.iterdir()):
   if p.is_file() and p.suffix in ('.json','.log'):keep(p,'qualification/'+name+'/'+p.name)
  keep(root/(name+'-driver.log'),'qualification/'+name+'/driver.log')
  for p in sorted((attempt/'gate').iterdir()):
   if p.is_file() and p.suffix in ('.json','.jsonl','.xml','.log'):keep(p,'qualification/'+name+'/gate/'+p.name)
  for folder in ('isolated-daprd','isolated-daprd-retained-preflight'):
   for basename in ('binding.json','launches.jsonl'):keep(attempt/'gate'/folder/basename,'qualification/'+name+'/gate/'+folder+'/'+basename)
  for folder in ('read-only-observer','dcp-observer'):
   for p in sorted((attempt/folder).iterdir()):
    if p.is_file() and p.suffix in ('.json','.jsonl'):keep(p,'qualification/'+name+'/'+folder+'/'+p.name)
 elif name in ('ordinary','owner-focus','ordinary-document-binding'):
  for p in sorted((root/name).iterdir()):
   if p.is_file() and p.suffix in ('.json','.xml','.log','.csproj','.props','.md'):keep(p,'qualification/'+name+'/'+p.name)
 elif name=='audits':
  for p in sorted(root.glob('parent-*.json')):keep(p,'qualification/audits/'+p.name)
  for basename in ('audit-qualifications.py','append-evidence.py','run-ci1.py','run-full4.py','run-ordinary.sh','run-owner-focus.sh','observe-full4-control-plane.py','observe-full4-dcp.py','observe-ci1-control-plane.py','observe-ci1-dcp.py','bind-ordinary-doc-markers.py','capture-live-drift.py','capture-diff.py','audit-ordinary.py','run-ordinary-focus.sh','run-ordinary-remaining.py'):keep(root/basename,'qualification/scripts/'+basename)
 else:raise ValueError(name)
for e in entries:
 b=(out/e['path']).read_bytes();assert hashlib.sha256(b).hexdigest()==e['sha256'];assert hashlib.sha256(gzip.decompress(b)).hexdigest()==e['nativeSha256']
manifest.write_text(json.dumps({'status':'bounded qualification records; consult README for final acceptance state','files':entries},indent=2)+'\n')
print(json.dumps({'bindings':len(entries),'nativeBytes':sum(e['nativeBytes'] for e in entries),'storedBytes':sum((out/e['path']).stat().st_size for e in entries)},indent=2))
