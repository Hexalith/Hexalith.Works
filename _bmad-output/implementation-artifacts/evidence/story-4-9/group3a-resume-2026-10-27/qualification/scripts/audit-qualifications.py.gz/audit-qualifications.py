import copy, hashlib, importlib.util, json, re, sys, xml.etree.ElementTree as ET
from pathlib import Path
root=Path('/mnt/wsl/story49-group3a-b1ye__ne')
works=root/'final-inputs/works'
live=Path('/home/administrator/projects/hexalith/works')
old=json.loads((live/'_bmad-output/implementation-artifacts/evidence/story-4-9/review-parent-acceptance-2026-10-27/positive/matrix-audit.json').read_text())

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def load(path,name):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
coordinator=load(works/'scripts/verify-platform-parity-ci.py','coordinator')
report={'scope':'captured run-start inputs plus 16 owned overlays; concurrent live checkout advances are outside this qualification','profiles':{},'matrix':[]}
selected=[('full4','full'),('ci1','ci')]
if len(sys.argv)>1:selected=[pair for pair in selected if pair[0] in sys.argv[1:]]
for attempt,profile in selected:
 artifact=root/attempt;gate=artifact/'gate';d=json.loads((gate/'ledger.json').read_text());boot=json.loads((artifact/'bootstrap.json').read_text());platform=Path(boot['platformRoot'])
 assert d['status']=='passed-disposable-synthetic-parity-and-rollback'
 assert d['profile']['name']==profile
 assert d['profile']['consumerConfigurations']==(['Debug','Release'] if profile=='full' else ['Release'])
 assert boot['status']=='passed-disposable-synthetic-parity-and-rollback'
 if profile=='ci':
  coordinator.require_complete_gate(artifact,coordinator.toolchain_runtime_sha256(platform))
  entry=json.loads((artifact/'entry-point-result.json').read_text());assert entry['exitCode']==0
  assert entry['command'][:2]==['bash','scripts/verify-platform-parity-ci.sh']
 sys.path.insert(0,str(platform/'eng'))
 # Each attempt executes in its own Python process through this script's --profile switch.
 owner=load(platform/'eng/verify_works_host.py','owner_'+profile)
 checks={}
 for key,value in d['checks'].items():
  if not isinstance(value,dict) or 'sha256' not in value:continue
  candidates=[p for p in gate.glob('*.xml') if sha(p)==value['sha256']]
  assert len(candidates)==1,(key,candidates)
  p=candidates[0];observed=owner.require_passed_tests(p);assert observed==value,(key,observed,value)
  checks[key]={'file':p.name,**observed}
 assert set(d['rows'])=={'R'+str(i) for i in range(1,12)}
 assert all(r['status']=='passed' and set(r['requiredProofs'])=={'persisted','negative','restart','rollback'} and all(v['passed'] is True and v['evidence'] for v in r['requiredProofs'].values()) for r in d['rows'].values())
 assert d['rollback']['complete'] is True
 owner.require_unchanged_inputs(d,works,platform,Path(d['platformSourceSnapshot']['manifest']),owner.host_ephemeral_port_range(),owner.host_reserved_port_ranges())
 rows=copy.deepcopy(d['rows']);rollback=owner.bind_persisted_outcomes(gate/'persisted-states.jsonl',rows,d['actualStarts']);assert rollback==d['rollback'];assert rows==d['rows']
 starts=owner.verify_host_records(gate/'host-starts.jsonl',Path(d['host']['assembly']),platform,d['selectedSdk']['version'],runtime_artifacts=d['runtimeArtifacts'],host_runtime=Path(d['platformRuntimeIdentity']['hostOutput']),composition_literals=owner.platform_composition_literals(platform/'src/Hexalith.Platform.Composition/WorksPreviewModel.cs'),control_plane_ports=d['controlPlanePorts'],retained_assembly=Path(d['runtimeEnvironment']['WORKS_RETAINED_HOST_ASSEMBLY']))
 assert starts==d['actualStarts']
 assert owner.isolated_daprd.verify(gate/'isolated-daprd',d['isolatedRuntime'],starts)==d['isolatedRuntimeEvidence']
 inventory={}
 for p in gate.glob('*.xml'):
  for t in ET.parse(p).getroot().findall('.//test'):
   inventory.setdefault(t.get('method'),[]).append({'type':t.get('type'),'result':t.get('result'),'xml':p.name})
 matrix=[]
 for row in old['rows']:
  coverage={}
  for method in row['facts']:
   passed=[t for t in inventory.get(method,[]) if t['result']=='Pass'];assert passed,method;coverage[method]=passed
  source={}
  for relative,previous in row['sourceSHA256'].items():
   digest=sha(works/relative);assert digest==previous,(relative,digest,previous);source[relative]=digest
  matrix.append({'scenario':row['scenario'],'executedCoverage':coverage,'unchangedPreviouslyAuditedSourceSHA256':source})
 report['profiles'][profile]={'attempt':attempt,'status':'passed','ledgerSHA256':sha(gate/'ledger.json'),'bootstrapSHA256':sha(artifact/'bootstrap.json'),'rowCount':len(rows),'proofCount':sum(len(r['requiredProofs']) for r in rows.values()),'rollbackComplete':True,'strictFinalInputsAndArtifacts':'passed','persistedBindingsRecomputed':'passed','hostAndLauncherBindingsRecomputed':'passed','checks':checks,'directXmlFactCount':sum(c['total'] for c in checks.values()),'matrix':matrix}
 # Do not reuse the first attempt's helper modules with another Platform root.
 for name in list(sys.modules):
  file=getattr(sys.modules[name],'__file__',None)
  if file and str(platform/'eng') in file:del sys.modules[name]
 sys.path.pop(0)
mtls=works/'tests/Hexalith.Works.IntegrationTests/WorksMtlsAuthorizationSmokeTests.cs'
report['additionalChangedMatrixSource']={'path':str(mtls.relative_to(works)),'sha256':sha(mtls),'assertions':'denied payload carries tenant/item/marker; 403, no disclosure, unchanged family and checkpoint; checkpoint waits below one then asserts exactly one'}
snapshot=json.loads((root/'final-inputs/snapshot.json').read_text());report['ownedCompiledInputsMatchFrozenCapture']={}
for path,digest in snapshot['ownedOverlays'].items():
 if not path.endswith('.cs'):continue
 assert sha(works/path)==digest,path
 report['ownedCompiledInputsMatchFrozenCapture'][path]=digest
text=(live/'_bmad-output/implementation-artifacts/spec-4-9-migrate-works-hosting-to-the-platform-boundary.md').read_bytes()
marked=re.search(rb'<frozen-after-approval\b[^>]*>.*?</frozen-after-approval>',text,re.S).group().replace(b'\r\n',b'\n')
assert hashlib.sha256(marked).hexdigest()==old['frozenIntentSHA256']
report['frozenIntentSHA256']=hashlib.sha256(marked).hexdigest()
if (root/'ordinary-document-binding/binding.json').exists():report['ordinaryDocumentationMetadataBinding']=json.loads((root/'ordinary-document-binding/binding.json').read_text())
(root/('parent-qualification-audit.json' if len(selected)==2 else 'parent-'+selected[0][0]+'-audit.json')).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({p:{k:v for k,v in r.items() if k in ['status','directXmlFactCount','rowCount','proofCount','rollbackComplete']} for p,r in report['profiles'].items()},indent=2))
