import hashlib,json,re,xml.etree.ElementTree as ET
from pathlib import Path
root=Path('/mnt/wsl/story49-group3a-b1ye__ne');out=root/'ordinary';report={'status':'passed','suites':{},'explicitExclusions':[],'newControlCoverage':{},'ownerFocus':{}}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def parse(p,notrun=0):
 r=ET.parse(p).getroot();a=r.findall('assembly');t=r.findall('.//test');assert a and t
 for x in a:
  assert all(int(x.get(k,'0'))==0 for k in ['errors','failed','skipped'])
  assert int(x.get('total'))==len(x.findall('.//test'))
 assert sum(int(x.get('not-run','0')) for x in a)==notrun
 assert all(x.get('result') in ['Pass','NotRun'] for x in t)
 assert sum(x.get('result')=='NotRun' for x in t)==notrun
 return {'passed':sum(x.get('result')=='Pass' for x in t),'notRun':notrun,'total':len(t),'sha256':sha(p)},t
inventories={}
for suite,file,notrun in [('UnitTests','UnitTests.xml',0),('PropertyTests','PropertyTests.xml',0),('ArchitectureTests','ArchitectureTests-clean-env.xml',0),('IntegrationTests','IntegrationTests.xml',7)]:
 data,t=parse(out/file,notrun);report['suites'][suite]={'xml':file,**data};inventories[suite]=t
 log=(out/(suite+'-build.log')).read_text();assert 'Build succeeded.' in log and '0 Warning(s)' in log and '0 Error(s)' in log
for t in inventories['IntegrationTests']:
 if t.get('result')!='NotRun':continue
 key=(t.get('type'),t.get('method'));row={'type':key[0],'method':key[1],'ordinaryResult':'NotRun','canonical':{}}
 for attempt in ['full4','ci1']:
  matches=[]
  for p in (root/attempt/'gate').glob('*.xml'):
   for x in ET.parse(p).getroot().findall('.//test'):
    if (x.get('type'),x.get('method'))==key and x.get('result')=='Pass':matches.append({'xml':p.name,'result':'Pass'})
  assert matches,key;row['canonical'][attempt]=matches
 report['explicitExclusions'].append(row)
expected={'UnsafeSentryPortsAreRefused':4,'SidecarRewriteIsolatesEveryConfigurationAndSelectsTheOwnedControlPlane':2,'SelectedControlPlaneAndOwnedSchedulerVolumeMustBothBeReleased':2,'MissingProofVolumeSkipsOnlyTheSchedulerOwnershipProbe':1,'ActorReadinessRequiresTheQualifiedDaprRuntime':4}
for name,count in expected.items():
 tests=[t for t in inventories['IntegrationTests'] if t.get('method')==name];assert len(tests)==count and all(t.get('result')=='Pass' for t in tests),name;report['newControlCoverage'][name]={'passedCases':count,'xml':'IntegrationTests.xml'}
for name,number in [('null',7),('component',8)]:
 data,tests=parse(root/'owner-focus'/(name+'.xml'));assert data['passed']==number;report['ownerFocus'][name]=data
 log=(root/'owner-focus'/(name+'-build.log')).read_text();assert 'Build succeeded.' in log and '0 Warning(s)' in log and '0 Error(s)' in log
scripts=(out/'scripts.log').read_text();match=re.search(r'Ran (\d+) tests in',scripts);assert match and scripts.rstrip().endswith('OK');report['scriptContracts']={'passed':int(match.group(1)),'logSHA256':sha(out/'scripts.log')}
remaining=json.loads((out/'remaining-result.json').read_text());assert remaining['status']=='passed' and all(c['exitCode']==0 for c in remaining['commands']);report['remainingCommands']=remaining
report['broadSolutionBuildBlocker']=json.loads((root/'parent-ordinary-build-blocker.json').read_text())
r=ET.parse(out/'ArchitectureTests.xml').getroot();report['initialArchitectureEnvironmentFailure']={'passed':int(r.find('assembly').get('passed')),'failed':int(r.find('assembly').get('failed')),'sha256':sha(out/'ArchitectureTests.xml'),'diagnosis':'build-only Hexalith source-root variables inherited by independently isolated synthetic fixtures; same built assembly passes all398 after removal'}
report['ordinaryDocumentationMetadataBinding']=json.loads((root/'ordinary-document-binding/binding.json').read_text())
report['totalOrdinaryPassed']=sum(s['passed'] for s in report['suites'].values())
(root/'parent-ordinary-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['status','totalOrdinaryPassed','newControlCoverage','ownerFocus','scriptContracts']},indent=2))
