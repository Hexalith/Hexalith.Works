import json,os,subprocess
from pathlib import Path
root=Path('/mnt/wsl/story49-group3a-b1ye__ne');works=root/'final-inputs/works';out=root/'ordinary';env=os.environ.copy();env['TMPDIR']=(root/'selected-tmpdir').read_text().strip();env['DOTNET_USE_POLLING_FILE_WATCHER']='1'
names=('Builds','EventStore','Commons','Tenants','Parties','PolymorphicSerializations');buildenv=env.copy()
for name in names:buildenv['Hexalith'+name+'Root']=str(works/'references'/('Hexalith.'+name))
testenv=buildenv.copy()
for name in names:testenv.pop('Hexalith'+name+'Root',None)
record={'scope':'ordinary Debug source fallback; broad build and initial architecture environment failure retained','removedBuildOnlyEnvironmentVariables':['Hexalith'+name+'Root' for name in names],'commands':[]}
def run(command,log,environment):
 with (out/log).open('w') as stream:result=subprocess.run(command,cwd=works,env=environment,stdout=stream,stderr=subprocess.STDOUT)
 record['commands'].append({'command':command,'log':log,'exitCode':result.returncode})
 if result.returncode:raise SystemExit(result.returncode)
try:
 run(['dotnet',str(works/'tests/Hexalith.Works.ArchitectureTests/bin/Debug/net10.0/Hexalith.Works.ArchitectureTests.dll'),'-noLogo','-result-xml',str(out/'ArchitectureTests-clean-env.xml')],'ArchitectureTests-clean-env.log',testenv)
 run(['dotnet','build','tests/Hexalith.Works.IntegrationTests/Hexalith.Works.IntegrationTests.csproj','-c','Debug','-m:1','-v:minimal','-p:WorksPlatformTestRoot='+str(root/'full4/workspace/platform')],'IntegrationTests-build.log',buildenv)
 run(['dotnet',str(works/'tests/Hexalith.Works.IntegrationTests/bin/Debug/net10.0/Hexalith.Works.IntegrationTests.dll'),'-noLogo','-result-xml',str(out/'IntegrationTests.xml')],'IntegrationTests.log',testenv)
 run(['python3','-m','unittest','discover','-s','scripts/tests','-v'],'scripts.log',testenv)
 record['status']='passed'
finally:
 record.setdefault('status','failed; see exact command');(out/'remaining-result.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
