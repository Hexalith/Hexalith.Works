import hashlib,json,re,subprocess
from pathlib import Path
root=Path('/mnt/wsl/story49-group3a-b1ye__ne');works=root/'final-inputs/works';out=root/'ordinary-document-binding';out.mkdir(exist_ok=False)
revision=subprocess.check_output(['git','ls-tree','HEAD','--','references/Hexalith.EventStore'],cwd=works,text=True).split()[2]
checkout=subprocess.check_output(['git','rev-parse','HEAD'],cwd=works/'references/Hexalith.EventStore',text=True).strip();assert checkout==revision
entries=[]
for name in ('eventstore-api-surface-constraints.md','boundary-decision-record.md'):
 p=works/'docs'/name;b=p.read_bytes();(out/name).write_bytes(b);matches=re.findall(rb'(?m)^<!-- EventStore-current-source: ([0-9a-f]{40}) -->\r?$',b);assert matches==[b'7af8a2a74dff103f286abad144e4959e3e30b902'],(name,matches)
 changed=b.replace(b'<!-- EventStore-current-source: '+matches[0]+b' -->',b'<!-- EventStore-current-source: '+revision.encode()+b' -->');p.write_bytes(changed)
 entries.append({'path':str(p.relative_to(works)),'beforeSHA256':hashlib.sha256(b).hexdigest(),'afterSHA256':hashlib.sha256(changed).hexdigest(),'oldMarker':matches[0].decode(),'selectedGitlinkAndCheckout':revision})
(out/'binding.json').write_text(json.dumps({'scope':'ordinary architecture documentation metadata only; original docs preserved; compiled qualified inputs unchanged','reason':'run-start docs pointed at an older EventStore revision; live concurrent session has independently corrected its own newer marker; no live file altered','files':entries},indent=2)+'\n')
print(json.dumps({'status':'ordinary document markers match exact selected gitlink and checkout','files':len(entries),'revision':revision},indent=2))
