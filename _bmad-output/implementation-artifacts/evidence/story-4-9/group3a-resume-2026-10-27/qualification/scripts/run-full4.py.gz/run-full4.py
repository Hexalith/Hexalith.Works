import importlib.util,json,os,subprocess,sys
from pathlib import Path
os.environ["TMPDIR"]=Path("/mnt/wsl/story49-group3a-b1ye__ne/selected-tmpdir").read_text().strip()
works=Path("/mnt/wsl/story49-group3a-b1ye__ne/final-inputs/works")
artifacts=Path("/mnt/wsl/story49-group3a-b1ye__ne/full4")
specification=importlib.util.spec_from_file_location("works_ci",works/"scripts/verify-platform-parity-ci.py")
coordinator=importlib.util.module_from_spec(specification)
specification.loader.exec_module(coordinator)
command,environment,record,snapshot=coordinator.bootstrap(works,artifacts)
command[command.index("--profile")+1]="full"
if not environment.get("GITHUB_TOKEN"):
    try:
        authentication=subprocess.run(["gh","auth","token"],capture_output=True,text=True,timeout=15)
        if authentication.returncode==0 and authentication.stdout.strip():
            environment["GITHUB_TOKEN"]=authentication.stdout.strip()
    except (FileNotFoundError,subprocess.TimeoutExpired):
        pass
(artifacts/"full-invocation.json").write_text(json.dumps({"command":command,"officialProducerAuthenticationPresent":bool(environment.get("GITHUB_TOKEN")),"environmentPins":{k:v for k,v in environment.items() if k.startswith("Hexalith") or k in ("DOTNET_USE_POLLING_FILE_WATCHER","TMPDIR")}},indent=2)+"\n")
observers=[]
try:
    for name in ("observe-full4-control-plane.py","observe-full4-dcp.py"):
        path=Path("/mnt/wsl/story49-group3a-b1ye__ne")/name
        compile(path.read_text(),str(path),"exec")
        stream=(artifacts/(name+".log")).open("w")
        process=subprocess.Popen([sys.executable,str(path)],stdout=stream,stderr=subprocess.STDOUT,env=environment)
        observers.append((process,stream))
    result=subprocess.run(command,env=environment)
finally:
    (artifacts/"observer-stop.json").write_text(json.dumps({"status":"canonical command terminated; observers stop read-only capture"})+"\n")
    for process,stream in observers:
        try:process.wait(timeout=15)
        except subprocess.TimeoutExpired:process.terminate();process.wait(timeout=10)
        stream.close()
if result.returncode: raise SystemExit(result.returncode)
if snapshot.origin_files(Path(record["platformOrigin"]))!=record["platformSourceFiles"]: raise ValueError("Frozen Platform origin changed")
coordinator.require_unchanged_coordinators(record["coordinatorSha256"])
record["status"]="passed-disposable-synthetic-parity-and-rollback"
record["profile"]="full"
(artifacts/"bootstrap.json").write_text(json.dumps(record,indent=2)+"\n")
