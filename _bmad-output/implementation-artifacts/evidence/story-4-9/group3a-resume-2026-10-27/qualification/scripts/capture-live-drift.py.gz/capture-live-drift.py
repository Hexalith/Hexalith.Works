import difflib,hashlib,json,subprocess
from pathlib import Path
root=Path('/mnt/wsl/story49-group3a-b1ye__ne');live=Path('/home/administrator/projects/hexalith/works');frozen=root/'final-inputs/works';manifest=json.loads((root/'final-inputs/snapshot.json').read_text())
def git(p,*args):return subprocess.check_output(['git',*args],cwd=p,text=True).strip()
def sha(b):return hashlib.sha256(b).hexdigest()
d={'scope':'read-only observation; evidence qualifies captured inputs, not unselected concurrent dependency advances','capturedWorks':manifest['baseline'],'observedWorks':git(live,'rev-parse','HEAD'),'dependencies':{},'ownedFiles':{}}
for p,h in manifest['rootDependencies'].items():d['dependencies'][p]={'capturedRevision':h,'observedCheckout':git(live/p,'rev-parse','HEAD'),'observedGitlink':git(live,'ls-tree','HEAD','--',p).split()[2]}
for p,h in manifest['ownedOverlays'].items():
 if not p.endswith('.cs'):continue
 a=(frozen/p).read_bytes();b=(live/p).read_bytes();kind='exact' if a==b else 'line-ending-only' if a.replace(b'\r\n',b'\n')==b.replace(b'\r\n',b'\n') else 'text-difference'
 d['ownedFiles'][p]={'qualifiedSHA256':sha(a),'observedSHA256':sha(b),'comparison':kind}
 if kind=='text-difference':d['ownedFiles'][p]['diff']='\n'.join(difflib.unified_diff(a.decode().splitlines(),b.decode().splitlines(),fromfile='qualified',tofile='observed'))
(root/'parent-live-drift.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({'observedWorks':d['observedWorks'],'ownedComparisonCounts':{k:sum(v['comparison']==k for v in d['ownedFiles'].values()) for k in ['exact','line-ending-only','text-difference']}},indent=2))
