#!/usr/bin/env bash
set -euo pipefail
task_root=/mnt/wsl/story49-group3a-b1ye__ne/final-inputs/works
task_output=/mnt/wsl/story49-group3a-b1ye__ne/owner-focus
mkdir "$task_output"
export TMPDIR
TMPDIR=$(cat /mnt/wsl/story49-group3a-b1ye__ne/selected-tmpdir)
export HexalithBuildsRoot="$task_root/references/Hexalith.Builds"
export HexalithEventStoreRoot="$task_root/references/Hexalith.EventStore"
export HexalithCommonsRoot="$task_root/references/Hexalith.Commons"
export HexalithPolymorphicSerializationsRoot="$task_root/references/Hexalith.PolymorphicSerializations"
python3 - <<'PY'
from pathlib import Path
root=Path('/mnt/wsl/story49-group3a-b1ye__ne');out=root/'owner-focus';works=root/'final-inputs/works'
s=(Path('/tmp/story49-group3a-custody-null/CustodyNull.csproj')).read_text().replace('/home/administrator/projects/hexalith/works',str(works));(out/'CustodyNull.csproj').write_text(s)
(out/'Directory.Packages.props').write_text('<Project><Import Project="'+str(works/'Directory.Packages.props')+'" /></Project>\n')
for name in ('.editorconfig','global.json'):(out/name).write_bytes((works/name).read_bytes())
PY
cd "$task_root"
dotnet build "$task_output/CustodyNull.csproj" -c Debug --artifacts-path "$task_output/null-artifacts" -m:1 -v:minimal > "$task_output/null-build.log" 2>&1
dotnet "$task_output/null-artifacts/bin/CustodyNull/debug/CustodyNull.dll" -noLogo -result-xml "$task_output/null.xml" > "$task_output/null-tests.log" 2>&1
cd "$task_root/references/Hexalith.Platform"
dotnet build tests/Hexalith.Platform.Custody.Component.Tests/Hexalith.Platform.Custody.Component.Tests.csproj -c Debug --artifacts-path "$task_output/component-artifacts" -m:1 -v:minimal > "$task_output/component-build.log" 2>&1
dotnet "$task_output/component-artifacts/bin/Hexalith.Platform.Custody.Component.Tests/debug/Hexalith.Platform.Custody.Component.Tests.dll" -noLogo -class Hexalith.Platform.Custody.Component.Tests.CustodyComponentMatrixTests -result-xml "$task_output/component.xml" > "$task_output/component-tests.log" 2>&1
