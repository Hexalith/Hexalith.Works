import hashlib,importlib,json,os,subprocess,sys,time,xml.etree.ElementTree as ET
from pathlib import Path
root=Path('/mnt/wsl/story49-group3a-b1ye__ne'); old=root/'full3'; output=root/'focused-restart-diagnostic';output.mkdir(exist_ok=False);(output/'gate').mkdir()
ledger=json.loads((old/'gate/ledger.json').read_text());bootstrap=json.loads((old/'bootstrap.json').read_text())
platform=Path(bootstrap['platformRoot']);works=Path(bootstrap['worksRoot'])
for name,digest in ledger['verifierHelpers'].items():assert hashlib.sha256((platform/'eng'/name).read_bytes()).hexdigest()==digest
assert hashlib.sha256((platform/'eng/verify_works_host.py').read_bytes()).hexdigest()==ledger['verifierSha256']
sys.path.insert(0,str(platform/'eng'));verifier=importlib.import_module('verify_works_host');isolated=importlib.import_module('isolated_daprd')
def unchanged():
    ephemeral=verifier.host_ephemeral_port_range();reserved=verifier.host_reserved_port_ranges()
    assert list(ephemeral)==ledger['controlPlanePortSelection']['excludedEphemeralRange']
    assert [list(x) for x in reserved]==ledger['controlPlanePortSelection']['excludedReservedRanges']
    verifier.require_unchanged_inputs(ledger,works,platform,Path(bootstrap['platformSourceBinding']),ephemeral,reserved)
record={'status':'incomplete','scope':'One unchanged restart-and-restore fact with read-only own-resource observers; zero complete full/CI acceptance credit.'};observers=[]
try:
    unchanged();record['strictInputsBefore']='passed'
    binding=isolated.prepare(output/'isolated-daprd',ledger['isolatedRuntime']['runtime'],ledger['controlPlanePortSelection']['selected']['sentry'])
    assert binding['runtimeSha256']==ledger['qualifiedToolchain']['runtimeSha256']
    environment=os.environ.copy();environment.pop('GITHUB_TOKEN',None);environment.pop('GH_TOKEN',None);environment.update(ledger['runtimeEnvironment'])
    environment.update({'TMPDIR':(root/'selected-tmpdir').read_text().strip(),'WORKS_PLATFORM_DAPRD_RUNTIME_PATH':str(output/'isolated-daprd'),'WORKS_PLATFORM_HOST_EVIDENCE':str(output/'host-starts.jsonl'),'WORKS_SDK_PROOF_EVIDENCE_PATH':str(output/'persisted-states.jsonl')})
    (output/'gate/ledger.json').write_text(json.dumps({'status':'diagnostic-only; incomplete','controlPlanePorts':ledger['controlPlanePortSelection']['selected']})+'\n')
    for name in ('observe-focused-control-plane.py','observe-focused-dcp.py'):
        compile((root/name).read_text(),str(root/name),'exec')
        stream=(output/(name+'.log')).open('w');process=subprocess.Popen([sys.executable,str(root/name)],stdout=stream,stderr=subprocess.STDOUT,env=environment);observers.append((process,stream))
    command=[str(Path(ledger['consumer']['root'])/'Hexalith.Works.IntegrationTests'),'-noLogo','-explicit','on','-method','Hexalith.Works.IntegrationTests.WorksSdkRecoveryPipelineSmokeTests.SdkRemindersAndCascadeConvergeThroughPersistedReceiptsAcrossRestart','-result-xml',str(output/'restart.xml')]
    record.update({'command':command,'TMPDIR':environment['TMPDIR'],'isolatedRuntime':binding,'observerSha256':{name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in ('observe-focused-control-plane.py','observe-focused-dcp.py')}})
    (output/'command.json').write_text(json.dumps(record,indent=2)+'\n')
    with (output/'test.log').open('w') as stream:result=verifier.run_owned(command,cwd=works,env=environment,stdout=stream,timeout=1800)
    record['exitCode']=result.returncode
    unchanged();record['strictInputsAfter']='passed'
    if result.returncode:raise ValueError('Focused restart/restore failed; see restart.xml and read-only observers')
    record['test']=verifier.require_passed_tests(output/'restart.xml',['SdkRemindersAndCascadeConvergeThroughPersistedReceiptsAcrossRestart'])
    starts=[json.loads(x) for x in (output/'host-starts.jsonl').read_text().splitlines() if x]
    assert starts and any(x['role']=='retained-rollback' for x in starts)
    for start in starts:
        assert start['controlPlanePorts']==ledger['controlPlanePortSelection']['selected']
        expected=ledger['host'] if start['role']=='platform-target' else {'assembly':ledger['retainedHostSource']['assembly'],'sha256':ledger['retainedHostSource']['assemblySha256']}
        assert start['assembly']==expected['assembly'] and start['sha256'].lower()==expected['sha256']
        for module in start['runtimeModules']:
            assert module['entrySha256'].lower()==ledger['runtimeArtifacts'][module['entry']]
            for sdk in module['sdkAssemblies']:
                assert sdk['version']==ledger['selectedSdk']['version']+'.0' and hashlib.sha256(Path(sdk['path']).read_bytes()).hexdigest()==sdk['sha256'].lower()
    record['launcherBinding']=isolated.verify(output/'isolated-daprd',binding,starts)
    record['status']='focused-restart-and-restore-passed; no full/CI credit'
except BaseException as error:record['failure']=type(error).__name__+': '+str(error)
finally:
    (output/'finished.json').write_text(json.dumps(record,indent=2)+'\n')
    for process,stream in observers:
        try:process.wait(timeout=15)
        except subprocess.TimeoutExpired:process.terminate();process.wait(timeout=10)
        stream.close()
print(json.dumps({k:v for k,v in record.items() if k in ('status','scope','exitCode','test','strictInputsBefore','strictInputsAfter','failure')},indent=2))
raise SystemExit(0 if record['status'].startswith('focused-restart-and-restore-passed') else 1)
