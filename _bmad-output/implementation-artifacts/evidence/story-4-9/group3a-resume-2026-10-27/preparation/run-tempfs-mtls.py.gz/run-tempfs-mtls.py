import hashlib, importlib, json, os, subprocess, sys, xml.etree.ElementTree as ET
from pathlib import Path
root=Path('/mnt/wsl/story49-group3a-b1ye__ne')
gate=root/'full2/gate'; output=root/'tempfs-mtls'; output.mkdir(exist_ok=False)
ledger=json.loads((gate/'ledger.json').read_text()); bootstrap=json.loads((root/'full2/bootstrap.json').read_text())
platform=Path(bootstrap['platformRoot']); works=Path(bootstrap['worksRoot'])
for name,digest in ledger['verifierHelpers'].items():
    assert hashlib.sha256((platform/'eng'/name).read_bytes()).hexdigest()==digest
assert hashlib.sha256((platform/'eng/verify_works_host.py').read_bytes()).hexdigest()==ledger['verifierSha256']
sys.path.insert(0,str(platform/'eng'))
verifier=importlib.import_module('verify_works_host'); isolated=importlib.import_module('isolated_daprd')
def unchanged():
    ephemeral=verifier.host_ephemeral_port_range(); reserved=verifier.host_reserved_port_ranges()
    assert list(ephemeral)==ledger['controlPlanePortSelection']['excludedEphemeralRange']
    assert [list(x) for x in reserved]==ledger['controlPlanePortSelection']['excludedReservedRanges']
    verifier.require_unchanged_inputs(ledger,works,platform,Path(bootstrap['platformSourceBinding']),ephemeral,reserved)
record={'status':'incomplete','scope':'Focused mTLS/environment diagnostic only; no complete full/CI or rollback acceptance credit.'}
try:
    unchanged(); record['strictInputsBefore']='passed'
    binding=isolated.prepare(output/'isolated-daprd',ledger['isolatedRuntime']['runtime'],ledger['controlPlanePortSelection']['selected']['sentry'])
    assert binding['runtimeSha256']==ledger['qualifiedToolchain']['runtimeSha256']
    environment=os.environ.copy(); environment.pop('GITHUB_TOKEN',None); environment.pop('GH_TOKEN',None)
    environment.update(ledger['runtimeEnvironment'])
    environment.update({'TMPDIR':(root/'selected-tmpdir').read_text().strip(),'WORKS_PLATFORM_DAPRD_RUNTIME_PATH':str(output/'isolated-daprd'),'WORKS_PLATFORM_HOST_EVIDENCE':str(output/'host-starts.jsonl'),'WORKS_SDK_PROOF_EVIDENCE_PATH':str(output/'persisted-states.jsonl')})
    command=[str(Path(ledger['consumer']['root'])/'Hexalith.Works.IntegrationTests'),'-noLogo','-explicit','on','-method','Hexalith.Works.IntegrationTests.WorksMtlsAuthorizationSmokeTests.Mtls_allows_event_store_and_denies_an_unauthorized_caller_at_works_process','-result-xml',str(output/'mtls.xml')]
    record.update({'command':command,'TMPDIR':environment['TMPDIR'],'isolatedRuntime':binding})
    with (output/'test.log').open('w') as stream:
        result=verifier.run_owned(command,cwd=works,env=environment,stdout=stream,timeout=1800)
    record['exitCode']=result.returncode
    unchanged();record['strictInputsAfter']='passed'
    if result.returncode: raise ValueError('Focused mTLS fact failed; see test.log')
    record['test']=verifier.require_passed_tests(output/'mtls.xml',['Mtls_allows_event_store_and_denies_an_unauthorized_caller_at_works_process'])
    starts=verifier.verify_host_records(output/'host-starts.jsonl',Path(ledger['host']['assembly']),platform,ledger['selectedSdk']['version'],runtime_artifacts=ledger['runtimeArtifacts'],host_runtime=Path(ledger['platformRuntimeIdentity']['path']) if 'path' in ledger['platformRuntimeIdentity'] else None,control_plane_ports=ledger['controlPlanePortSelection']['selected'],retained_assembly=Path(ledger['retainedHostSource']['assembly']))
    record['launchBinding']=isolated.verify(output/'isolated-daprd',binding,starts)
    record['status']='focused-mtls-and-temporary-filesystem-passed'
except BaseException as error:
    record['failure']=type(error).__name__+': '+str(error)
finally:
    (output/'result.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k in ('status','scope','exitCode','test','strictInputsBefore','strictInputsAfter','failure')},indent=2))
raise SystemExit(0 if record['status']=='focused-mtls-and-temporary-filesystem-passed' else 1)
