import importlib.util,json,os,subprocess
from pathlib import Path
works=Path("/mnt/wsl/story49-group3a-b1ye__ne/final-inputs/works")
artifacts=Path("/mnt/wsl/story49-group3a-b1ye__ne/full2")
specification=importlib.util.spec_from_file_location("works_ci",works/"scripts/verify-platform-parity-ci.py")
coordinator=importlib.util.module_from_spec(specification)
specification.loader.exec_module(coordinator)
command,environment,record,snapshot=coordinator.bootstrap(works,artifacts)
command[command.index("--profile")+1]="full"
if not environment.get("GITHUB_TOKEN"):
    try:
        authentication=subprocess.run(["gh","auth","token"],capture_output=True,text=True,timeout=15)
        if authentication.returncode==0 and authentication.stdout.strip():
            environment["GITHUB_TOKEN"]=authentication.stdout.strip()
    except (FileNotFoundError,subprocess.TimeoutExpired):
        pass
(artifacts/"full-invocation.json").write_text(json.dumps({"command":command,"officialProducerAuthenticationPresent":bool(environment.get("GITHUB_TOKEN")),"environmentPins":{k:v for k,v in environment.items() if k.startswith("Hexalith") or k=="DOTNET_USE_POLLING_FILE_WATCHER"}},indent=2)+"\n")
result=subprocess.run(command,env=environment)
if result.returncode: raise SystemExit(result.returncode)
if snapshot.origin_files(Path(record["platformOrigin"]))!=record["platformSourceFiles"]: raise ValueError("Frozen Platform origin changed")
coordinator.require_unchanged_coordinators(record["coordinatorSha256"])
record["status"]="passed-disposable-synthetic-parity-and-rollback"
record["profile"]="full"
(artifacts/"bootstrap.json").write_text(json.dumps(record,indent=2)+"\n")
