#!/usr/bin/env bash
set -euo pipefail
task_root=/mnt/wsl/story49-group3a-b1ye__ne/final-inputs/works
task_output=/mnt/wsl/story49-group3a-b1ye__ne/ordinary
mkdir "$task_output"
cd "$task_root"
export TMPDIR
TMPDIR=$(cat /mnt/wsl/story49-group3a-b1ye__ne/selected-tmpdir)
export DOTNET_USE_POLLING_FILE_WATCHER=1
export HexalithBuildsRoot="$task_root/references/Hexalith.Builds"
export HexalithEventStoreRoot="$task_root/references/Hexalith.EventStore"
export HexalithCommonsRoot="$task_root/references/Hexalith.Commons"
export HexalithTenantsRoot="$task_root/references/Hexalith.Tenants"
export HexalithPartiesRoot="$task_root/references/Hexalith.Parties"
export HexalithPolymorphicSerializationsRoot="$task_root/references/Hexalith.PolymorphicSerializations"
dotnet restore Hexalith.Works.slnx -p:Configuration=Debug -m:1 -v:minimal > "$task_output/restore.log" 2>&1
dotnet build Hexalith.Works.slnx --configuration Debug --no-restore -m:1 -v:minimal > "$task_output/build.log" 2>&1
for task_suite in UnitTests PropertyTests ArchitectureTests IntegrationTests; do
    task_project="Hexalith.Works.$task_suite"
    dotnet "tests/$task_project/bin/Debug/net10.0/$task_project.dll" -noLogo -result-xml "$task_output/$task_suite.xml" > "$task_output/$task_suite.log" 2>&1
done
