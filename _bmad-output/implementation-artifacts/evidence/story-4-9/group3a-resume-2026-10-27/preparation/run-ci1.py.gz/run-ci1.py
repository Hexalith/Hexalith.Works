import json,os,subprocess,sys,time
from pathlib import Path
root=Path('/mnt/wsl/story49-group3a-b1ye__ne');works=root/'final-inputs/works';artifacts=root/'ci1'
environment=os.environ.copy();environment['TMPDIR']=(root/'selected-tmpdir').read_text().strip()
if not environment.get('GITHUB_TOKEN'):
    try:
        authentication=subprocess.run(['gh','auth','token'],capture_output=True,text=True,timeout=15)
        if authentication.returncode==0 and authentication.stdout.strip():environment['GITHUB_TOKEN']=authentication.stdout.strip()
    except (FileNotFoundError,subprocess.TimeoutExpired):pass
command=['bash','scripts/verify-platform-parity-ci.sh','--artifacts-path',str(artifacts)]
record={'status':'actual-ci-entry-point-running; parent audit pending','command':command,'cwd':str(works),'TMPDIR':environment['TMPDIR'],'officialProducerAuthenticationPresent':bool(environment.get('GITHUB_TOKEN'))};observers=[]
process=subprocess.Popen(command,cwd=works,env=environment)
try:
    started=time.monotonic()
    while process.poll() is None and not (artifacts/'gate/ledger.json').exists() and time.monotonic()-started<90:time.sleep(0.2)
    if (artifacts/'gate/ledger.json').exists():
        for name in ('observe-ci1-control-plane.py','observe-ci1-dcp.py'):
            script=root/name;compile(script.read_text(),str(script),'exec');stream=(artifacts/(name+'.log')).open('w')
            observer=subprocess.Popen([sys.executable,str(script)],stdout=stream,stderr=subprocess.STDOUT,env=environment);observers.append((observer,stream))
    record['exitCode']=process.wait()
    record['status']='actual-ci-entry-point-exited; parent audit pending'
finally:
    artifacts.mkdir(parents=True,exist_ok=True)
    (artifacts/'observer-stop.json').write_text(json.dumps({'status':'actual CI entry point terminated; observers stop read-only capture'})+'\n')
    for observer,stream in observers:
        try:observer.wait(timeout=15)
        except subprocess.TimeoutExpired:observer.terminate();observer.wait(timeout=10)
        stream.close()
    (artifacts/'entry-point-result.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
raise SystemExit(record.get('exitCode',1))
