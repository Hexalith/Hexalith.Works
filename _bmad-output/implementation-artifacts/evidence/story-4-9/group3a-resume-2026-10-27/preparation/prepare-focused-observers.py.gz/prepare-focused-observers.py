from pathlib import Path
root=Path('/mnt/wsl/story49-group3a-b1ye__ne')
source=Path('/tmp/story49-final-20261026T195205Z')
control=(source/'observe-full2-control-plane.py').read_text()
control=control.replace("/'full2'","/'focused-restart-diagnostic'",1)
control=control.replace("ROOTS=[SOURCE_RUN/'full1/workspace/platform/DaprComponents',RUN/'gate/retained-works-source'];APPHOST=SOURCE_RUN/'full1/workspace/platform/apphost.cs'", "ROOTS=[SOURCE_RUN/'full3/workspace/platform/DaprComponents',SOURCE_RUN/'full3/gate/retained-works-source'];APPHOST=SOURCE_RUN/'full3/gate/retained-works-source/src/Hexalith.Works.AppHost/Hexalith.Works.AppHost.csproj'")
control=control.replace('10800','2400').replace("if L.get('failure') or L.get('status')=='passed-disposable-synthetic-parity-and-rollback':break", "if (RUN/'finished.json').exists():break")
(root/'observe-focused-control-plane.py').write_text(control)
script=(source/'observe-full2-dcp.py').read_text().replace("/'full2'","/'focused-restart-diagnostic'",1).replace('10800','2400')
script=script.replace("NAMES=['dapr-sentry','dapr-placement-mtls','dapr-scheduler-mtls']", "NAMES=['dapr-sentry','dapr-placement-mtls','dapr-scheduler-mtls']\nEXECUTABLES=['eventstore','works','works-ha','eventstore-operations','eventstore-admin','eventstore-dapr-cli','works-dapr-cli','works-ha-dapr-cli','eventstore-operations-dapr-cli','eventstore-admin-dapr-cli']")
script=script.replace("'containers':[],'services':[],'endpoints':[]", "'containers':[],'services':[],'endpoints':[],'executables':[]")
script=script.replace("for kind in ['containers','services','endpoints']:", "for kind in ['containers','services','endpoints','executables']:")
needle="    elif kind=='services':"
insert='''    elif kind=='executables':
     if not any(name==n or name.startswith(n+'-') for n in EXECUTABLES):continue
     item={'metadata':meta,'status':{k:v for k,v in status.items() if k in ['state','processId','pid','exitCode','startupTimestamp','finishTimestamp']},'statusFieldNames':sorted(status)}
     uid=obj['metadata']['uid']; files=set()
     for key,value in status.items():
      if isinstance(value,str) and re.search(r'std.?out|std.?err',key,re.I):
       candidate=Path(value)
       try:
        if candidate.is_absolute() and candidate.resolve().is_relative_to(config.parent.resolve()) and candidate.is_file() and not candidate.is_symlink():files.add(candidate)
       except (OSError,ValueError):pass
     for candidate in config.parent.iterdir():
      if uid in candidate.name and re.search(r'_out_|_err_|_startout_|_starterr_|stdout|stderr|\\.log$',candidate.name) and candidate.is_file() and not candidate.is_symlink():files.add(candidate)
     item['logFiles']=[str(x) for x in sorted(files)]
     for log in sorted(files):
      try:raw=log.read_bytes()[-65536:]
      except (FileNotFoundError,PermissionError):continue
      digest=hashlib.sha256(raw).hexdigest()
      if (str(log),digest) not in logged:
       lines=raw.decode(errors='replace').splitlines()[-100:]
       safe=[line for line in lines if not re.search(r'environment|effectiveEnv|-----BEGIN|authorization|bearer|password|token|private.key',line,re.I)]
       put('executable-logs.jsonl',{'at':now(),'creatorPid':pid,'resource':name,'uid':uid,'source':str(log),'nativeTailSha256':digest,'redactedLines':len(lines)-len(safe),'lines':safe})
       logged.add((str(log),digest))
     snapshot[kind].append(item)
'''
assert script.count(needle)==1
script=script.replace(needle,insert+needle)
script=script.replace("if owner_ledger.get('failure') or owner_ledger.get('status')=='passed-disposable-synthetic-parity-and-rollback':break", "if (D/'finished.json').exists():break")
(root/'observe-focused-dcp.py').write_text(script)
print('Prepared read-only observers with exact config/creator/UID admission; executable log capture excludes environments and credentials.')
