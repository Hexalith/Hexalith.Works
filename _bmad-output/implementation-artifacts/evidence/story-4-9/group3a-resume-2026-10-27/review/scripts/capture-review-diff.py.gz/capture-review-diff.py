import hashlib,json,subprocess,tempfile,sys
from pathlib import Path
live=Path('/home/administrator/projects/hexalith/works');run=Path('/mnt/wsl/story49-group3a-b1ye__ne');snapshot=json.loads((run/'final-inputs/snapshot.json').read_text());out=Path(sys.argv[1]) if len(sys.argv)>1 else Path(tempfile.mkdtemp(prefix='bmad-build-4-9-review-'));baseline='18e94d388ab0abd8be363b361d0b2fee762359e7'
def capture(command,path,cwd):
 with path.open('wb') as stream:subprocess.run(command,cwd=cwd,stdout=stream,check=True)
def files(command,cwd):return subprocess.check_output(command,cwd=cwd).split(b'\0')
full=out/'baseline.diff';capture(['git','diff','--no-ext-diff','--submodule=short',baseline,'--'],full,live)
untracked=[n.decode() for n in files(['git','ls-files','--others','--exclude-standard','-z'],live) if n]
with full.open('ab') as stream:
 for name in untracked:
  r=subprocess.run(['git','diff','--no-index','--','/dev/null',name],cwd=live,stdout=stream);assert r.returncode in (0,1),(name,r.returncode)
capture(['git','diff','--numstat','--submodule=short',baseline,'--'],out/'baseline-index.txt',live)
with (out/'baseline-index.txt').open('a') as stream:
 for name in untracked:stream.write('untracked\t'+name+'\n')
works=[p for p in snapshot['ownedOverlays'] if p.endswith('.cs') and not p.startswith('references/')]
platform=[p.removeprefix('references/Hexalith.Platform/') for p in snapshot['ownedOverlays'] if p.endswith('.cs') and p.startswith('references/Hexalith.Platform/')]
capture(['git','diff','--ignore-space-at-eol','--no-ext-diff','--submodule=short',snapshot['baseline'],'--',*works],out/'owned-works.diff',live)
owner=live/'references/Hexalith.Platform';capture(['git','diff','--ignore-space-at-eol','--no-ext-diff',snapshot['rootDependencies']['references/Hexalith.Platform'],'--',*platform],out/'owned-platform.diff',owner)
metadata={'baseline':baseline,'observedWorks':subprocess.check_output(['git','rev-parse','HEAD'],cwd=live,text=True).strip(),'untrackedCount':len(untracked),'purpose':'complete root unified diff plus separate readable owner patch views; no Git staging or index mutation','files':{p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in out.iterdir() if p.name!='capture.json'}}
(out/'capture.json').write_text(json.dumps(metadata,indent=2)+'\n');(run/'selected-diff-directory').write_text(str(out)+'\n');print(json.dumps({'directory':str(out),'files':metadata['files']},indent=2))
