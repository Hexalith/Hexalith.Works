import gzip,hashlib,json,re
from pathlib import Path
root=Path('/mnt/wsl/story49-group3a-b1ye__ne');live=Path('/home/administrator/projects/hexalith/works');out=live/'_bmad-output/implementation-artifacts/evidence/story-4-9/group3a-resume-2026-10-27';manifest=out/'qualification-manifest.json';d=json.loads(manifest.read_text());entries=d['files'];known={e['path']:e for e in entries}
def keep(p,relative):
 b=p.read_bytes();target=out/(relative+'.gz');key=str(target.relative_to(out));digest=hashlib.sha256(b).hexdigest()
 if key in known:assert known[key]['nativeSha256']==digest,key;return
 assert not target.exists(),target
 target.parent.mkdir(parents=True,exist_ok=True);stored=gzip.compress(b,mtime=0);target.write_bytes(stored);e={'path':key,'sha256':hashlib.sha256(stored).hexdigest(),'nativePath':str(p),'nativeSha256':digest,'nativeBytes':len(b)};entries.append(e);known[key]=e
for p in sorted(root.glob('parent-review*.json')):keep(p,'review/'+p.name)
for p in sorted((root/'reviews').iterdir()):keep(p,'review/reports/'+p.name)
for p in sorted((root/'review-controls').iterdir()):
 if p.is_file():keep(p,'review/controls/'+p.name)
for name in ['Program.cs','Probe.csproj','global.json']:keep(root/'review-controls/guard'/name,'review/controls/guard/'+name)
for name in ['record-review.py','capture-review-diff.py','seal-final-evidence.py']:keep(root/name,'review/scripts/'+name)
for name in ['commit-message.txt','commitlint.log']:keep(root/name,'completion/'+name)
diff=Path((root/'selected-diff-directory').read_text().strip())
for name in ['capture.json','baseline-index.txt','owned-works.diff','owned-platform.diff']:keep(diff/name,'review/diff/'+name)
# The complete historical diff is indexed and hash-bound rather than copied as an unbounded generated artifact.
for entry in entries:
 b=(out/entry['path']).read_bytes();assert hashlib.sha256(b).hexdigest()==entry['sha256'];assert hashlib.sha256(gzip.decompress(b)).hexdigest()==entry['nativeSha256']
for entry in json.loads((out/'preparation-manifest.json').read_text())['files']:
 b=(out/entry['path']).read_bytes();assert hashlib.sha256(b).hexdigest()==entry['sha256'];assert hashlib.sha256(gzip.decompress(b)).hexdigest()==entry['nativeSha256']
d['status']='qualified on recorded inputs; parent acceptance and all three independent review layers complete';manifest.write_text(json.dumps(d,indent=2)+'\n')
spec=live/'_bmad-output/implementation-artifacts/spec-4-9-migrate-works-hosting-to-the-platform-boundary.md';text=spec.read_text();assert "status: 'done'" in text;assert not re.search(r'^- \[ \]',text,re.M);block=re.search(r'<frozen-after-approval\b[^>]*>.*?</frozen-after-approval>',text,re.S).group();assert hashlib.sha256(block.encode()).hexdigest()=='de1c74eee26581eab23b760d595d93951471cad0074b3b57eb45a35058f7ef5d';sprint=(live/'_bmad-output/implementation-artifacts/sprint-status.yaml').read_text();assert '  4-9-migrate-works-hosting-to-the-platform-boundary: review' in sprint
report={'status':'complete-on-recorded-inputs','specStatus':'done','sprintStatus':'review','reviewLayers':3,'findingsIndividuallyTriaged':10,'newPreCutoverFollowUps':3,'currentPatchesOrLoopbacks':0,'qualification':{'fullXmlFacts':606,'ciXmlFacts':462,'rowsEach':11,'proofsEach':44,'rollbackEach':True,'finalClosureEach':True},'ordinary':{'passed':2031,'explicitLiveExclusionsWithBothProfilePasses':7,'pythonControls':82,'ownerFocusedCases':15},'frozenIntentSHA256':hashlib.sha256(block.encode()).hexdigest(),'scope':'captured run-start revisions plus exact owned overlays; concurrent dependency advances preserved outside these bindings','broadBuildLimitation':'captured-baseline Debug solution build refused138 existing Platform.Secrets.Runtime analyzer diagnostics; individual source test-project builds pass with recorded test-only source-root selection and no analyzer suppression','remainingHumanReview':'sprint retains later integration3B–3E,docs/contracts and submodule review-group tracking','terminalCommit':'requested workflow authorizes a local completion commit only; commit identifier recorded outside this self-bound packet after creation','files':[]}
for p in sorted(out.rglob('*')):
 if p.is_file() and p.name!='completion-manifest.json':report['files'].append({'path':str(p.relative_to(out)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(out/'completion-manifest.json').write_text(json.dumps(report,indent=2)+'\n');(root/'completion-seal-result.json').write_text(json.dumps({'files':len(report['files']),'completionManifestSHA256':hashlib.sha256((out/'completion-manifest.json').read_bytes()).hexdigest(),'qualifiedNativeBindings':len(entries)},indent=2)+'\n');print((root/'completion-seal-result.json').read_text())
