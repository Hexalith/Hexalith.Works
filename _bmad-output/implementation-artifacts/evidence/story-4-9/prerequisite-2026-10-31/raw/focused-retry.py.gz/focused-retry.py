import datetime,json,os,subprocess,sys
from pathlib import Path
ROOT=Path('/tmp/story49-qualification-20261031-pMAQI0');WORKS=ROOT/'baseline/works';env=os.environ.copy()|{'HexalithBuildsRoot':str(WORKS/'references/Hexalith.Builds'),'DOTNET_USE_POLLING_FILE_WATCHER':'1'}
records=[]
def run(name,args):
 print(name,flush=True);r={'name':name,'command':args,'cwd':str(WORKS),'startedAt':datetime.datetime.now(datetime.UTC).isoformat()}
 with (ROOT/(name+'.log')).open('w') as log:p=subprocess.run(args,cwd=WORKS,env=env,stdout=log,stderr=subprocess.STDOUT)
 r|={'exitCode':p.returncode,'finishedAt':datetime.datetime.now(datetime.UTC).isoformat()};records.append(r);(ROOT/'package-focus2-commands.json').write_text(json.dumps(records,indent=2)+'\n');return p.returncode
proj='tests/Hexalith.Works.IntegrationTests/Hexalith.Works.IntegrationTests.csproj'
focus=ROOT/'package-contract-focus2.targets'
focus.write_text("""<Project>
  <ItemGroup Condition="'$(MSBuildProjectName)' == 'Hexalith.Works.IntegrationTests'">
    <ProjectReference Remove="@(ProjectReference)" Condition="'%(ProjectReference.Filename)' == 'Hexalith.Platform.Composition'" />
    <Compile Remove="@(Compile)" />
    <Compile Include="$(MSBuildProjectDirectory)/WorksSdkPackageContractTests.cs" />
  </ItemGroup>
</Project>
""")
command=['dotnet','build',proj,'--configuration','Release','-p:UseHexalithProjectReferences=false','--artifacts-path',str(ROOT/'package-focus2'),'-p:CustomBeforeMicrosoftCommonTargets='+str(focus),'-m:1','-v:minimal']
if run('package-contract-focus2-build',command)==0:
 executable=ROOT/'package-focus2/bin/Hexalith.Works.IntegrationTests/release/Hexalith.Works.IntegrationTests'
 run('package-contract-focus2-tests',[str(executable),'-noLogo','-class','Hexalith.Works.IntegrationTests.WorksSdkPackageContractTests','-result-xml',str(ROOT/'package-contract-focus2.xml')])
