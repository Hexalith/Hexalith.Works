import datetime,json,os,subprocess,sys
from pathlib import Path
ROOT=Path('/tmp/story49-qualification-20261031-pMAQI0');WORKS=ROOT/'baseline/works';env=os.environ.copy()|{'HexalithBuildsRoot':str(WORKS/'references/Hexalith.Builds'),'DOTNET_USE_POLLING_FILE_WATCHER':'1'}
records=[]
def run(name,args):
 print(name,flush=True);r={'name':name,'command':args,'cwd':str(WORKS),'startedAt':datetime.datetime.now(datetime.UTC).isoformat()}
 with (ROOT/(name+'.log')).open('w') as log:p=subprocess.run(args,cwd=WORKS,env=env,stdout=log,stderr=subprocess.STDOUT)
 r|={'exitCode':p.returncode,'finishedAt':datetime.datetime.now(datetime.UTC).isoformat()};records.append(r);(ROOT/'focused-commands.json').write_text(json.dumps(records,indent=2)+'\n');return p.returncode
proj='tests/Hexalith.Works.IntegrationTests/Hexalith.Works.IntegrationTests.csproj'
actual=['dotnet','build',proj,'--configuration','Release','-p:UseHexalithProjectReferences=false','--artifacts-path',str(ROOT/'baseline-release'),'-m:1','-v:minimal']
run('baseline-release-build',actual)
focus=ROOT/'package-contract-focus.targets'
focus.write_text("""<Project>
  <ItemGroup Condition="'$(MSBuildProjectName)' == 'Hexalith.Works.IntegrationTests'">
    <ProjectReference Remove="@(ProjectReference)" Condition="'%(ProjectReference.Filename)' == 'Hexalith.Platform.Composition'" />
    <Compile Remove="@(Compile)" />
    <Compile Include="$(MSBuildProjectDirectory)/WorksSdkPackageContractTests.cs" />
  </ItemGroup>
</Project>
""")
command=['dotnet','build',proj,'--configuration','Release','-p:UseHexalithProjectReferences=false','--artifacts-path',str(ROOT/'package-focus'),'-p:CustomBeforeMicrosoftCommonTargets='+str(focus),'-m:1','-v:minimal']
if run('package-contract-focus-build',command)==0:
 executable=ROOT/'package-focus/bin/Hexalith.Works.IntegrationTests/release/Hexalith.Works.IntegrationTests'
 run('package-contract-focus-tests',[str(executable),'-noLogo','-class','Hexalith.Works.IntegrationTests.WorksSdkPackageContractTests','-result-xml',str(ROOT/'package-contract-focus.xml')])
run('release-pin-guard',['dotnet','msbuild',proj,'-nologo','-p:Configuration=Release','-p:UseHexalithProjectReferences=false','-t:ValidateHexalithDependencyMode','-getProperty:HexalithEventStoreVersion,HexalithPartiesVersion,UseHexalithProjectReferences'])
run('parent-script-controls',['python3','-m','unittest','discover','-s','scripts/tests'])
