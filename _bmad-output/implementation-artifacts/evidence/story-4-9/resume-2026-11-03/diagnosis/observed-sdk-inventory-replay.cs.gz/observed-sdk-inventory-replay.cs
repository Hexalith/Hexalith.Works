using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;
using Hexalith.EventStore.Contracts.Routing;
using Hexalith.EventStore.ServiceDefaults.Routing;

string folder = "/tmp/story49-current-20261103-e50fzbzy/tmp/hexalith-route-catalog-Ul3azz";
byte[] observedBytes = File.ReadAllBytes(Path.Combine(folder, "eventstore.observation.json"));
var observation = JsonSerializer.Deserialize<RouteCatalogHostObservation>(observedBytes)!;
var activation = JsonSerializer.Deserialize<RouteCatalogActivation>(File.ReadAllBytes(Path.Combine(folder, "activation.json")))!;
var envelope = RouteCatalogCodec.Decode(activation.CanonicalCatalog, activation.RootDigest);
string Check(byte[] configuration)
{
    try
    {
        RouteCatalogTopologyValidator.ValidateDevelopment(observation.TopologyDocuments[0], configuration,
            envelope, activation.RequiredHosts, observation.AppId, activation.AuxiliaryOperations,
            observation.ReceiverSurface, observation.SelectedAppIds, observation.DeclaredInvocations);
        return "accepted";
    }
    catch (RouteCatalogValidationException failure)
    {
        return string.Join(",", failure.Diagnostics.Select(item => item.Code));
    }
}
const string withdrawn = "/api/v1/commands/status/workload/*/*";
var original = JsonNode.Parse(observation.TopologyDocuments[1])!;
var after = original.DeepClone();
var works = after["spec"]!["accessControl"]!["policies"]!.AsArray().Single(item => (string?)item!["appId"] == "works")!;
var operations = works["operations"]!.AsArray();
operations.Remove(operations.Single(item => (string?)item!["name"] == withdrawn));
bool Decision(JsonNode configuration, string caller, string verb, string path, bool intersects)
{
    var policy = configuration["spec"]!["accessControl"]!["policies"]!.AsArray().SingleOrDefault(item => (string?)item!["appId"] == caller);
    return policy is not null && policy["operations"]!.AsArray().Any(item => (string?)item!["action"] == "allow"
        && item["httpVerb"]!.AsArray().Any(method => (string?)method == verb)
        && (intersects ? RouteCatalogDaprGrant.Intersects((string)item["name"]!, path) : RouteCatalogDaprGrant.Allows((string)item["name"]!, path)));
}
var json = JsonNode.Parse(observedBytes)!;
var inventory = new List<object>();
int comparisons = 0;
foreach (var endpoint in json["ReceiverSurface"]!["Endpoints"]!.AsArray())
{
    string pattern = (string)endpoint!["Pattern"]!;
    var methods = endpoint["Methods"]!.AsArray().Select(item => (string)item!).ToArray();
    if (methods.Length == 0) methods = ["GET", "POST", "PUT", "DELETE"];
    string sample = Regex.Replace(pattern, @"\{[^}]+\}", "01ARZ3NDEKTSV4RRFFQ69G5FAV");
    foreach (string caller in new[] { "works", "eventstore-admin", "unknown" })
    foreach (string method in methods)
    {
        bool oldIntersects = Decision(original, caller, method, pattern, true);
        bool newIntersects = Decision(after, caller, method, pattern, true);
        bool oldAllows = Decision(original, caller, method, sample, false);
        bool newAllows = Decision(after, caller, method, sample, false);
        if (oldIntersects != newIntersects || oldAllows != newAllows) throw new Exception("Observed endpoint admission changed: " + pattern);
        inventory.Add(new { pattern, caller, method, intersectsBefore = oldIntersects, intersectsAfter = newIntersects,
            samplePath = sample, allowedBefore = oldAllows, allowedAfter = newAllows });
        comparisons++;
    }
}
var cases = new[]
{
    ("works", "GET", "/api/v1/commands/status/01ARZ3NDEKTSV4RRFFQ69G5FAV", true, true),
    ("works", "GET", "/api/v1/commands/status/workload/tenant-a/01ARZ3NDEKTSV4RRFFQ69G5FAV", false, false),
    ("works", "POST", "/api/v1/commands/status/01ARZ3NDEKTSV4RRFFQ69G5FAV", true, true),
    ("works", "DELETE", "/api/v1/commands/status/01ARZ3NDEKTSV4RRFFQ69G5FAV", false, false),
    ("unknown", "GET", "/api/v1/commands/status/01ARZ3NDEKTSV4RRFFQ69G5FAV", false, false),
    ("works", "GET", "/api/v1/commands/status-other/01ARZ3NDEKTSV4RRFFQ69G5FAV", false, false),
    ("works", "POST", "/api/v1/trusted-effects", true, true),
    ("works", "GET", "/api/v1/commands/status/workload/tenant-a", true, false),
};
var protectedCases = cases.Select(item =>
{
    bool before = Decision(original, item.Item1, item.Item2, item.Item3, false);
    bool current = Decision(after, item.Item1, item.Item2, item.Item3, false);
    if (before != item.Item4 || current != item.Item5) throw new Exception("Protected request decision differs: " + item + " observed=" + before + "," + current);
    return new { caller = item.Item1, method = item.Item2, path = item.Item3, before, after = current };
}).ToArray();
var refusedGrants = new List<object>();
foreach (var policy in original["spec"]!["accessControl"]!["policies"]!.AsArray())
foreach (var grant in policy!["operations"]!.AsArray())
{
    var configuration = original.DeepClone();
    var selected = policy.DeepClone();
    selected!["operations"] = new JsonArray(grant!.DeepClone());
    configuration["spec"]!["accessControl"]!["policies"] = new JsonArray(selected);
    string result = Check(JsonSerializer.SerializeToUtf8Bytes(configuration));
    if (result != "accepted") refusedGrants.Add(new { caller = (string)policy["appId"]!, grant = (string)grant["name"]!, result });
}
string afterResult = Check(JsonSerializer.SerializeToUtf8Bytes(after));
operations.Remove(operations.Single(item => (string?)item!["name"] == "/api/v1/trusted-effects"));
Console.WriteLine(JsonSerializer.Serialize(new
{
    status = "focused-offline-observation-replay; not-live-or-parity-acceptance",
    observationSha256 = Convert.ToHexString(SHA256.HashData(observedBytes)).ToLowerInvariant(),
    configurationSha256 = Convert.ToHexString(SHA256.HashData(observation.TopologyDocuments[1])).ToLowerInvariant(),
    originalResult = Check(observation.TopologyDocuments[1]), afterOnlyNestedWithdrawal = afterResult,
    afterBothRefusedGrantWithdrawals = Check(JsonSerializer.SerializeToUtf8Bytes(after)),
    refusedGrants, endpoints = json["ReceiverSurface"]!["Endpoints"]!.AsArray().Count,
    comparisons, inventory, protectedCases,
    limit = "Observed fixed-depth endpoint inventory and listed request cases only. The old unmatched one-segment prefix is narrowed; no all-URI equivalence or native runtime proof is claimed."
}, new JsonSerializerOptions { WriteIndented = true }));
