import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

base=Path('/tmp/story49-public402-candidate-20261103')
record=json.loads((base/'candidate.json').read_text())
platform=Path(record['platformRoot']);works=Path(record['worksRoot']);sdk=Path(record['sdkRoot'])
sys.path.insert(0,str(platform/'eng'))
from verify_works_host import consumer_build_command,consumer_model_environment
output=base/'artifacts'
env=os.environ.copy()
for name,path in record['rootDependencies'].items():env[name.replace('Hexalith.','Hexalith')+'Root']=path
env.update({'HexalithBuildsPublishedToolRoot':'/tmp/works-published-builds.0YYy7o/verified/published/tools/net10.0/any','NUGET_PACKAGES':str(base/'packages'),'RestorePackagesPath':str(base/'packages'),'RestoreSources':'https://api.nuget.org/v3/index.json','DOTNET_USE_POLLING_FILE_WATCHER':'1'})
(base/'tmp').mkdir(exist_ok=True);env['TMPDIR']=str(base/'tmp')
results=[]
def run(name,command,cwd,environment=env):
 print(name,flush=True)
 with (base/(name+'.log')).open('w') as log:completed=subprocess.run(command,cwd=cwd,env=environment,stdout=log,stderr=subprocess.STDOUT)
 results.append({'name':name,'command':command,'cwd':str(cwd),'exitCode':completed.returncode,'log':name+'.log','logSha256':hashlib.sha256((base/(name+'.log')).read_bytes()).hexdigest()})
 (base/'results.json').write_text(json.dumps({'status':'candidate-focused-only; canonical-full-and-CI-pending','commands':results},indent=2)+'\n')
 if completed.returncode:raise SystemExit(completed.returncode)
common=['-p:HexalithEventStoreRoot='+str(sdk),'-p:HexalithEventStoreVersion=4.0.2']
command=consumer_build_command('tests/Hexalith.Platform.Works.Tests/Hexalith.Platform.Works.Tests.csproj','Release','4.0.2',platform/'artifacts/candidate-release')+common
run('platform-release-build',command,platform)
os.environ.update(env)
modelenv=consumer_model_environment(works,sdk,'Release','4.0.2',platform/'artifacts/candidate-release')
executable=platform/'artifacts/candidate-release/bin/Hexalith.Platform.Works.Tests/release/Hexalith.Platform.Works.Tests'
run('platform-release-tests',[str(executable),'-noLogo','-result-xml',str(base/'platform-release.xml')],platform,modelenv)
command=consumer_build_command('tests/Hexalith.Works.IntegrationTests/Hexalith.Works.IntegrationTests.csproj','Release','4.0.2',works/'.artifacts/candidate-release')+common+['-p:HexalithAspireHostingDaprVersion=13.6.2-beta.959','-p:PlatformWorksRuntimeRoot='+str(platform),'-p:HexalithPartiesRoot='+record['rootDependencies']['Hexalith.Parties'],'-p:HexalithPlatformRoot='+str(platform),'-p:PathMap='+str(works/'.artifacts/candidate-release')+'=/_/hexalith-works-platform-build']
run('works-release-build',command,works)
ledger=json.loads(Path('/tmp/story49-current-20261103-e50fzbzy/full/gate/ledger.json').read_text())
command=next(item['command'] for item in ledger['commands'] if item['name']=='works-consumer-supporting').copy()
command[0]=str(works/'.artifacts/candidate-release/bin/Hexalith.Works.IntegrationTests/release/Hexalith.Works.IntegrationTests')
command[-1]=str(base/'works-consumer-supporting.xml')
env.update({'Platform__Works__SourceRoot':str(works),'Platform__Works__RuntimeRoot':str(platform)})
run('works-supporting-tests',command,works)
run('generated-platform-catalog',['pwsh','-NoProfile','-File','/home/administrator/projects/hexalith/works/references/Hexalith.Builds/Tools/write-platform-version-catalog.ps1','-CatalogPath',str(Path(record['buildsRoot'])/'Props/Directory.Packages.props'),'-OutputPath',str(base/'platform-version-catalog.json'),'-Configuration','Release'],base)
print('candidate-focused-checks-passed',flush=True)
