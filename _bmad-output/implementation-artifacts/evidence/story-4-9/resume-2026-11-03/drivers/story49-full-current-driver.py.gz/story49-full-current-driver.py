import importlib.util
import json
import os
from pathlib import Path
import subprocess
import tempfile

works = Path('/home/administrator/projects/hexalith/works')
artifacts = Path(tempfile.mkdtemp(prefix='story49-current-20261103-'))
(artifacts / 'tmp').mkdir()
os.environ['TMPDIR'] = str(artifacts / 'tmp')
specification = importlib.util.spec_from_file_location('coordinator', works / 'scripts/verify-platform-parity-ci.py')
module = importlib.util.module_from_spec(specification)
specification.loader.exec_module(module)
command, environment, record, snapshot = module.bootstrap(works, artifacts / 'full')
command[command.index('--profile') + 1] = 'full'
environment['HexalithBuildsPublishedToolRoot'] = '/tmp/works-published-builds.0YYy7o/verified/published/tools/net10.0/any'
cache = artifacts / 'packages'
cache.mkdir()
environment.update({'NUGET_PACKAGES':str(cache), 'RestorePackagesPath':str(cache), 'RestoreSources':'https://api.nuget.org/v3/index.json'})
(artifacts / 'invocation.json').write_text(json.dumps({'command': command, 'worksRoot': str(works), 'artifacts': str(artifacts), 'publishedBuildsToolRoot': environment['HexalithBuildsPublishedToolRoot'], 'nugetPackages':str(cache), 'restoreSources':environment['RestoreSources']}, indent=2) + '\n')
print(str(artifacts), flush=True)
result = subprocess.run(command, env=environment)
if result.returncode == 0:
    if snapshot.origin_files(Path(record['platformOrigin'])) != record['platformSourceFiles']:
        raise ValueError('Platform source changed during full qualification')
    module.require_unchanged_coordinators(record['coordinatorSha256'])
print('fullExitCode=' + str(result.returncode), flush=True)
raise SystemExit(result.returncode)
