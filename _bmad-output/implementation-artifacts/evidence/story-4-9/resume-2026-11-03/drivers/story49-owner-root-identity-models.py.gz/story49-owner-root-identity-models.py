import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

attempt=Path('/tmp/story49-current-20261103-0hb3k7zj/full')
record=json.loads((attempt/'bootstrap.json').read_text())
ledger=json.loads((attempt/'gate/ledger.json').read_text())
output=Path(ledger['platformTestsArtifacts'])/'debug'
executable=output/'bin/Hexalith.Platform.Works.Tests/debug/Hexalith.Platform.Works.Tests'
env=os.environ.copy()
for name, path in record['rootDependencies'].items():
    env[name.replace('Hexalith.','Hexalith')+'Root']=path
env.update({'HexalithEventStoreRoot': record['sdkRoot'], 'Platform__Works__SourceRoot':record['worksRoot'],
            'TMPDIR':str(attempt.parent/'tmp'), 'ArtifactsPath':str(output), 'UseArtifactsOutput':'true',
            'Version':record['sdkVersion'], 'MinVerVersionOverride':record['sdkVersion'],
            'UseHexalithProjectReferences':'true','UseNuGetDeps':'false','Configuration':'Debug',
            'DOTNET_USE_POLLING_FILE_WATCHER':'1'})
os.environ.update(env)
os.environ.update({'HexalithEventStoreRoot':'/unrelated/sdk','HexalithEventStoreFromSource':'invalid','HexalithPolymorphicSerializationsFromSource':'invalid'})
sys.path.insert(0, '/home/administrator/projects/hexalith/works/references/Hexalith.Platform/eng')
from verify_works_host import consumer_model_environment
env=consumer_model_environment(record['worksRoot'], record['sdkRoot'], 'Debug', record['sdkVersion'], output)
loaded=executable.parent/'Hexalith.EventStore.Client.dll'
before=hashlib.sha256(loaded.read_bytes()).hexdigest()
command=[str(executable), '-noLogo','-class','*WorksPreviewModelTests',
         '-result-xml','/tmp/story49-owner-root-identity-models-20261103.xml']
result=subprocess.run(command,env=env,cwd=record['platformRoot'])
after=hashlib.sha256(loaded.read_bytes()).hexdigest()
print(json.dumps({'exitCode':result.returncode,'parentClientBefore':before,'parentClientAfter':after,'sameBytes':before==after}))
raise SystemExit(result.returncode)
