import difflib
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess

works=Path('/home/administrator/projects/hexalith/works')
base=Path('/tmp/story49-public402-candidate-20261103')
base.mkdir()
source_record=json.loads((Path(Path('/tmp/story49-verify-public402-20261103-qualified.log').read_text().splitlines()[0])/'record.json').read_text())
sdk=Path(source_record['sourceRoot'])
spec=importlib.util.spec_from_file_location('snapshot',works/'references/Hexalith.Platform/eng/works_host_snapshot.py');snap=importlib.util.module_from_spec(spec);spec.loader.exec_module(snap)
platform=base/'platform'
for name in snap.origin_files(works/'references/Hexalith.Platform'):
 target=platform/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(works/'references/Hexalith.Platform'/name,target)
consumer=base/'works'
names=subprocess.check_output(['git','-C',str(works),'ls-files','-z','--cached','--others','--exclude-standard']).decode().split('\0')
for name in names:
 if not name or name.split('/')[0] in {'references','_bmad-output','.agents','node_modules','.artifacts'}:continue
 path=works/name
 if path.is_file() and not path.is_symlink():
  target=consumer/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,target)
builds=base/'builds'
shutil.copytree(works/'references/Hexalith.Builds/Props',builds/'Props')
changes={'Works':{},'Builds':{}}
for name in ['Directory.Build.props','Directory.Packages.props','tests/Hexalith.Works.IntegrationTests/Hexalith.Works.IntegrationTests.csproj','tools/source-debug-dependencies.json','docs/development-assurance.md','docs/eventstore-api-surface-constraints.md']:
 p=consumer/name;old=p.read_bytes();new=old.replace(b'4.0.0',b'4.0.2').replace(b'653124dced81830e932edb7738a78ee61104d55a',b'f06abada8dc3aab4a5fd240847fd680d515c98a5');assert new!=old;p.write_bytes(new);changes['Works'][name]=(old,new)
p=builds/'Props/Directory.Packages.props';old=p.read_bytes();new=old.replace(b">4.0.0</HexalithEventStoreVersion>",b">4.0.2</HexalithEventStoreVersion>");assert new!=old;p.write_bytes(new);changes['Builds']['Props/Directory.Packages.props']=(old,new)
for owner,items in changes.items():
 patch=''.join(''.join(difflib.unified_diff(old.decode().splitlines(keepends=True),new.decode().splitlines(keepends=True),fromfile='a/'+name,tofile='b/'+name)) for name,(old,new) in items.items())
 (base/(owner.lower()+'-candidate-pins.patch')).write_bytes(patch.encode())
roots={p.name:p for p in (works/'references').iterdir() if p.is_dir() and (p/'.git').exists()}
roots.update({'Hexalith.Works':consumer,'Hexalith.Platform':platform,'Hexalith.Builds':builds,'Hexalith.EventStore':sdk})
for root in [consumer,platform]:
 for relative in snap.declared_links(works if root==consumer else works/'references/Hexalith.Platform'):
  name=Path(relative).name
  if name in roots:
   target=root/relative;target.parent.mkdir(parents=True,exist_ok=True);target.symlink_to(roots[name],target_is_directory=True)
# SDK source qualification is already complete; candidate catalog is a separate, explicitly unaccepted build input.
(sdk/'references/Hexalith.Builds').unlink();(sdk/'references/Hexalith.Builds').symlink_to(builds,target_is_directory=True)
record={'status':'executable-candidate-preparation; not-accepted-tuple-or-parity','worksRoot':str(consumer),'platformRoot':str(platform),'buildsRoot':str(builds),'sdkRoot':str(sdk),'publicSdk':source_record,'rootDependencies':{name:str(path) for name,path in roots.items()},'acceptedTupleUnchanged':json.loads((platform/'eng/builds-tuple.json').read_text()),'limits':['Candidate catalog has no new owner source revision, freshness audit or public Builds publication.','Accepted tuple fields and live consumer pins remain unchanged.','A direct candidate build cannot qualify the canonical full/CI gate.']}
(base/'candidate.json').write_text(json.dumps(record,indent=2)+'\n')
print(base)
