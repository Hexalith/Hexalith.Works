import json
import os
from pathlib import Path
import subprocess
import sys
root=Path('/home/administrator/projects/hexalith/works')
pinned=Path(Path('/tmp/story49-final-pinned-model-controls-20261103.log').read_text().splitlines()[0])
record=json.loads((pinned/'bootstrap/bootstrap.json').read_text());platform=Path(record['platformRoot'])
sys.path.insert(0,str(platform/'eng'))
from verify_works_host import consumer_build_command
output=root/'.artifacts/story49-final-policy-20261103'
env=os.environ.copy()
for name,path in record['rootDependencies'].items():env[name.replace('Hexalith.','Hexalith')+'Root']=path
env.update({'NUGET_PACKAGES':'/tmp/story49-current-20261103-e50fzbzy/packages','RestorePackagesPath':'/tmp/story49-current-20261103-e50fzbzy/packages','RestoreSources':'https://api.nuget.org/v3/index.json','HexalithBuildsPublishedToolRoot':'/tmp/works-published-builds.0YYy7o/verified/published/tools/net10.0/any','WORKS_PLATFORM_ROOT':str(platform)})
command=consumer_build_command('tests/Hexalith.Works.IntegrationTests/Hexalith.Works.IntegrationTests.csproj','Release','4.0.0',output)+['-p:HexalithEventStoreRoot='+record['sdkRoot'],'-p:HexalithEventStoreVersion=4.0.0','-p:HexalithAspireHostingDaprVersion=13.6.2-beta.959','-p:PlatformWorksRuntimeRoot='+str(platform),'-p:HexalithPartiesRoot='+env['HexalithPartiesRoot'],'-p:HexalithPlatformRoot='+str(platform),'-p:PathMap='+str(output)+'=/_/hexalith-works-platform-build']
print(json.dumps(command),flush=True)
subprocess.run(command,cwd=root,env=env,check=True)
executable=output/'bin/Hexalith.Works.IntegrationTests/release/Hexalith.Works.IntegrationTests'
command=[str(executable),'-noLogo','-class','*WorksSdkDaprConfigCopyTests','-class','*WorksIngressIdentityTests','-class','*WorksCapturedConfigurationFileTests','-result-xml','/tmp/story49-final-works-policy-controls-20261103.xml']
print(json.dumps(command),flush=True)
subprocess.run(command,cwd=root,env=env,check=True)
