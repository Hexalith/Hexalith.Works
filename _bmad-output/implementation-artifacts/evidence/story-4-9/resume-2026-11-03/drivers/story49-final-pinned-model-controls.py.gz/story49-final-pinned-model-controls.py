import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
works=Path('/home/administrator/projects/hexalith/works')
base=Path(tempfile.mkdtemp(prefix='story49-final-pinned-models-20261103-'))
print(base,flush=True)
spec=importlib.util.spec_from_file_location('coordinator',works/'scripts/verify-platform-parity-ci.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
_,env,record,_=module.bootstrap(works,base/'bootstrap')
platform=Path(record['platformRoot']);output=platform/'artifacts/focused-release'
sys.path.insert(0,str(platform/'eng'))
from verify_works_host import consumer_build_command,consumer_model_environment
command=consumer_build_command('tests/Hexalith.Platform.Works.Tests/Hexalith.Platform.Works.Tests.csproj','Release','4.0.0',output)+['-p:HexalithEventStoreRoot='+record['sdkRoot'],'-p:HexalithEventStoreVersion=4.0.0']
env.update({'NUGET_PACKAGES':'/tmp/story49-current-20261103-e50fzbzy/packages','RestorePackagesPath':'/tmp/story49-current-20261103-e50fzbzy/packages','RestoreSources':'https://api.nuget.org/v3/index.json','HexalithBuildsPublishedToolRoot':'/tmp/works-published-builds.0YYy7o/verified/published/tools/net10.0/any'})
(base/'invocation.json').write_text(json.dumps({'build':command,'record':record,'scope':'focused-model-policy-controls-only; full-and-CI-remain-pending'},indent=2)+'\n')
subprocess.run(command,cwd=platform,env=env,check=True)
os.environ.update(env)
env=consumer_model_environment(works,record['sdkRoot'],'Release','4.0.0',output)
subprocess.run([str(output/'bin/Hexalith.Platform.Works.Tests/release/Hexalith.Platform.Works.Tests'),'-noLogo','-result-xml',str(base/'platform-release.xml')],cwd=platform,env=env,check=True)
print('focused-pinned-model-controls-passed',flush=True)
