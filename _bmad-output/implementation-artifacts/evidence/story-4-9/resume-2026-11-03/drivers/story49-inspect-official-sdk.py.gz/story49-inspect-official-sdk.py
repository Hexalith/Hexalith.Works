import hashlib
import json
from pathlib import Path
import tempfile
import urllib.request
import zipfile
import xml.etree.ElementTree as ET

attempt=Path('/tmp/story49-current-20261103-clg615jc/full')
assets=json.loads((attempt/'gate/consumer/obj/Hexalith.Works.IntegrationTests/project.assets.json').read_text())
root=Path(tempfile.mkdtemp(prefix='story49-official-sdk-20261103-'))
record={'sdkVersion':'4.0.0','archives':{},'observedSharedCache':{},'status':'running'}
(root/'record.json').write_text(json.dumps(record,indent=2)+'\n')
print(root,flush=True)
for key, library in assets['libraries'].items():
    if not key.startswith('Hexalith.EventStore.') or library['type']!='package':
        continue
    name,version=key.split('/')
    folder=next(Path(path)/library['path'] for path in assets['packageFolders'] if (Path(path)/library['path']).exists())
    cache_archive=folder/(name.lower()+'.'+version+'.nupkg')
    metadata=json.loads((folder/'.nupkg.metadata').read_text())
    record['observedSharedCache'][name]={'metadata':metadata,'archiveSha256':hashlib.sha256(cache_archive.read_bytes()).hexdigest()}
    file=name.lower()+'.'+version+'.nupkg'
    url='https://api.nuget.org/v3-flatcontainer/'+name.lower()+'/'+version+'/'+file
    with urllib.request.urlopen(url,timeout=30) as response:
        data=response.read(64*1024*1024+1)
    if len(data)>64*1024*1024:
        raise ValueError('Official archive exceeds bound')
    path=root/file
    path.write_bytes(data)
    with zipfile.ZipFile(path) as archive:
        nuspec=next(entry for entry in archive.namelist() if entry.endswith('.nuspec'))
        node=ET.fromstring(archive.read(nuspec))
        repository=node.find('.//{*}repository')
        package_version=node.findtext('.//{*}version')
    row={'url':url,'archiveSha256':hashlib.sha256(data).hexdigest(),'repository':repository.attrib if repository is not None else None,'version':package_version}
    record['archives'][name]=row
    (root/'record.json').write_text(json.dumps(record,indent=2)+'\n')
    print(name,package_version,row['repository'],flush=True)
    if package_version!='4.0.0' or row['repository']!={'type':'git','url':'https://github.com/Hexalith/Hexalith.EventStore','commit':'653124dced81830e932edb7738a78ee61104d55a'}:
        raise ValueError('Official producer identity differs')
record['status']='official-archive-metadata-matches-selected-producer'
(root/'record.json').write_text(json.dumps(record,indent=2)+'\n')
