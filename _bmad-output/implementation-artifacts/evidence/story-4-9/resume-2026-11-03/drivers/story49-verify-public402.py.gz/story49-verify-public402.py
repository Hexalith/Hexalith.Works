import concurrent.futures
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import tarfile
import tempfile
import urllib.request
import zipfile
import xml.etree.ElementTree as ET

works=Path('/home/administrator/projects/hexalith/works')
base=Path(tempfile.mkdtemp(prefix='story49-public402-20261103-'))
print(base,flush=True)
version='4.0.2'
commit='f06abada8dc3aab4a5fd240847fd680d515c98a5'
assets=json.loads(Path('/tmp/story49-current-20261103-e50fzbzy/full/gate/consumer/obj/Hexalith.Works.IntegrationTests/project.assets.json').read_text())
names=[name.split('/')[0] for name,row in assets['libraries'].items() if name.startswith('Hexalith.EventStore.') and row['type']=='package']
def fetch(url):
    with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Hexalith-Works-Story49'}),timeout=45) as response:
        data=response.read(128*1024*1024+1)
    if len(data)>128*1024*1024:raise ValueError('Bound exceeded')
    return data
def package(name):
    file=name.lower()+'.'+version+'.nupkg';url='https://api.nuget.org/v3-flatcontainer/'+name.lower()+'/'+version+'/'+file
    data=fetch(url);path=base/file;path.write_bytes(data)
    with zipfile.ZipFile(path) as archive:
        spec=next(item for item in archive.namelist() if item.endswith('.nuspec'));node=ET.fromstring(archive.read(spec))
        repository=node.find('.//{*}repository').attrib
        assert node.findtext('.//{*}version')==version
        assert repository=={'type':'git','url':'https://github.com/Hexalith/Hexalith.EventStore','commit':commit},repository
        (base/(name+'.nuspec')).write_bytes(archive.read(spec))
    return name,{'url':url,'archiveSha256':hashlib.sha256(data).hexdigest(),'repositoryUrl':repository['url'],'repositoryCommit':commit,'version':version}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    producers=dict(pool.map(package,names))
url='https://codeload.github.com/Hexalith/Hexalith.EventStore/tar.gz/'+commit
data=fetch(url);(base/'source.tar.gz').write_bytes(data)
with tarfile.open(fileobj=io.BytesIO(data)) as archive:
    archive.extractall(base/'export',filter='data')
source=next((base/'export').iterdir())
(source/'references').mkdir(exist_ok=True)
(source/'references/Hexalith.Builds').rmdir()
(source/'references/Hexalith.Builds').symlink_to(works/'references/Hexalith.Builds',target_is_directory=True)
module_spec=importlib.util.spec_from_file_location('producer',works/'references/Hexalith.Platform/eng/verify_works_producer.py')
module=importlib.util.module_from_spec(module_spec);module_spec.loader.exec_module(module)
snapshot=module.runtime_source_snapshot(source)
qualification=module.qualify_runtime_source(snapshot,producers,tag='v4.0.2')
controller=source/'src/Hexalith.EventStore/Controllers/TrustedEffectsController.cs'
assert '[EventStoreTechnicalHttpController]' in controller.read_text()
record={'status':'official-public-packages-and-exact-source-qualified; candidate-not-accepted','version':version,'producer':commit,'archives':producers,'sourceArchive':{'url':url,'sha256':hashlib.sha256(data).hexdigest()},'sourceRoot':str(source),'sourceQualification':qualification,'trustedEffectsControllerSha256':hashlib.sha256(controller.read_bytes()).hexdigest()}
(base/'record.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'sourceRoot':str(source),'packages':len(producers),'runtimeFileCount':qualification['runtimeFileCount'],'matchesPublishedProducer':qualification['matchesPublishedProducer']}),flush=True)
