The retained Works host fails mandatory route-catalog startup with the old SDK and ACL pairing. This binds Platform to genuine Builds 4.43.3 / SDK 4.0.4, gives selected-child compilation the parent SDK's build context, and withdraws the nested scalar status grant while preserving denial of the actual two-parameter workload-status endpoint. The unmatched one-segment prefix becomes denied; the other grants and SDK identity guards remain intact.

The old 3.126.0 proof records and table are explicitly historical. Their results do not qualify the new producer.

Validation:

- Official release source/tag, signed archive, qualification carrier and embedded catalog verified against Builds source fc743715f7d0993392dee34b2ef9c4eb85cdd399.
- Platform Works model/policy tests: 155 passed with the published 4.43.3 Tooling.
- Owner helper controls: 159 passed; finite SDK gate evaluations: 208 passed; tuple controls: 19 passed; host-resolution controls: 15 passed.
- SDK 4.0.4 package preparation: nine executed consumer DLLs match official archives/source; 173 focused Works policy, HTTP, cancellation and package facts pass. That preparation used the previous Tooling and supplies no new tuple acceptance.

Exact-source hosted tuple CI and fresh Works ordinary/full/actual-CI/rollback qualification remain required before final acceptance.
