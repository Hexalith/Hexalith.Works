param(
    [Parameter(Mandatory=$true)][string] $ToolingPath,
    [Parameter(Mandatory=$true)][string] $ExpectedPath,
    [Parameter(Mandatory=$true)][string] $OutputPath
)
$ErrorActionPreference = 'Stop'
$assembly = [System.Reflection.Assembly]::LoadFile([IO.Path]::GetFullPath($ToolingPath))
$stream = $assembly.GetManifestResourceStream('Hexalith.Builds.Tooling.Manifest.platform-version-catalog.json')
if ($null -eq $stream) { throw 'Published Tooling omitted its embedded catalog.' }
$reader = [IO.StreamReader]::new($stream)
try { $observed = $reader.ReadToEnd() } finally { $reader.Dispose() }
$expected = [IO.File]::ReadAllText([IO.Path]::GetFullPath($ExpectedPath))
if ($observed -cne $expected) { throw 'Published embedded catalog differs from the owning evaluated catalog.' }
[IO.File]::WriteAllText([IO.Path]::GetFullPath($OutputPath), $observed, [Text.UTF8Encoding]::new($false))
$catalog = $observed | ConvertFrom-Json
if ($catalog.eventStoreVersion -cne '4.0.4') { throw 'Published catalog does not preserve the current SDK selection.' }
Write-Output 'Published embedded catalog exactly matches the owning evaluated catalog and selects SDK 4.0.4.'
