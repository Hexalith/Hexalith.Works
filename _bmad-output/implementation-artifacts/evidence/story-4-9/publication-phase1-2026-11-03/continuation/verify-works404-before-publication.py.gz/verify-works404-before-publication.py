import json,os,subprocess,sys
from pathlib import Path
base=Path('/tmp/story49-publication-20261103-evyasum6');platform=base/'platform';works=base/'works-pin-candidate';sdk=Path('/tmp/story49-public404-20261103-09lkkd9x/export/Hexalith.EventStore-326bfef884543cdbcaf96de7f4c4ad378dbad6d7');output=works/'.artifacts/works404-before-publication'
sys.path.insert(0,str(platform/'eng'))
from verify_works_host import consumer_build_command
from verify_works_producer import qualify_runtime_source,runtime_source_snapshot
from verify_works_host import published_producers
env=os.environ.copy()
for path in Path('/home/administrator/projects/hexalith/works/references').iterdir():
 if (path/'.git').exists():env[path.name.replace('Hexalith.','Hexalith')+'Root']=str(path)
env.update({'HexalithEventStoreRoot':str(sdk),'HexalithPlatformRoot':str(platform),'HexalithBuildsPublishedToolRoot':'/tmp/works-published-builds.0YYy7o/verified/published/tools/net10.0/any','NUGET_PACKAGES':str(base/'preparation-packages'),'RestorePackagesPath':str(base/'preparation-packages'),'RestoreSources':'https://api.nuget.org/v3/index.json','TMPDIR':str(base/'helper-tmp'),'WORKS_PLATFORM_ROOT':str(platform)})
command=consumer_build_command('tests/Hexalith.Works.IntegrationTests/Hexalith.Works.IntegrationTests.csproj','Release','4.0.4',output)+['-p:HexalithEventStoreRoot='+str(sdk),'-p:HexalithEventStoreVersion=4.0.4','-p:HexalithAspireHostingDaprVersion=13.6.2-beta.959','-p:PlatformWorksRuntimeRoot='+str(platform),'-p:HexalithPartiesRoot='+env['HexalithPartiesRoot'],'-p:HexalithPlatformRoot='+str(platform),'-p:PathMap='+str(output)+'=/_/hexalith-works-platform-build']
(base/'works404-before-publication-invocation.json').write_text(json.dumps({'status':'focused-preparation-only; live-pins-unmodified','limitation':'Existing verified4.43.2 Tooling; not qualification of the pending new owner tuple.','build':command},indent=2)+'\n')
subprocess.run(command,cwd=works,env=env,check=True)
executable=output/'bin/Hexalith.Works.IntegrationTests/release/Hexalith.Works.IntegrationTests'
command=[str(executable),'-noLogo','-class','*WorksSdkDaprConfigCopyTests','-class','*WorksIngressIdentityTests','-class','*WorksCapturedConfigurationFileTests','-class','*WorksSdkProtectedHttpTests','-class','*WorksSdkEndpointCancellationTests','-class','*WorksSdkPackageContractTests','-result-xml',str(base/'works404-before-publication.xml')]
subprocess.run(command,cwd=works,env=env,check=True)
producers=published_producers(output/'obj/Hexalith.Works.IntegrationTests/project.assets.json',executable.parent,'4.0.4')
qualification=qualify_runtime_source(runtime_source_snapshot(sdk),producers,tag='v4.0.4')
(base/'works404-executed-producers-before-publication.json').write_text(json.dumps({'scope':'focused-preparation-consumer-bytes-only; not-new-tool-tuple-acceptance','producers':producers,'sourceQualification':qualification},indent=2)+'\n')
