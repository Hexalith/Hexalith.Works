import hashlib,json,subprocess,sys,urllib.request,zipfile
from pathlib import Path
import xml.etree.ElementTree as ET

base=Path('/tmp/story49-publication-20261103-evyasum6');builds=Path('/home/administrator/projects/hexalith/works/references/Hexalith.Builds');source='fc743715f7d0993392dee34b2ef9c4eb85cdd399';run_id=41606852507
output=base/'published-builds-observation';output.mkdir()
def gh(*args):return subprocess.check_output(['gh',*args])
run=json.loads(gh('api',f'repos/Hexalith/Hexalith.Builds/actions/runs/{run_id}'))
(output/'release-run.json').write_text(json.dumps(run,indent=2)+'\n')
assert run['head_sha']==source and run['status']=='completed' and run['conclusion']=='success'
release=json.loads(gh('api','repos/Hexalith/Hexalith.Builds/releases/latest'));(output/'release.json').write_text(json.dumps(release,indent=2)+'\n')
assert not release['draft'] and not release['prerelease'];tag=release['tag_name'];assert tag.startswith('v4.')
ref=json.loads(gh('api','repos/Hexalith/Hexalith.Builds/git/ref/tags/'+tag));(output/'tag.json').write_text(json.dumps(ref,indent=2)+'\n');target=ref['object']
if target['type']=='tag':target=json.loads(gh('api','repos/Hexalith/Hexalith.Builds/git/tags/'+target['sha']))['object']
assert target['type']=='commit' and target['sha']==source
version=tag[1:]
subprocess.run(['gh','release','download',tag,'--repo','Hexalith/Hexalith.Builds','--pattern','g4-tool-package-inventory.json','--pattern','g4-tool-qualification-evidence.zip','--dir',str(output)],check=True)
for name in ['g4-tool-package-inventory.json','g4-tool-qualification-evidence.zip']:
 matches=[asset for asset in release['assets'] if asset['name']==name];assert len(matches)==1
 payload=(output/name).read_bytes();assert len(payload)==matches[0]['size']
 if matches[0].get('digest'):assert matches[0]['digest'].lower()=='sha256:'+hashlib.sha256(payload).hexdigest()
inventory_path=output/'g4-tool-package-inventory.json';inventory_bytes=inventory_path.read_bytes();inventory=json.loads(inventory_bytes)
assert inventory['version']==version and inventory['configuration']=='Release' and inventory['qualification']['releaseEligible'] is True
assert inventory['qualification']['sourceTree']['clean'] is True and inventory['qualification']['sourceTree']['revision']==source
with zipfile.ZipFile(output/'g4-tool-qualification-evidence.zip') as carrier:
 assert carrier.read('g4-tool-package-inventory.json')==inventory_bytes
 identity=json.loads(carrier.read('producer-run.json'));assert identity['kind']=='release' and identity['sourceRevision']==source and identity['version']==version and identity['GITHUB_RUN_ID']==str(run_id)
 assert identity['GITHUB_REPOSITORY']=='Hexalith/Hexalith.Builds' and identity['GITHUB_JOB']=='release' and identity['GITHUB_WORKFLOW_SHA']==source and identity['GITHUB_EVENT_NAME']=='workflow_dispatch'
 declared={'g4-tool-package-inventory.json','producer-run.json'}
 for row in inventory['qualificationEvidence']:
  data=carrier.read(row['file']);assert len(data)==row['sizeBytes'] and hashlib.sha256(data).hexdigest().lower()==row['sha256'].lower();declared.add(row['file'])
 assert len(carrier.namelist())==len(declared) and set(carrier.namelist())==declared
 (output/'producer-run.json').write_text(json.dumps(identity,indent=2)+'\n')
name='hexalith.builds.module.cli.'+version+'.nupkg';url='https://api.nuget.org/v3-flatcontainer/hexalith.builds.module.cli/'+version+'/'+name
with urllib.request.urlopen(url,timeout=90) as response:data=response.read(512*1024*1024+1)
assert len(data)<512*1024*1024
archive=output/name;archive.write_bytes(data)
verify=subprocess.run(['dotnet','nuget','verify','--all',str(archive)],text=True,capture_output=True);(output/'signature.stdout').write_text(verify.stdout);(output/'signature.stderr').write_text(verify.stderr);assert verify.returncode==0
with zipfile.ZipFile(archive) as package:
 spec=ET.fromstring(package.read(next(n for n in package.namelist() if n.endswith('.nuspec'))));repository=spec.find('.//{*}repository');assert repository is not None and repository.get('commit')==source
 assert repository.get('url','').rstrip('/').removesuffix('.git')=='https://github.com/Hexalith/Hexalith.Builds'
 assert spec.findtext('.//{*}id')=='Hexalith.Builds.Module.Cli' and spec.findtext('.//{*}version')==version
 tooling=package.read('tools/net10.0/any/Hexalith.Builds.Tooling.dll');(output/'Hexalith.Builds.Tooling.dll').write_bytes(tooling)
 (output/'archive-inventory.json').write_text(json.dumps({name:hashlib.sha256(package.read(name)).hexdigest() for name in package.namelist() if not name.endswith('/')},indent=2)+'\n')
blob=subprocess.check_output(['git','rev-parse',source+':Props/Directory.Packages.props'],cwd=builds).decode().strip();catalog=subprocess.check_output(['git','show',source+':Props/Directory.Packages.props'],cwd=builds)
binding={'schemaVersion':1,'candidateAcceptance':False,'producer':{'repository':'https://github.com/Hexalith/Hexalith.Builds.git','sourceRevision':source,'catalog':{'path':'Props/Directory.Packages.props','blob':blob,'sha256':hashlib.sha256(catalog).hexdigest()}},'publication':{'version':version,'sourceRevision':source,'releaseTag':tag,'catalogSha256':hashlib.sha256(catalog).hexdigest(),'archiveSha256':hashlib.sha256(data).hexdigest(),'toolingSha256':hashlib.sha256(tooling).hexdigest(),'inventorySha256':hashlib.sha256(inventory_bytes).hexdigest(),'inventoryUrl':'https://github.com/Hexalith/Hexalith.Builds/releases/download/'+tag+'/g4-tool-package-inventory.json'}}
(output/'observed-binding.json').write_text(json.dumps(binding,indent=2)+'\n')
print(json.dumps(binding,indent=2))
