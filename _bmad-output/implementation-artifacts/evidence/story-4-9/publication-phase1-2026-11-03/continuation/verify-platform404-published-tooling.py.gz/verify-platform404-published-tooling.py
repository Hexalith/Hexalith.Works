import json,os,subprocess,sys
from pathlib import Path
base=Path('/tmp/story49-publication-20261103-evyasum6');platform=base/'platform';works=base/'works-pin-candidate';sdk=Path('/tmp/story49-public404-20261103-09lkkd9x/export/Hexalith.EventStore-326bfef884543cdbcaf96de7f4c4ad378dbad6d7');output=platform/'artifacts/works404-published-tooling'
sys.path.insert(0,str(platform/'eng'))
from verify_works_host import consumer_build_command,consumer_model_environment
env=os.environ.copy()
for path in Path('/home/administrator/projects/hexalith/works/references').iterdir():
 if (path/'.git').exists():env[path.name.replace('Hexalith.','Hexalith')+'Root']=str(path)
env.update({'HexalithEventStoreRoot':str(sdk),'HexalithPlatformRoot':str(platform),'HexalithBuildsPublishedToolRoot':'/tmp/story49-publication-20261103-evyasum6/verified-builds/published/tools/net10.0/any','NUGET_PACKAGES':str(base/'preparation-packages'),'RestorePackagesPath':str(base/'preparation-packages'),'RestoreSources':'https://api.nuget.org/v3/index.json','TMPDIR':str(base/'helper-tmp')})
command=consumer_build_command('tests/Hexalith.Platform.Works.Tests/Hexalith.Platform.Works.Tests.csproj','Release','4.0.4',output)+['-p:HexalithEventStoreRoot='+str(sdk),'-p:HexalithEventStoreVersion=4.0.4']
(base/'platform404-published-tooling-invocation.json').write_text(json.dumps({'status':'published-artifact-model-verification; hosted-tuple-preflight-pending','limitation':'Uses the freshly signature/source/version-verified published4.43.3 Tooling. Hosted exact-source tuple CI remains required.','build':command},indent=2)+'\n')
subprocess.run(command,cwd=platform,env=env,check=True)
os.environ.update(env);modelenv=consumer_model_environment(works,sdk,'Release','4.0.4',output)
subprocess.run([str(output/'bin/Hexalith.Platform.Works.Tests/release/Hexalith.Platform.Works.Tests'),'-noLogo','-result-xml',str(base/'platform404-published-tooling.xml')],cwd=platform,env=modelenv,check=True)
