import datetime,difflib,gzip,hashlib,json,shutil,subprocess
from pathlib import Path
base=Path('/tmp/story49-publication-20261103-evyasum6');works=Path('/home/administrator/projects/hexalith/works');packet=works/'_bmad-output/implementation-artifacts/evidence/story-4-9/publication-phase1-2026-11-03';packet.mkdir()
state=json.loads((base/'state.json').read_text());state['status']='Builds-published; Platform-PR-green-review-pending';state['builds'].update({'version':'4.43.3','releasePhase':'completed-successfully','publishedAtUtc':'2026-11-03T10:19:01Z'});state['platform'].update({'pr':15,'prUrl':'https://github.com/Hexalith/Hexalith.Platform/pull/15','head':'2db699c53219721ed2b9bf2860082662b73fa00d','main':'f90e68a0c0305d18dc2cde8d4d4c856aa5a49725','tupleCiRun':41620736259,'catalogCiRun':41620469841,'reviewDecision':'REVIEW_REQUIRED','publication':'pending normal eligibility or explicit user owner-exemption decision; no merge/tag yet'});(base/'state.json').write_text(json.dumps(state,indent=2)+'\n')
records=[]
def keep(source,relative):
 source=Path(source);data=source.read_bytes();target=packet/(relative+'.gz');target.parent.mkdir(parents=True,exist_ok=True);stored=gzip.compress(data,mtime=0);target.write_bytes(stored);records.append({'path':str(target.relative_to(packet)),'sha256':hashlib.sha256(stored).hexdigest(),'nativePath':str(source),'nativeSha256':hashlib.sha256(data).hexdigest(),'nativeBytes':len(data)})
for path in sorted(base.iterdir()):
 if path.is_file() and path.suffix in {'.json','.log','.txt','.md','.ps1','.py','.diff','.patch','.xml'}:
  keep(path,'continuation/'+path.name)
public=Path('/tmp/story49-public404-20261103-09lkkd9x');keep(public/'record.json','sdk404/official-package-source-record.json')
for path in sorted((base/'published-builds-observation').iterdir()):
 if path.is_file() and path.suffix in {'.json','.log','.stdout','.stderr','.zip'}:keep(path,'published-builds/'+path.name)
for root_name in ['platform-original-candidate-tuple-artifact','platform-pr-head-tuple-artifact']:
 root=base/root_name
 for path in sorted(root.rglob('*')):
  if path.is_file() and path.suffix in {'.json','.xml','.stdout','.stderr','.log'}:
   relative=path.relative_to(root)
   if 'published' in relative.parts or 'assets' in relative.parts:continue
   keep(path,root_name+'/'+relative.as_posix())
root=base/'platform-pr-catalog-artifacts'
for path in sorted(root.rglob('*')):
 if path.is_file() and (path.name in {'result.json','catalog-sdk-gates.json'} or path.name.endswith('-receipt.json')):keep(path,'platform-pr-catalog/'+path.relative_to(root).as_posix())
preflight=base/'works-pair-preflight/.artifacts/sdk404-pair-identity'
for path in sorted(preflight.iterdir()):
 if path.is_file() and path.suffix in {'.json','.log'}:keep(path,'candidate-pair-preflight-refusal/'+path.name)
# Readable deltas contain no acceptance or fabricated publication fields.
handoff=packet/'handoff';handoff.mkdir();shutil.copy2(base/'works-sdk404-pins-pending-platform-publication.patch',handoff/'works-sdk404-pins-unapplied.patch')
(handoff/'platform-pr-source.diff').write_bytes(subprocess.check_output(['git','diff','f90e68a0c0305d18dc2cde8d4d4c856aa5a49725','2db699c53219721ed2b9bf2860082662b73fa00d'],cwd=base/'platform'))
manifest={'status':'phase1-complete; external merge-eligibility decision pending','createdAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'genuine Builds publication and fully green Platform PR; no final Platform publication or Works qualification','files':records};(packet/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(packet,len(records))
