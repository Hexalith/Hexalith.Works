import datetime
import json
import socket
import subprocess
import time
from pathlib import Path

root = Path('/mnt/wsl/story49-qualification-20261021T072935Z')
command = root / 'review-pass1-ci3-command.json'
started = json.loads(command.read_text())['startedAt']
seen = set()
with (root / 'review-pass1-ci3-redis-observations.jsonl').open('x') as output:
    while 'finishedAt' not in json.loads(command.read_text()):
        names = subprocess.run(['docker', 'ps', '--filter', 'label=hexalith.works.sdk-fixture', '--format', '{{.Names}}'],
                               text=True, capture_output=True, timeout=15).stdout.splitlines()
        for name in names:
            try:
                result = subprocess.run(['docker', 'inspect', name], text=True, capture_output=True, timeout=15)
                if result.returncode:
                    continue
                container = json.loads(result.stdout)[0]
                if container['Config']['Labels'].get('hexalith.works.sdk-fixture') != name or container['State']['StartedAt'] < started:
                    continue
                for binding in container['NetworkSettings']['Ports'].get('6379/tcp', []) or []:
                    record = {'time': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'name': name,
                              'containerStartedAt': container['State']['StartedAt'], 'binding': binding}
                    try:
                        with socket.create_connection((binding['HostIp'], int(binding['HostPort'])), timeout=0.75) as client:
                            client.sendall(b'*1\r\n$4\r\nPING\r\n')
                            record['hostPing'] = client.recv(100).decode('ascii', errors='replace')
                    except OSError as error:
                        record['hostError'] = repr(error)
                        inside = subprocess.run(['docker', 'exec', name, 'redis-cli', 'PING'],
                                                text=True, capture_output=True, timeout=5)
                        record['insideExit'] = inside.returncode
                        record['insidePing'] = inside.stdout
                        record['insideError'] = inside.stderr
                    identity = (name, json.dumps(binding, sort_keys=True), record.get('hostPing'), record.get('hostError'))
                    if identity not in seen:
                        output.write(json.dumps(record) + '\n')
                        output.flush()
                        seen.add(identity)
            except (OSError, ValueError, subprocess.TimeoutExpired) as error:
                output.write(json.dumps({'time': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'name': name, 'observerError': repr(error)}) + '\n')
                output.flush()
        time.sleep(3)
print('Redis observation complete:', len(seen), 'distinct observed states')
