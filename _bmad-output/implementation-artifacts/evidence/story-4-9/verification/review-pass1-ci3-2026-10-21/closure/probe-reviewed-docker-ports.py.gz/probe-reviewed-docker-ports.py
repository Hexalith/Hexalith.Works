import datetime
import json
import random
import socket
import subprocess
import time
import uuid
from pathlib import Path

root = Path('/mnt/wsl/story49-qualification-20261021T072935Z')
records = []
def docker(*args):
    return subprocess.run(['docker', *args], text=True, capture_output=True, timeout=20)
for mode in ['automatic'] * 20 + ['explicit'] * 10:
    name = 'works-story49-port-probe-' + uuid.uuid4().hex
    port = ''
    if mode == 'explicit':
        for attempt in range(100):
            port = str(random.randrange(20000, 45000))
            try:
                with socket.socket() as listener:
                    listener.bind(('127.0.0.1', int(port)))
                break
            except OSError:
                continue
        else:
            raise RuntimeError('No available explicit probe port')
    record = {'time': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'name': name, 'mode': mode}
    try:
        result = docker('run', '--rm', '-d', '--name', name, '--label', 'hexalith.works.story49-port-probe=' + name,
                        '-p', '127.0.0.1:' + port + ':6379', 'redis:7.4-alpine')
        record['runExit'] = result.returncode
        if result.returncode:
            record['runError'] = result.stderr
            continue
        binding = docker('port', name, '6379/tcp').stdout.strip()
        record['binding'] = binding
        record['insidePing'] = docker('exec', name, 'redis-cli', 'PING').stdout
        record['hostObservations'] = []
        for attempt in range(11):
            sample = {'elapsedAttempt': attempt}
            try:
                host, selected = binding.rsplit(':', 1)
                with socket.create_connection((host, int(selected)), timeout=0.75) as client:
                    client.sendall(b'*1\r\n$4\r\nPING\r\n')
                    sample['reply'] = client.recv(100).decode('ascii', errors='replace')
            except OSError as error:
                sample['error'] = repr(error)
            record['hostObservations'].append(sample)
            if sample.get('reply') == '+PONG\r\n':
                break
            if attempt < 10:
                time.sleep(1)
    finally:
        owner = docker('inspect', '--format', '{{index .Config.Labels "hexalith.works.story49-port-probe"}}', name)
        if owner.returncode == 0 and owner.stdout.strip() == name:
            record['cleanupExit'] = docker('rm', '-f', name).returncode
        records.append(record)
        (root / 'review-pass1-docker-port-probes.json').write_text(json.dumps(records, indent=2) + '\n')
        print(json.dumps({'mode': mode, 'binding': record.get('binding'), 'runExit': record['runExit'],
                          'hostPassed': record.get('hostObservations', [{}])[-1].get('reply') == '+PONG\r\n'}), flush=True)
