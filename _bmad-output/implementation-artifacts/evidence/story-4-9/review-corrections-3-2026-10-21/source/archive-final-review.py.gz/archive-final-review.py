"""Append final review and exact-input full qualification to the retained packet."""

import gzip
import hashlib
import json
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path('/home/administrator/projects/hexalith/works')
LOCAL = ROOT / '.artifacts/story49-review3'
ATTEMPT = Path('/tmp/story49-final-review-qualification-20261021/full-retry')
GATE = ATTEMPT / 'gate'
PACKET = ROOT / '_bmad-output/implementation-artifacts/evidence/story-4-9/review-corrections-3-2026-10-21'


def read(path):
    return json.loads(path.read_text())


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    invocation = read(LOCAL / 'final-review-full-retry-invocation.json')
    assert invocation['exitCode'] == 0
    assert invocation['restoredOriginalMaxUserWatches'] is True
    ledger = read(GATE / 'ledger.json')
    assert ledger['status'] == 'passed-disposable-synthetic-parity-and-rollback'
    assert ledger['profile']['consumerConfigurations'] == ['Debug', 'Release']
    assert ledger['rollback']['complete'] is True
    assert set(ledger['rows']) == {'R' + str(i) for i in range(1, 12)}
    for row in ledger['rows'].values():
        assert row['status'] == 'passed'
        assert set(row['requiredProofs']) == {'persisted', 'negative', 'restart', 'rollback'}
        assert all(p['passed'] is True and p['evidence'] for p in row['requiredProofs'].values())
    for name, check in ledger['checks'].items():
        if isinstance(check, dict):
            assert check['total'] > 0 and check['total'] == check['passed'] and check['skipped'] == 0, name
    assert ledger['platformSourceSnapshot'] == ledger['platformSourceSnapshotFinal']
    assert ledger['runtimeProducerQualification']['matchesPublishedProducer'] is True
    executed = {}
    for path in GATE.glob('*.xml'):
        tests = ET.parse(path).getroot().findall('.//test')
        assert tests and all(t.get('result') == 'Pass' for t in tests), path
        executed[path.name] = sorted(t.get('name') for t in tests)
    for filename, name in [('platform-debug.xml', 'Debug'), ('platform-release.xml', 'Release'),
                           ('supporting-consumer.xml', 'supportingConsumer')]:
        # The owning ledger is authoritative for the result filename; XML below is checked by digest.
        check = ledger['checks'][name]
        assert any(digest(p.read_bytes()) == check['sha256'] for p in GATE.glob('*.xml')), filename
    for path, expected in ledger['canonicalSources']['Works']['sourceFiles'].items():
        assert digest((ROOT / path).read_bytes()) == expected, path
    ordinary = read(LOCAL / 'new-hosted-ordinary-results.json')
    explicit = ordinary['ordinaryExplicitExclusionsMatchPassedLocalFullGate']
    matched = {name: next((f for f, names in executed.items() if name in names), None) for name in explicit}
    assert len(matched) == 7 and all(matched.values())
    triage = read(LOCAL / 'final-review-triage.json')
    triage['patchVerification']['fullQualification'] = 'passed'
    (LOCAL / 'final-review-triage.json').write_text(json.dumps(triage, indent=2) + '\n')
    audit = {'status': ledger['status'], 'rows': 11, 'proofs': 44, 'rollbackComplete': True,
             'profile': ledger['profile'], 'checks': ledger['checks'],
             'ledgerSha256': digest((GATE / 'ledger.json').read_bytes()),
             'sourceFileCount': len(ledger['canonicalSources']['Works']['sourceFiles']),
             'recordedWorksCommit': ledger['canonicalSources']['Works']['commit'],
             'recordedSourceOverlays': read(LOCAL / 'final-review-input-delta.json'),
             'allSevenExplicitFactsExecutedAndPassed': matched,
             'executedMethods': executed, 'finalSourceFilesMatch': True,
             'platformClosurePassed': True, 'producerQualified': True,
             'machineLimitsChanged': True, 'temporaryQuotaRestored': True,
             'quotaLifecycle': invocation['quotaLifecycle'], 'frozenIntentSha256': triage['frozenSha256'],
             'reviewComplete': True, 'newDeferredEntries': 6, 'carriedWithoutRepeatedDeferral': 3}
    (LOCAL / 'final-review-parent-audit.json').write_text(json.dumps(audit, indent=2) + '\n')
    manifest = read(PACKET / 'manifest.json')

    def include(source, relative):
        raw = source.read_bytes()
        compressed = gzip.compress(raw, mtime=0)
        target = PACKET / relative
        if target.exists():
            assert target.read_bytes() == compressed, relative
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(compressed)
        manifest[relative] = {'source': str(source), 'sha256': digest(compressed),
                              'uncompressedSha256': digest(raw), 'uncompressedBytes': len(raw)}

    names = ['final-review-triage.json', 'final-review-input-delta.json', 'final-review-corrections.diff',
             'final-review-full-invocation.json', 'final-review-full.log',
             'final-review-full-retry-invocation.json', 'final-review-full-retry.log',
             'final-review-ordinary-commands.json',
             'final-review-restore.log', 'final-review-build.log', 'final-review-architecture.log',
             'final-review-architecture.xml', 'final-review-architecture-retry-command.json',
             'final-review-architecture-retry.log', 'final-review-architecture-retry.xml',
             'final-review-parent-audit.json']
    for name in names:
        include(LOCAL / name, 'final-review/' + name + '.gz')
    for name in ['story49-review4-architecture-build.log', 'story49-review4-build-configuration.xml',
                 'story49-review4-build-configuration.log']:
        include(Path('/tmp') / name, 'final-review/implementer/' + name + '.gz')
    for path in sorted(GATE.rglob('*')):
        if not path.is_file() or path.suffix not in {'.json', '.jsonl', '.xml', '.log'}:
            continue
        relative = path.relative_to(GATE)
        if {'bin', 'obj', 'workspace', '.artifacts'}.intersection(relative.parts):
            continue
        include(path, 'final-review/full/gate/' + relative.as_posix() + '.gz')
    failed_gate = Path('/tmp/story49-final-review-qualification-20261021/full/gate')
    for path in sorted(failed_gate.rglob('*')):
        if not path.is_file() or path.suffix not in {'.json', '.jsonl', '.xml', '.log'}:
            continue
        relative = path.relative_to(failed_gate)
        if {'bin', 'obj', 'workspace', '.artifacts'}.intersection(relative.parts):
            continue
        include(path, 'final-review/full-watch-failure/gate/' + relative.as_posix() + '.gz')
    include(LOCAL / 'archive-final-review.py', 'source/archive-final-review.py.gz')
    summary = read(PACKET / 'qualification-summary.json')
    summary['finalIndependentReview'] = triage
    summary['finalReviewFullQualification'] = audit
    summary['finalReviewMachineLimitsChanged'] = True
    summary['finalReviewTemporaryQuotaRestored'] = True
    summary['subsequentBuildCorrection']['status'] = 'full qualification, hosted CI and independent review passed'
    summary['subsequentBuildCorrection']['required'] = []
    summary['hostedOrdinaryAfterBuildCorrection']['hostedParityExplicitAudit'] = 'all seven exclusions verified against executed passing hosted facts'
    # Preserve original downloaded run metadata in its immutable archive.
    summary['hostedVerification']['remaining'] = []
    summary['finalSourceDifferenceFromHostedF8ad136'] = read(LOCAL / 'final-review-input-delta.json')
    summary['finalSourceDifferenceExplanation'] = 'Only XML documentation in an architecture test; the final full qualification binds the changed bytes. Runtime, consumer and live fixture code are unchanged.'
    (PACKET / 'qualification-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    (PACKET / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    for relative, entry in manifest.items():
        raw = (PACKET / relative).read_bytes()
        assert digest(raw) == entry['sha256'], relative
        assert digest(gzip.decompress(raw)) == entry['uncompressedSha256'], relative
    print(json.dumps({'verifiedArchives': len(manifest), 'rows': 11, 'proofs': 44,
                      'completeRollback': True, 'reviewComplete': True}))


if __name__ == '__main__':
    main()
