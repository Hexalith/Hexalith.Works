using System.Reflection;
using System.Runtime.Loader;
using System.Text.Json;
using Microsoft.Build.Evaluation;
using Microsoft.Build.Graph;

AssemblyLoadContext.Default.Resolving += (context, name) => {
    var candidate = Path.Combine("/home/administrator/.dotnet/sdk/10.0.402", name.Name + ".dll");
    return File.Exists(candidate) ? context.LoadFromAssemblyPath(candidate) : null;
};
using var collection = new ProjectCollection();
var globals = new Dictionary<string, string> { ["Configuration"] = args.Length > 2 ? args[2] : "Release", ["MinVerVersionOverride"] = "1.0.0" };
if (args.Length > 3) globals["HexalithEventStoreVersion"] = args[3];
var graph = new ProjectGraph(new[] { args[0] }, globals, collection);
var nodes = graph.ProjectNodes.Select(node => new {
    project = node.ProjectInstance.FullPath,
    configuration = node.ProjectInstance.GetPropertyValue("Configuration"),
    sdkVersionGlobal = node.ProjectInstance.GlobalProperties.TryGetValue("HexalithEventStoreVersion", out var version) ? version : null,
    sdkVersion = node.ProjectInstance.GetPropertyValue("HexalithEventStoreVersion"),
    sourceMode = node.ProjectInstance.GetPropertyValue("UseHexalithProjectReferences"),
    globalKeys = node.ProjectInstance.GlobalProperties.Keys.Order().ToArray(),
    references = node.ProjectReferences.Select(reference => reference.ProjectInstance.FullPath).Order().ToArray()
}).OrderBy(node => node.project).ThenBy(node => node.sdkVersionGlobal).ToArray();
File.WriteAllText(args[1], JsonSerializer.Serialize(nodes, new JsonSerializerOptions { WriteIndented = true }) + "\n");
Console.WriteLine(JsonSerializer.Serialize(new { nodes = nodes.Length, duplicatedProjects = nodes.GroupBy(node => node.project).Where(group => group.Count() > 1).Select(group => new { project = group.Key, instances = group.Count() }).ToArray() }));
