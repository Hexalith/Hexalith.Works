"""Append completed hosted verification without rewriting earlier archived evidence."""

import gzip
import hashlib
import json
import runpy
from pathlib import Path

ROOT = Path('/home/administrator/projects/hexalith/works')
LOCAL = ROOT / '.artifacts/story49-review3'
PACKET = ROOT / '_bmad-output/implementation-artifacts/evidence/story-4-9/review-corrections-3-2026-10-21'
HOSTED = LOCAL / 'hosted-parity-f8ad136'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    verification = json.loads((LOCAL / 'new-hosted-verification.json').read_text())
    assert verification['canonicalCiAcceptancePassed'] is True
    assert verification['overallWorkflow'] == 'success'
    ordinary = json.loads((LOCAL / 'new-hosted-ordinary-results.json').read_text())
    assert ordinary['jobConclusion'] == 'success'
    assert verification['commit'] == ordinary['commit'] == 'f8ad13632610348702c5157e8df3170e000c85cc'
    module = runpy.run_path(str(LOCAL / 'assemble-packet.py'))
    module['PROFILE_ROOTS']['ci'] = HOSTED
    current_ci = module['qualification']('ci')
    manifest_path = PACKET / 'manifest.json'
    inventory = json.loads(manifest_path.read_text())

    def include(source, relative):
        raw = source.read_bytes()
        compressed = gzip.compress(raw, mtime=0)
        target = PACKET / relative
        if target.exists():
            assert target.read_bytes() == compressed, relative
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(compressed)
        inventory[relative] = {'source': str(source), 'sha256': digest(compressed),
                               'uncompressedSha256': digest(raw), 'uncompressedBytes': len(raw)}

    include(LOCAL / 'new-hosted-ordinary.log', 'hosted-f8ad136/ordinary/build-and-test.log.gz')
    include(LOCAL / 'new-hosted-parity.log', 'hosted-f8ad136/parity/job.log.gz')
    include(LOCAL / 'hosted-ordinary-f8ad136.zip', 'hosted-f8ad136/ordinary/original-artifact.zip.gz')
    include(LOCAL / 'hosted-parity-f8ad136.zip', 'hosted-f8ad136/parity/original-artifact.zip.gz')
    for path in sorted((LOCAL / 'hosted-ordinary-f8ad136').rglob('*.trx')):
        include(path, 'hosted-f8ad136/ordinary/' + path.relative_to(LOCAL / 'hosted-ordinary-f8ad136').as_posix() + '.gz')
    for name in ('new-hosted-verification.json', 'new-hosted-ordinary-results.json', 'new-hosted-artifact-metadata.json',
                 'new-local-full-hosted-ci-input-equivalence.json', 'new-hosted-frozen-matrix-audit.json'):
        include(LOCAL / name, 'hosted-f8ad136/' + name + '.gz')
    for path in sorted(HOSTED.rglob('*')):
        if not path.is_file() or path.suffix not in {'.json', '.jsonl', '.xml', '.log'}:
            continue
        relative = path.relative_to(HOSTED)
        assert not {'workspace', 'bin', 'obj'}.intersection(relative.parts)
        include(path, 'hosted-f8ad136/parity/' + relative.as_posix() + '.gz')
    include(LOCAL / 'append-hosted-evidence.py', 'source/append-hosted-evidence.py.gz')
    include(LOCAL / 'verify-new-hosted.py', 'source/verify-new-hosted.py.gz')

    summary_path = PACKET / 'qualification-summary.json'
    summary = json.loads(summary_path.read_text())
    summary['profiles']['build-graph-ci'] = current_ci
    summary['hostedVerificationBeforeBuildCorrection'] = summary['hostedVerification']
    summary['hostedVerification'] = verification
    summary['hostedOrdinaryAfterBuildCorrection'] = ordinary
    summary['subsequentBuildCorrection']['status'] = 'fresh full and hosted CI qualification passed; final review pending'
    summary['subsequentBuildCorrection']['required'] = ['independent final review']
    summary_path.write_text(json.dumps(summary, indent=2) + '\n')
    manifest_path.write_text(json.dumps(inventory, indent=2) + '\n')
    for relative, entry in inventory.items():
        raw = (PACKET / relative).read_bytes()
        assert digest(raw) == entry['sha256'], relative
        assert digest(gzip.decompress(raw)) == entry['uncompressedSha256'], relative
    print(json.dumps({'verifiedArchives': len(inventory), 'currentHostedCiPassed': True}))


if __name__ == '__main__':
    main()
