"""Verify the downloaded canonical CI packet against fresh local full inputs."""

import hashlib
import importlib.util
import json
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path('/home/administrator/projects/hexalith/works')
LOCAL = ROOT / '.artifacts/story49-review3'
HOSTED = LOCAL / 'hosted-parity-f8ad136'
COMMIT = 'f8ad13632610348702c5157e8df3170e000c85cc'
SUCCESS = 'passed-disposable-synthetic-parity-and-rollback'


def read(path):
    return json.loads(path.read_text())


def normalized_linked(files):
    result = {}
    for path, digest in files.items():
        prefix, marker, suffix = path.replace('\\', '/').partition('/src/')
        assert marker and suffix not in result, path
        result[suffix] = digest
    return result


def main():
    specification = importlib.util.spec_from_file_location('works_parity_coordinator', ROOT / 'scripts/verify-platform-parity-ci.py')
    coordinator = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(coordinator)
    ledger = coordinator.require_complete_gate(HOSTED)
    assert read(HOSTED / 'bootstrap.json')['status'] == SUCCESS
    assert ledger['worksConsumerSource']['commit'] == COMMIT
    assert ledger['platformSourceSnapshot'] == ledger['platformSourceSnapshotFinal']
    metadata = read(LOCAL / 'new-hosted-artifact-metadata.json')
    assert metadata['headSha'] == COMMIT and metadata['workflowConclusion'] == 'success'
    artifact_digest = hashlib.sha256((LOCAL / 'hosted-parity-f8ad136.zip').read_bytes()).hexdigest()
    assert artifact_digest == metadata['artifactSha256']
    local = read(Path('/tmp/story49-buildgraph-qualification-20261021/full/gate/ledger.json'))
    equivalence = {}
    for name in ('Works', 'Platform'):
        before = local['canonicalSources'][name]
        after = ledger['canonicalSources'][name]
        assert before['sourceFiles'] == after['sourceFiles'], name
        equivalence[name] = {'sameSourceFiles': True, 'sourceFileCount': len(after['sourceFiles']),
                             'localCommit': before['commit'], 'hostedCommit': after['commit'],
                             'sameCommit': before['commit'] == after['commit']}
    assert local['fixtureSources'] == ledger['fixtureSources']
    assert normalized_linked(local['linkedFixtureSources']['sourceFiles']) == normalized_linked(ledger['linkedFixtureSources']['sourceFiles'])
    assert local['qualifiedToolchain']['runtimeSha256'] == ledger['qualifiedToolchain']['runtimeSha256']
    equivalence['fixtureSources'] = {'sameFiles': True, 'files': len(ledger['fixtureSources'])}
    equivalence['linkedFixtureSources'] = {'sameRelativePathsAndHashes': True, 'files': len(ledger['linkedFixtureSources']['sourceFiles'])}
    equivalence['runtimeSha256Equal'] = True
    (LOCAL / 'new-local-full-hosted-ci-input-equivalence.json').write_text(json.dumps(equivalence, indent=2) + '\n')

    executed = {}
    for name, filename in coordinator.REQUIRED_CHECKS.items():
        tests = ET.parse(HOSTED / 'gate' / filename).getroot().findall('.//test')
        assert len(tests) == ledger['checks'][name]['total']
        assert all(test.get('result') == 'Pass' for test in tests)
        executed[filename] = [test.get('name') for test in tests]
    ordinary = read(LOCAL / 'new-hosted-ordinary-results.json')
    exclusions = ordinary['ordinaryExplicitExclusionsMatchPassedLocalFullGate']
    matched = {name: next((filename for filename, tests in executed.items() if name in tests), None) for name in exclusions}
    assert len(matched) == 7 and all(matched.values())
    lanes = {'Migration gate': ['retained-preflight.xml', 'platform-recovery.xml'],
             'Shared rebuild': ['platform-projection.xml', 'platform-recovery.xml'],
             'Redelivery/restart': ['platform-recovery.xml', 'platform-ha.xml', 'platform-historical.xml'],
             'Unauthorized request': ['platform-recovery.xml', 'platform-historical.xml', 'platform-mtls.xml']}
    matrix = {scenario: {filename: executed[filename] for filename in filenames} for scenario, filenames in lanes.items()}
    frozen = read(LOCAL / 'build-graph-frozen-matrix-audit.json')['frozenIntentSha256']
    (LOCAL / 'new-hosted-frozen-matrix-audit.json').write_text(json.dumps(
        {'frozenIntentSha256': frozen, 'allMappedTestsExecutedAndPassed': True,
         'scenarios': matrix, 'ordinaryExplicitExclusionsPassedInHostedGate': matched}, indent=2) + '\n')
    verification = read(LOCAL / 'new-hosted-verification.json')
    verification.update(canonicalCiAcceptancePassed=True, overallWorkflow='success',
                        artifactId=metadata['artifactId'], artifactZipSha256=artifact_digest,
                        status=ledger['status'], rows=11, proofs=44, rollbackComplete=True,
                        qualifiedToolchain=ledger['qualifiedToolchain'],
                        ledgerSha256=hashlib.sha256((HOSTED / 'gate/ledger.json').read_bytes()).hexdigest(),
                        remaining=['independent final review'])
    (LOCAL / 'new-hosted-verification.json').write_text(json.dumps(verification, indent=2) + '\n')
    print(json.dumps({'hostedCiQualified': True, 'rows': 11, 'proofs': 44,
                      'rollbackComplete': True, 'ordinaryExplicitFactsProven': 7,
                      'canonicalWorksFilesMatchFreshFull': equivalence['Works']['sourceFileCount']}))


if __name__ == '__main__':
    main()
