"""Preserve the completed story 4.9 correction qualification without runtime binaries."""

from pathlib import Path
import gzip
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET

ROOT = Path('/home/administrator/projects/hexalith/works')
LOCAL = ROOT / '.artifacts/story49-review3'
RUN = Path('/tmp/story49-review3-qualification-20261021')
PROFILE_ROOTS = {
    'full': RUN / 'full',
    'ci': LOCAL / 'hosted-parity-39656915517',
    'build-graph-full': Path('/tmp/story49-buildgraph-qualification-20261021/full'),
}
PACKET = ROOT / '_bmad-output/implementation-artifacts/evidence/story-4-9/review-corrections-3-2026-10-21'
SUCCESS = 'passed-disposable-synthetic-parity-and-rollback'
SUFFIXES = {'.json', '.jsonl', '.xml', '.log', '.md'}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def qualification(profile):
    attempt = PROFILE_ROOTS[profile]
    gate = attempt / 'gate'
    ledger = json.loads((gate / 'ledger.json').read_text())
    assert ledger['status'] == SUCCESS
    assert ledger['rollback']['complete'] is True
    assert set(ledger['rows']) == {'R' + str(index) for index in range(1, 12)}
    for row in ledger['rows'].values():
        assert row['status'] == 'passed'
        assert set(row['requiredProofs']) == {'persisted', 'negative', 'restart', 'rollback'}
        assert all(proof['passed'] is True and proof['evidence'] for proof in row['requiredProofs'].values())
    if profile in ('full', 'build-graph-full'):
        invocation_name = 'full-invocation.json' if profile == 'full' else 'build-graph-full-invocation.json'
        invocation = json.loads((LOCAL / invocation_name).read_text())
        assert invocation['exitCode'] == 0
    else:
        assert json.loads((attempt / 'bootstrap.json').read_text())['status'] == SUCCESS
        assert json.loads((LOCAL / 'hosted-verification.json').read_text())['canonicalCiAcceptancePassed'] is True
    checks = {}
    for name, check in ledger['checks'].items():
        if not isinstance(check, dict):
            checks[name] = check
            continue
        assert check['total'] > 0 and check['passed'] == check['total'] and check['skipped'] == 0
        checks[name] = check
    methods = {}
    for path in sorted(gate.glob('*.xml')):
        document = ET.parse(path).getroot()
        tests = document.findall('.//test')
        assert all(test.get('result') == 'Pass' for test in tests)
        methods[path.name] = sorted({test.get('name') for test in tests})
    return {
        'status': ledger['status'], 'profile': ledger['profile'], 'checks': checks,
        'executionLocation': 'GitHub Actions' if profile == 'ci' else 'local',
        'rows': 11, 'proofs': 44, 'rollbackComplete': True,
        'qualifiedToolchain': ledger['qualifiedToolchain'], 'executedMethods': methods,
        'r10Consumer': ledger['rows']['R10']['consumer'],
        'r10Commands': [entry['name'] for entry in ledger['rows']['R10']['targetCommands']],
        'sourceSnapshotUnchanged': ledger['platformSourceSnapshot'] == ledger['platformSourceSnapshotFinal'],
    }


def main():
    summaries = {profile: qualification(profile) for profile in PROFILE_ROOTS}
    assert all(summary['sourceSnapshotUnchanged'] for summary in summaries.values())
    PACKET.mkdir(parents=True, exist_ok=False)
    inventory = {}

    def include(source, relative):
        raw = Path(source).read_bytes()
        target = PACKET / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        compressed = gzip.compress(raw, mtime=0)
        target.write_bytes(compressed)
        inventory[relative] = {'source': str(source), 'sha256': digest(compressed),
                               'uncompressedSha256': digest(raw), 'uncompressedBytes': len(raw)}

    for path in sorted(LOCAL.iterdir()):
        if path.is_file() and (path.suffix in SUFFIXES or path.name.startswith('probe-') and path.suffix == '.py'):
            include(path, 'ordinary/' + path.name + '.gz')
    for profile in PROFILE_ROOTS:
        attempt = PROFILE_ROOTS[profile]
        for path in sorted(attempt.glob('*.json')):
            include(path, profile + '/' + path.name + '.gz')
        gate = attempt / 'gate'
        for path in sorted(gate.iterdir()):
            if path.is_file() and path.suffix in SUFFIXES:
                include(path, profile + '/gate/' + path.name + '.gz')
        for path in sorted((gate / 'agents-full').rglob('*')):
            if path.is_file() and path.suffix in SUFFIXES and not {'bin', 'obj', 'workspace', '.artifacts'}.intersection(path.relative_to(gate).parts):
                include(path, profile + '/gate/' + path.relative_to(gate).as_posix() + '.gz')
        for directory in gate.glob('isolated-daprd*'):
            for name in ('binding.json', 'launches.jsonl'):
                path = directory / name
                if path.is_file():
                    include(path, profile + '/gate/' + path.relative_to(gate).as_posix() + '.gz')

    failed_attempt = RUN / 'ci'
    for path in sorted(failed_attempt.glob('*.json')):
        include(path, 'local-ci-inotify-failure/' + path.name + '.gz')
    for path in sorted((failed_attempt / 'gate').iterdir()):
        if path.is_file() and path.suffix in SUFFIXES:
            include(path, 'local-ci-inotify-failure/gate/' + path.name + '.gz')
    include(LOCAL / 'hosted-parity-39656915517.zip', 'hosted/original-artifact.zip.gz')

    differences = json.loads(Path('/tmp/works-story49-parent-diffs.json').read_text())
    include(Path(differences['corrections']), 'source/works-corrections.diff.gz')
    platform_diff = subprocess.check_output([
        'git', '-C', str(ROOT / 'references/Hexalith.Platform'), 'diff', '--binary', '5b2f03e7a3945af0be3654bc43d5085d2cc4ce52', '--',
        'config/works-proof-toolchain.json', 'config/works-production-profile.schema.json',
        'eng/works_toolchain.py', 'eng/test_works_toolchain.py', 'eng/verify_works_host.py',
        'eng/test_verify_works_host.py', 'docs/works-host-parity.md',
        'src/Hexalith.Platform.Composition/WorksProductionProfile.cs',
        'tests/Hexalith.Platform.Works.Tests/WorksProductionProfileTests.cs',
    ])
    platform_path = LOCAL / 'platform-corrections.diff'
    platform_path.write_bytes(platform_diff)
    include(platform_path, 'source/platform-corrections.diff.gz')
    include(LOCAL / 'assemble-packet.py', 'source/assemble-packet.py.gz')
    include(LOCAL / 'build-graph-fix.diff', 'source/build-graph-fix.diff.gz')
    for name in ('Program.cs', 'graph-inspector.csproj'):
        include(LOCAL / ('graph-inspector-' + name), 'source/graph-inspector/' + name + '.gz')

    summary = {
        'scope': 'Review corrections: local full and hosted CI; subsequent build correction: fresh local full qualification',
        'profiles': summaries,
        'ordinary': {'unit': 589, 'property': 3, 'propertyGeneratedCases': 300, 'architecture': 283,
                     'integrationExecuted': 749, 'integrationExplicitNotRun': 7, 'failures': 0, 'skips': 0},
        'ordinaryAfterBuildCorrection': json.loads((LOCAL / 'build-graph-parent-audit.json').read_text())['ordinary'],
        'hostedVerification': json.loads((LOCAL / 'hosted-verification.json').read_text()),
        'localCiAttempt': {'qualified': False, 'exitCode': 1, 'reason': 'Sentry credentials watch failed with ENOSPC; owned inotify diagnostic admitted zero watches'},
        'productionAdmission': 'closed; no production qualification claimed',
        'machineLimitsChanged': False,
        'subsequentBuildCorrection': {
            'status': 'fresh full qualification passed; changed inputs still require hosted CI and final review',
            'summary': 'ordinary/build-graph-fix-summary.json.gz',
            'required': ['fresh hosted CI qualification of changed source', 'hosted ordinary build and tests', 'independent final review'],
        },
        'frozenMatrix': {
            'Migration gate': {'rows': ['R1', 'R9'], 'lanes': ['retainedStartupPreflight', 'liveRecovery'],
                               'note': 'Historical accepted pre-cutover proof remains immutable; current complete rollback and retained startup pass.'},
            'Shared rebuild': {'rows': ['R4'], 'lanes': ['liveProjection', 'liveRecovery']},
            'Redelivery/restart': {'rows': ['R6', 'R7', 'R11'], 'lanes': ['liveRecovery', 'liveHa', 'liveHistorical']},
            'Unauthorized request': {'rows': ['R3', 'R5', 'R10'], 'lanes': ['liveRecovery', 'liveHistorical', 'liveMtls']},
        },
    }
    (PACKET / 'qualification-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    (PACKET / 'manifest.json').write_text(json.dumps(inventory, indent=2) + '\n')
    for relative, entry in inventory.items():
        compressed = (PACKET / relative).read_bytes()
        assert digest(compressed) == entry['sha256']
        assert digest(gzip.decompress(compressed)) == entry['uncompressedSha256']
    print(json.dumps({'packet': str(PACKET), 'files': len(inventory),
                      'compressedBytes': sum((PACKET / path).stat().st_size for path in inventory)}, indent=2))


if __name__ == '__main__':
    main()
