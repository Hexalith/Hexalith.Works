import base64,hashlib,hmac,json,os,pathlib,secrets,socket,subprocess,time,urllib.error,urllib.request
root=pathlib.Path(__file__).resolve().parent
app=root/'build/bin/Hexalith.Works/debug/Hexalith.Works.dll'
key=secrets.token_bytes(48).hex();channel=secrets.token_hex(32);issuer='story49-owned-probe'
def b64(b):return base64.urlsafe_b64encode(b).decode().rstrip('=')
def assertion():
 now=int(time.time());payload={'iss':issuer,'aud':'works','iat':now,'nbf':now-1,'exp':now+120,'azp':'eventstore','eventstore:operation':['domain-service:metadata']}
 unsigned=b64(b'{"alg":"HS256","typ":"JWT"}')+'.'+b64(json.dumps(payload).encode())
 return unsigned+'.'+b64(hmac.new(key.encode(),unsigned.encode(),hashlib.sha256).digest())
def ports(n):
 socks=[]
 for _ in range(n):
  s=socket.socket();s.bind(('127.0.0.1',0));socks.append(s)
 values=[s.getsockname()[1] for s in socks]
 for s in socks:s.close()
 return values
def request(url,data=None,headers={}):
 try:
  with urllib.request.urlopen(urllib.request.Request(url,data=data,headers=headers),timeout=3) as r:return r.status,r.read()
 except urllib.error.HTTPError as e:return e.code,e.read()
app_port=ports(1)[0]
args=['dotnet',str(app),'--environment=Development','--urls=http://127.0.0.1:'+str(app_port),'--Works:Query:PartiesGatewayBaseAddress=http://127.0.0.1:8999','--EventStore:DomainService:AppId=works','--EventStore:Reminders:ReconciliationEnabled=false','--EventStore:Processes:ReconciliationEnabled=false','--Authentication:JwtBearer:Issuer='+issuer,'--Authentication:JwtBearer:Audience=hexalith-eventstore','--Authentication:JwtBearer:SigningKey='+key,'--Authentication:JwtBearer:AllowedAlgorithms:0=HS256','--Authentication:JwtBearer:RequireHttpsMetadata=false','--Logging:LogLevel:Default=Error']
records=[]
with (root/'works-self-app.log').open('w') as log:
 process=subprocess.Popen(args,stdout=log,stderr=subprocess.STDOUT,env=os.environ|{'APP_API_TOKEN':channel,'DOTNET_USE_POLLING_FILE_WATCHER':'1'},start_new_session=True)
 try:
  deadline=time.monotonic()+30
  while True:
   if process.poll() is not None:raise RuntimeError('Works exited '+str(process.returncode))
   try:request('http://127.0.0.1:'+str(app_port)+'/alive');break
   except Exception:
    if time.monotonic()>deadline:raise
    time.sleep(.1)
  for runtime in (root/'daprd-1.18.3',pathlib.Path('/home/administrator/.dapr/bin/daprd')):
   version=subprocess.check_output([str(runtime),'--version'],text=True).strip();selected=ports(4)
   args=[str(runtime),'--app-id','works','--app-port',str(app_port),'--dapr-http-port',str(selected[0]),'--dapr-grpc-port',str(selected[1]),'--dapr-internal-grpc-port',str(selected[2]),'--metrics-port',str(selected[3]),'--disable-init-endpoints','config,subscribe','--log-level','info']
   with (root/('works-self-daprd-'+version+'.log')).open('w') as output:
    sidecar=subprocess.Popen(args,stdout=output,stderr=subprocess.STDOUT,env=os.environ|{'APP_API_TOKEN':channel,'NAMESPACE':'default'},start_new_session=True)
    try:
     deadline=time.monotonic()+30
     while True:
      if sidecar.poll() is not None:raise RuntimeError('daprd exited '+str(sidecar.returncode))
      try:
       code,_=request('http://127.0.0.1:'+str(selected[0])+'/v1.0/healthz')
       if code==204:break
      except Exception:pass
      if time.monotonic()>deadline:raise RuntimeError('daprd readiness timeout')
      time.sleep(.1)
     observations=[]
     for spoof in (None,'eventstore'):
      headers={'content-type':'application/json','X-Hexalith-Workload-Assertion':assertion()}
      if spoof:headers['dapr-caller-app-id']=spoof
      code,body=request('http://127.0.0.1:'+str(selected[0])+'/v1.0/invoke/works/method/admin/operational-index-metadata',data=b'{}',headers=headers)
      observations.append({'suppliedCaller':spoof,'status':code,'bodySha256':hashlib.sha256(body).hexdigest(),'bodyBytes':len(body)})
     records.append({'version':version,'runtimeSha256':hashlib.sha256(runtime.read_bytes()).hexdigest(),'applicationSha256':hashlib.sha256(app.read_bytes()).hexdigest(),'command':args,'observations':observations,'mtls':False,'scope':'actual Works SDK workload authentication over owned self-invocation; no domain writes, production or full parity claim'})
    finally:
     sidecar.terminate()
     try:sidecar.wait(timeout=10)
     except subprocess.TimeoutExpired:sidecar.kill();sidecar.wait()
 finally:
  process.terminate()
  try:process.wait(timeout=10)
  except subprocess.TimeoutExpired:process.kill();process.wait()
(root/'works-self-invocation-comparison.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps(records,indent=2))
