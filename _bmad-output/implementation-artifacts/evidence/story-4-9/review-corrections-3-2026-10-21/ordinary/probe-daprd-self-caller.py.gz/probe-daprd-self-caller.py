import hashlib,http.server,json,os,pathlib,socket,subprocess,threading,time,urllib.request,uuid
root=pathlib.Path(__file__).resolve().parent
runtime183=root/'daprd-1.18.3'
container='works-story49-daprd183-'+uuid.uuid4().hex[:8]
try:
 subprocess.run(['docker','create','--name',container,'daprio/dapr:1.18.3','/daprd'],check=True,capture_output=True)
 subprocess.run(['docker','cp',container+':/daprd',str(runtime183)],check=True,capture_output=True)
finally:
 subprocess.run(['docker','rm','-f',container],check=False,capture_output=True)
runtime183.chmod(0o700)
records=[]
class Receiver(http.server.BaseHTTPRequestHandler):
 def do_POST(self):
  body=json.dumps({'caller':self.headers.get('dapr-caller-app-id'),'headers':dict(self.headers)}).encode()
  self.send_response(200);self.send_header('content-type','application/json');self.send_header('content-length',str(len(body)));self.end_headers();self.wfile.write(body)
 def log_message(self,*_):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Receiver)
thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
try:
 for runtime in (runtime183,pathlib.Path('/home/administrator/.dapr/bin/daprd')):
  version=subprocess.check_output([str(runtime),'--version'],text=True).strip()
  sockets=[]
  for _ in range(4):
   s=socket.socket();s.bind(('127.0.0.1',0));sockets.append(s)
  ports=[s.getsockname()[1] for s in sockets]
  resources=root/('empty-components-'+version);resources.mkdir(exist_ok=True)
  args=[str(runtime),'--app-id','works','--app-port',str(server.server_port),'--dapr-http-port',str(ports[0]),'--dapr-grpc-port',str(ports[1]),'--dapr-internal-grpc-port',str(ports[2]),'--metrics-port',str(ports[3]),'--resources-path',str(resources),'--log-level','info']
  for s in sockets:s.close()
  with (root/('self-caller-'+version+'.log')).open('w') as log:
   process=subprocess.Popen(args,stdout=log,stderr=subprocess.STDOUT,env=os.environ|{'NAMESPACE':'default'},start_new_session=True)
   try:
    deadline=time.monotonic()+30
    while True:
     if process.poll() is not None:raise RuntimeError('daprd exited '+str(process.returncode))
     try:
      with urllib.request.urlopen('http://127.0.0.1:'+str(ports[0])+'/v1.0/healthz',timeout=1) as response:response.read()
      break
     except Exception:
      if time.monotonic()>deadline:raise
      time.sleep(.1)
    observed=[]
    for spoof in (None,'eventstore'):
     headers={'content-type':'application/json','x-eventstore-workload-assertion':'synthetic-valid-assertion-placeholder'}
     if spoof:headers['dapr-caller-app-id']=spoof
     request=urllib.request.Request('http://127.0.0.1:'+str(ports[0])+'/v1.0/invoke/works/method/project/v2',data=b'{}',headers=headers)
     with urllib.request.urlopen(request,timeout=5) as response:observed.append({'suppliedCaller':spoof,'status':response.status,'received':json.load(response)})
    records.append({'runtime':str(runtime),'version':version,'sha256':hashlib.sha256(runtime.read_bytes()).hexdigest(),'command':args,'observations':observed,'mtls':False,'scope':'owned self-invocation caller-attribution probe; no production or full parity claim'})
   finally:
    process.terminate()
    try:process.wait(timeout=10)
    except subprocess.TimeoutExpired:process.kill();process.wait()
finally:
 server.shutdown();server.server_close()
(root/'self-caller-comparison.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps([{k:r[k] for k in ('version','sha256','observations')} for r in records],indent=2))
