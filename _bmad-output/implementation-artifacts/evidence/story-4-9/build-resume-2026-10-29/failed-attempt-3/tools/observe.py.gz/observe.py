"""Observe only exact runtime/config/PID-bound resources recorded by this gate."""
import hashlib
import json
import os
from pathlib import Path
import sys
import time
import urllib.error
import urllib.request

FLAGS = {'--app-id', '--app-port', '--dapr-http-port', '--dapr-grpc-port', '--config'}
SAFE_ENV = {'DAPR_HTTP_ENDPOINT', 'DAPR_GRPC_ENDPOINT', 'DAPR_HTTP_PORT', 'DAPR_GRPC_PORT', 'ASPNETCORE_URLS'}

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def stat(pid):
    fields = (Path('/proc') / str(pid) / 'stat').read_text().rsplit(')', 1)[1].split()
    return {'pid': int(pid), 'ppid': int(fields[1]), 'startTicks': fields[19], 'state': fields[0]}

def listeners(proc):
    sockets = set()
    for fd in (proc / 'fd').iterdir():
        try:
            target = os.readlink(fd)
            if target.startswith('socket:['):
                sockets.add(target[8:-1])
        except OSError:
            pass
    ports = set()
    for name in ('tcp', 'tcp6'):
        try:
            for line in (proc / 'net' / name).read_text().splitlines()[1:]:
                fields = line.split()
                if fields[3] == '0A' and fields[9] in sockets:
                    ports.add(int(fields[1].rsplit(':', 1)[1], 16))
        except (OSError, IndexError, ValueError):
            pass
    return sorted(ports)

def probe(port, route):
    try:
        with urllib.request.urlopen('http://127.0.0.1:' + str(port) + route, timeout=0.5) as response:
            return {'status': response.status}
    except urllib.error.HTTPError as error:
        return {'status': error.code}
    except Exception as error:
        return {'exception': type(error).__name__}

def observe(run_root):
    out = run_root / 'native-observations.jsonl'
    seen = {}
    with out.open('w') as stream:
        while not (run_root / 'result.json').exists():
            for profile in ('full', 'ci'):
                base = run_root / profile / 'gate'
                try:
                    ledger = json.loads((base / 'ledger.json').read_text())
                    runtime = ledger['isolatedRuntime']
                    expected = ledger['runtimeArtifacts']
                    consumer_root = ledger['consumer']['root']
                    environment = ledger['runtimeEnvironment']
                    starts = [json.loads(line) for line in (base / 'host-starts.jsonl').read_text().splitlines() if line]
                except (OSError, ValueError, KeyError):
                    continue
                configs = {(row['appId'], row['config'], row['configSha256']) for start in starts for row in start['sidecarLaunches'] if row['appId'] == 'works'}
                if not configs:
                    continue
                sample = {'at': time.time(), 'profile': profile, 'processes': []}
                for proc in Path('/proc').iterdir():
                    if not proc.name.isdecimal():
                        continue
                    try:
                        exe = Path(os.readlink(proc / 'exe'))
                        if exe.name not in {'daprd', 'dotnet', 'Hexalith.Works'}:
                            continue
                        row = stat(proc.name)
                        args = (proc / 'cmdline').read_bytes().decode().split('\0')
                        flags = {flag: args[args.index(flag) + 1] for flag in FLAGS if flag in args and args.index(flag) + 1 < len(args)}
                        if exe.name == 'daprd' and flags.get('--app-id') == 'works':
                            config = flags.get('--config')
                            if not config or ('works', config, sha(config)) not in configs or sha(exe) != runtime['runtimeSha256']:
                                continue
                            row.update({'kind': 'works-sidecar', 'flags': flags, 'listeners': listeners(proc)})
                            port = flags.get('--dapr-http-port', '')
                            if port.isdecimal() and int(port) in row['listeners']:
                                row['metadata'] = probe(int(port), '/v1.0/metadata')
                                row['missingKeyRead'] = probe(int(port), '/v1.0/state/statestore/__story49_diagnostic_missing_key__')
                        elif exe.name == 'Hexalith.Works' and str(exe) in expected and sha(exe) == expected[str(exe)] or exe.name == 'dotnet' and any(Path(arg).name in {'Hexalith.Works.dll', 'Hexalith.Works.csproj'} for arg in args if arg):
                            all_env = dict(item.partition('=')[::2] for item in (proc / 'environ').read_bytes().decode().split('\0') if '=' in item)
                            scoped = all_env.get('ArtifactsPath') == environment.get('ArtifactsPath') or all_env.get('WORKS_PLATFORM_HOST_EVIDENCE') == str(base / 'host-starts.jsonl') or str(consumer_root) in all_env.get('DOTNET_STARTUP_HOOKS', '')
                            if not scoped:
                                continue
                            row.update({'kind': 'works-app', 'environment': {key: value for key, value in all_env.items() if key in SAFE_ENV}, 'listeners': listeners(proc)})
                        else:
                            continue
                        if stat(proc.name)['startTicks'] != row['startTicks']:
                            continue
                        seen[(profile, row['pid'], row['startTicks'])] = row['kind']
                        sample['processes'].append(row)
                    except (OSError, ValueError, IndexError, UnicodeError):
                        pass
                stream.write(json.dumps(sample) + '\n')
                stream.flush()
            time.sleep(3)
    summary = {'status': 'read-only exact-recorded-config/runtime/PID-start observations', 'admittedProcesses': len(seen), 'kinds': sorted(set(seen.values())), 'extraHelperContainers': 0, 'containerExecCalls': 0}
    (run_root / 'native-observer-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary), flush=True)

if __name__ == '__main__':
    observe(Path(sys.argv[1]).resolve())
