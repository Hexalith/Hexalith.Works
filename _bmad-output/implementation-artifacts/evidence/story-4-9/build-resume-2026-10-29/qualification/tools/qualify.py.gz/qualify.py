"""Run the unchanged canonical full profile, then the actual CI entry point."""
import datetime
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

WORKS = Path('/home/administrator/projects/hexalith/works')

def main():
    run_root = Path(tempfile.mkdtemp(prefix='story49-build-20261029-', dir='/tmp'))
    print(json.dumps({'runRoot': str(run_root)}), flush=True)
    module_spec = importlib.util.spec_from_file_location('story49_ci_bootstrap', WORKS / 'scripts/verify-platform-parity-ci.py')
    coordinator = importlib.util.module_from_spec(module_spec)
    module_spec.loader.exec_module(coordinator)
    command, environment, record, snapshot = coordinator.bootstrap(WORKS, run_root / 'full')
    command[command.index('--profile') + 1] = 'full'
    environment.pop('GH_TOKEN', None)
    if not environment.get('GITHUB_TOKEN'):
        token = subprocess.run(['gh', 'auth', 'token'], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, timeout=10)
        if token.returncode == 0:
            environment['GITHUB_TOKEN'] = token.stdout.strip()
    invocation = {'scope': 'fresh current-input qualification; full before actual CI',
                  'startedAt': datetime.datetime.now(datetime.UTC).isoformat(),
                  'fullCommand': command, 'producerReadTokenPresent': bool(environment.get('GITHUB_TOKEN')),
                  'runtimeEnvironmentPins': {'DOTNET_USE_POLLING_FILE_WATCHER': environment.get('DOTNET_USE_POLLING_FILE_WATCHER')}}
    (run_root / 'invocation.json').write_text(json.dumps(invocation, indent=2) + '\n')
    with (run_root / 'full-driver.log').open('w') as log:
        full = subprocess.run(command, cwd=WORKS, env=environment, stdout=log, stderr=subprocess.STDOUT)
    invocation['fullExitCode'] = full.returncode
    if full.returncode:
        invocation['status'] = 'full-failed; actual-CI-not-run'
        (run_root / 'result.json').write_text(json.dumps(invocation, indent=2) + '\n')
        print(json.dumps({'status': invocation['status'], 'fullExitCode': full.returncode, 'runRoot': str(run_root)}), flush=True)
        return full.returncode
    coordinator.require_unchanged_coordinators(record['coordinatorSha256'])
    if snapshot.origin_files(Path(record['platformOrigin'])) != record['platformSourceFiles']:
        raise RuntimeError('Platform inputs drifted after full qualification; CI not run')
    ci_command = ['bash', str(WORKS / 'scripts/verify-platform-parity-ci.sh'), '--artifacts-path', str(run_root / 'ci')]
    invocation['ciCommand'] = ci_command
    with (run_root / 'ci-driver.log').open('w') as log:
        ci = subprocess.run(ci_command, cwd=WORKS, env=environment, stdout=log, stderr=subprocess.STDOUT)
    invocation['ciExitCode'] = ci.returncode
    invocation['status'] = 'full-and-actual-CI-passed' if ci.returncode == 0 else 'full-passed; actual-CI-failed'
    invocation['finishedAt'] = datetime.datetime.now(datetime.UTC).isoformat()
    (run_root / 'result.json').write_text(json.dumps(invocation, indent=2) + '\n')
    print(json.dumps({'status': invocation['status'], 'fullExitCode': full.returncode, 'ciExitCode': ci.returncode, 'runRoot': str(run_root)}), flush=True)
    return ci.returncode

if __name__ == '__main__':
    sys.exit(main())
