"""Independently rebind completed canonical qualification to exact local evidence."""
import copy
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import xml.etree.ElementTree as ET

WORKS = Path('/home/administrator/projects/hexalith/works')
MATRIX = {
    'Migration gate': [('retained-preflight.xml', 'ArchivedTopologyReachesHealthyReadiness'), ('platform-recovery.xml', 'SdkRemindersAndCascadeConvergeThroughPersistedReceiptsAcrossRestart')],
    'Shared rebuild': [('platform-projection.xml', 'ActualPlatformSharedRebuildAndConcurrentCatchUpPreserveCompleteFamily'), ('platform-recovery.xml', 'SdkRemindersAndCascadeConvergeThroughPersistedReceiptsAcrossRestart')],
    'Redelivery/restart': [('platform-recovery.xml', 'SuccessfulCallbacksRegisterSdkReminderAndProcessWithoutPeriodicRecovery'), ('platform-recovery.xml', 'SdkRemindersAndCascadeConvergeThroughPersistedReceiptsAcrossRestart'), ('platform-ha.xml', 'TwoWorksHostsRecoverLostFiringAfterPrimaryStopsWithoutDuplicateEffect')],
    'Unauthorized request': [('platform-historical.xml', 'PlatformLifecycleTreeClaimFilteringAndSecuritySurviveRestart'), ('platform-recovery.xml', 'SdkRemindersAndCascadeConvergeThroughPersistedReceiptsAcrossRestart'), ('platform-recovery.xml', 'SuccessfulCallbacksRegisterSdkReminderAndProcessWithoutPeriodicRecovery'), ('platform-mtls.xml', 'Mtls_allows_event_store_and_denies_an_unauthorized_caller_at_works_process'), ('platform-ha.xml', 'TwoWorksHostsRecoverLostFiringAfterPrimaryStopsWithoutDuplicateEffect')],
}

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def require(condition, message):
    if not condition:
        raise ValueError(message)

def main(run_root):
    results = {'status': 'incomplete', 'profiles': {}, 'scope': 'current recorded local full and actual CI; no hosted Actions or production qualification claimed'}
    ledgers, bootstraps = {}, {}
    try:
        terminal = json.loads((run_root / 'result.json').read_text())
        require(terminal['status'] == 'full-and-actual-CI-passed', 'Both terminal profile results are required')
        for name in ('full', 'ci'):
            base = run_root / name
            ledger = json.loads((base / 'gate/ledger.json').read_text())
            bootstrap = json.loads((base / 'bootstrap.json').read_text())
            platform = Path(bootstrap['platformRoot'])
            require(ledger['status'] == 'passed-disposable-synthetic-parity-and-rollback', name + ': owning status')
            require(ledger['profile']['name'] == name, name + ': actual profile')
            require(set(ledger['rows']) == {'R' + str(i) for i in range(1, 12)}, name + ': eleven rows')
            require(sha(platform / 'eng/verify_works_host.py') == ledger['verifierSha256'], name + ': verifier source hash')
            for helper, digest in ledger['verifierHelpers'].items():
                require(sha(platform / 'eng' / helper) == digest, name + ': helper hash ' + helper)
            # Use verified fresh source copies, never an existing imported module or bytecode cache.
            with tempfile.TemporaryDirectory(prefix='story49-parent-evaluator-') as temp:
                evaluator_root = Path(temp)
                module_path = evaluator_root / 'verify_works_host.py'
                module_path.write_bytes((platform / 'eng/verify_works_host.py').read_bytes())
                for helper in ledger['verifierHelpers']:
                    target = evaluator_root / helper
                    target.parent.mkdir(parents=True, exist_ok=True)
                    target.write_bytes((platform / 'eng' / helper).read_bytes())
                sys.path.insert(0, str(evaluator_root))
                try:
                    for imported in list(sys.modules):
                        if imported in {'verify_works_host', 'verify_works_producer', 'works_host_snapshot', 'works_toolchain', 'works_verifier_command', 'isolated_daprd', 'retained_works_host'}:
                            del sys.modules[imported]
                    specification = importlib.util.spec_from_file_location('verify_works_host', module_path)
                    verifier = importlib.util.module_from_spec(specification)
                    specification.loader.exec_module(verifier)
                    version = bootstrap['sdkVersion']
                    assembly = Path(ledger['host']['assembly'])
                    retained = Path(ledger['retainedHostSource']['assembly'])
                    starts = verifier.verify_host_records(base / 'gate/host-starts.jsonl', assembly, platform, version,
                        runtime_artifacts=ledger['runtimeArtifacts'], host_runtime=Path(ledger['platformRuntimeIdentity']['hostOutput']),
                        composition_literals=verifier.platform_composition_literals(platform / 'src/Hexalith.Platform.Composition/WorksPreviewModel.cs'),
                        control_plane_ports=ledger['controlPlanePorts'], retained_assembly=retained)
                    require(starts == ledger['actualStarts'], name + ': independently verified actual host starts')
                    launcher = verifier.isolated_daprd.verify(base / 'gate/isolated-daprd', ledger['isolatedRuntime'], starts)
                    require(launcher == ledger['isolatedRuntimeEvidence'], name + ': independently verified main launcher')
                    preflight = verifier.verify_host_records(base / 'gate/retained-preflight-starts.jsonl', assembly, platform, version,
                        runtime_artifacts=ledger['runtimeArtifacts'], control_plane_ports=ledger['controlPlanePorts'],
                        retained_assembly=retained, retained_preflight=True)
                    require(preflight == ledger['retainedPreflightStarts'], name + ': independently verified retained preflight')
                    preflight_launcher = verifier.isolated_daprd.verify(base / 'gate/isolated-daprd-retained-preflight', ledger['retainedPreflightRuntime'], preflight)
                    require(preflight_launcher == ledger['retainedPreflightRuntimeEvidence'], name + ': independently verified preflight launcher')
                    rebound = copy.deepcopy(ledger['rows'])
                    rollback = verifier.bind_persisted_outcomes(base / 'gate/persisted-states.jsonl', rebound, starts)
                    require(rebound == ledger['rows'], name + ': independently rebound row predicates')
                    require(rollback == ledger['rollback'], name + ': independently rebound complete rollback')
                    require(rollback.get('complete') is True, name + ': complete rollback required')
                    require(sum(len(row['requiredProofs']) for row in rebound.values()) == 44, name + ': exactly 44 persisted proofs')
                    require(all(proof['passed'] is True for row in rebound.values() for proof in row['requiredProofs'].values()), name + ': every persisted proof passed')
                    verifier.require_unchanged_inputs(ledger, WORKS, platform, Path(bootstrap['platformSourceBinding']), tuple(ledger['controlPlanePortSelection']['excludedEphemeralRange']), tuple(tuple(pair) for pair in ledger['controlPlanePortSelection']['excludedReservedRanges']))
                finally:
                    sys.path.pop(0)
            xml_names = ['platform-release.xml', 'works-consumer-supporting.xml', 'retained-preflight.xml', 'platform-recovery.xml', 'platform-historical.xml', 'platform-ha.xml', 'platform-mtls.xml', 'platform-projection.xml']
            if name == 'full':
                xml_names.insert(0, 'platform-debug.xml')
            xml_tests, total = {}, 0
            for xml_name in xml_names:
                root = ET.parse(base / 'gate' / xml_name).getroot()
                tests = list(root.iter('test'))
                require(bool(tests), name + ': missing executed cases in ' + xml_name)
                require(all(t.get('result') == 'Pass' for t in tests), name + ': nonpassing case in ' + xml_name)
                for assembly in root.iter('assembly'):
                    for key in ('errors', 'failed', 'skipped', 'not-run'):
                        require(int(assembly.get(key, '0')) == 0, name + ': XML ' + key)
                xml_tests[xml_name] = tests
                total += len(tests)
            matrix = []
            for scenario, coverage in MATRIX.items():
                matched = []
                for xml_name, method in coverage:
                    found = [t for t in xml_tests[xml_name] if t.get('method') == method]
                    require(len(found) == 1 and found[0].get('result') == 'Pass', name + ': matrix method ' + method)
                    matched.append({'xml': xml_name, 'method': method, 'type': found[0].get('type'), 'result': 'Pass'})
                matrix.append({'scenario': scenario, 'coverage': matched})
            for command in ledger['commands']:
                expected = 1 if command['name'] == 'agents-full-refusal' else 0
                require(command['exitCode'] == expected, name + ': command exit ' + command['name'])
                require(sha(base / 'gate' / command['log']) == command['sha256'], name + ': command log hash ' + command['name'])
            results['profiles'][name] = {'status': 'passed', 'ledgerSha256': sha(base / 'gate/ledger.json'), 'directXmlFacts': total,
                'xmlCounts': {key: len(value) for key, value in xml_tests.items()}, 'rows': len(ledger['rows']),
                'proofs': sum(len(row['requiredProofs']) for row in ledger['rows'].values()), 'rollbackComplete': rollback['complete'],
                'persistedPhases': len((base / 'gate/persisted-states.jsonl').read_text().splitlines()), 'hostStarts': len(starts),
                'runtimeArtifacts': len(ledger['runtimeArtifacts']), 'matrix': matrix, 'sourceRuntimeFixtureArchiveClosure': 'passed'}
            ledgers[name], bootstraps[name] = ledger, bootstrap
        require(bootstraps['full']['sdkCommit'] == bootstraps['ci']['sdkCommit'], 'Producer commit differs across profiles')
        require(bootstraps['full']['platformSourceFiles'] == bootstraps['ci']['platformSourceFiles'], 'Platform source bytes differ across profiles')
        require(ledgers['full']['worksConsumerSource'] == ledgers['ci']['worksConsumerSource'], 'Works consumer inputs differ across profiles')
        require(ledgers['full']['fixtureSources'] == ledgers['ci']['fixtureSources'], 'Works fixtures differ across profiles')
        normalized_linked = {}
        for name in ('full', 'ci'):
            linked = copy.deepcopy(ledgers[name]['linkedFixtureSources'])
            selected_root = Path(bootstraps[name]['platformRoot'])
            require(linked['compositionRoot'] == str(selected_root), name + ': linked composition root must be its selected export')
            normalized = {}
            for source_path, digest in linked['sourceFiles'].items():
                try:
                    key = '<selected-platform-export>/' + Path(source_path).relative_to(selected_root).as_posix()
                except ValueError:
                    key = source_path
                require(key not in normalized, name + ': linked path normalization collision')
                normalized[key] = digest
            require(len(normalized) == len(linked['sourceFiles']), name + ': complete linked membership')
            linked['sourceFiles'] = normalized
            linked['compositionRoot'] = '<selected-platform-export>'
            normalized_linked[name] = linked
        require(normalized_linked['full'] == normalized_linked['ci'], 'Linked authority/identity/Composition bytes or membership differ across profiles')
        results['linkedFixtureEquivalence'] = {'comparedFiles': len(normalized_linked['full']['sourceFiles']),
            'normalization': 'Only each bootstrap-selected Platform export prefix is replaced; relative membership, SHA256 values, other absolute paths and commit metadata remain exact'}
        full_sdk = ledgers['full']['sourceProducers']['worksDebugAndRuntimeSdk']
        ci_sdk = ledgers['ci']['sourceProducers']['worksRuntimeSdk']
        require(full_sdk['sourceFiles'] == ci_sdk['sourceFiles'], 'SDK runtime source bytes differ across profiles')
        require(all(full_sdk['buildsInputs'][key] == ci_sdk['buildsInputs'][key] for key in ('resolvedRoot', 'sourceFiles', 'inventorySha256')), 'SDK imported Builds inputs differ across profiles')
        results.update({'status': 'passed', 'sdkVersion': bootstraps['full']['sdkVersion'], 'sdkCommit': bootstraps['full']['sdkCommit'],
            'sameInputFullThenActualCi': True})
    except Exception as error:
        results['status'] = 'failed'
        results['error'] = str(error)
        raise
    finally:
        (run_root / 'parent-audit.json').write_text(json.dumps(results, indent=2) + '\n')
        print(json.dumps({'status': results['status'], 'profiles': {key: value.get('directXmlFacts') for key, value in results['profiles'].items()}, 'error': results.get('error')}))

if __name__ == '__main__':
    main(Path(sys.argv[1]).resolve())
