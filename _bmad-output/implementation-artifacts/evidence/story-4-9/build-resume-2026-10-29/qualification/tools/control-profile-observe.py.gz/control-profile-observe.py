"""Read-only probes of control-plane containers bound to an exact config source."""
import hashlib, json, subprocess, sys, time, urllib.request, urllib.error
from pathlib import Path

def docker(*args):
    return subprocess.check_output(['docker', *args], text=True, stderr=subprocess.DEVNULL, timeout=5)

def probe(url):
    try:
        with urllib.request.urlopen(url, timeout=.5) as r:return {'status':r.status}
    except urllib.error.HTTPError as e:return {'status':e.code}
    except Exception as e:return {'exception':type(e).__name__}

def main(root, source, stop):
    config=(source/'components/sentry.yaml').resolve()
    if not config.exists():
        candidates=list(source.glob('**/sentry.yaml'))
        assert len(candidates)==1, candidates
        config=candidates[0].resolve()
    binding={'config':str(config),'configSha256':hashlib.sha256(config.read_bytes()).hexdigest(),'mutations':0,'containerExecCalls':0,'helperContainers':0}
    (root/'control-observer-binding.json').write_text(json.dumps(binding,indent=2)+'\n')
    admitted={}
    template='{"id":{{json .Id}},"name":{{json .Name}},"image":{{json .Image}},"mounts":{{json .Mounts}},"ports":{{json .NetworkSettings.Ports}},"networks":{{json .NetworkSettings.Networks}},"running":{{json .State.Running}},"exitCode":{{json .State.ExitCode}},"startedAt":{{json .State.StartedAt}}}'
    with (root/'control-observations.jsonl').open('w') as out:
        while not stop.exists():
            sample={'at':time.time(),'containers':[]}
            try:
                ids=docker('ps','--filter','name=dapr-sentry-','--format','{{.ID}}').split()
                for cid in ids:
                    row=json.loads(docker('inspect','--format',template,cid))
                    if not any(Path(m['Source']).resolve()==config and m['Destination']=='/var/run/dapr/config/sentry.yaml' for m in row['mounts']):continue
                    if hashlib.sha256(config.read_bytes()).hexdigest()!=binding['configSha256']:raise ValueError('Observed config drift')
                    certs=next(Path(m['Source']) for m in row['mounts'] if m['Destination']=='/var/run/dapr/credentials')
                    row['credentialsMetadata']={}
                    for filename in ['ca.crt','issuer.crt','issuer.key']:
                        p=certs/filename
                        if p.is_file():
                            s=p.stat();row['credentialsMetadata'][filename]={'bytes':s.st_size,'mtimeNs':s.st_mtime_ns}
                    row['publishedHealth']=[]
                    for port in (row['ports'] or {}).get('8080/tcp',[]) or []:
                        host=port['HostIp']
                        if host in ('0.0.0.0','::',''):host='127.0.0.1'
                        if ':' in host:host='['+host+']'
                        url='http://'+host+':'+port['HostPort']+'/healthz'
                        row['publishedHealth'].append({'url':url,'result':probe(url)})
                    row['bridgeHealth']=[]
                    for network in (row['networks'] or {}).values():
                        ip=network.get('IPAddress')
                        if ip:row['bridgeHealth'].append({'ip':ip,'result':probe('http://'+ip+':8080/healthz')})
                    # Persist only needed network fields, never environment or credential bytes.
                    del row['networks']
                    admitted[row['id']]=row['name'];sample['containers'].append(row)
            except (OSError,subprocess.SubprocessError,ValueError) as e:sample['observerException']=type(e).__name__
            out.write(json.dumps(sample)+'\n');out.flush();time.sleep(2)
    (root/'control-observer-summary.json').write_text(json.dumps({'admittedContainers':admitted,'mutations':0,'containerExecCalls':0,'helperContainers':0},indent=2)+'\n')
if __name__=='__main__':main(Path(sys.argv[1]).resolve(),Path(sys.argv[2]).resolve(),Path(sys.argv[3]).resolve())
