"""Qualify only after the unchanged failed-recovery fact passes; observe owned resources."""
import json, subprocess, sys, time, xml.etree.ElementTree as ET
from pathlib import Path
FOCUS=Path('/tmp/story49-recovery-focus-20261029-3in7s8es')
while not (FOCUS/'result.json').exists():time.sleep(3)
f=json.loads((FOCUS/'result.json').read_text())
tests=list(ET.parse(FOCUS/'result.xml').getroot().iter('test'))
if f['exitCode'] or not f['runtimeUnchangedAfter'] or len(tests)!=1 or tests[0].get('result')!='Pass':
    print('Recovery diagnostic did not pass unchanged; complete qualification not retried.',flush=True)
    raise SystemExit(1)
child=subprocess.Popen(['python3','/tmp/story49-build-20261029-qualify.py'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
first=child.stdout.readline();print(first,end='',flush=True)
run=Path(json.loads(first)['runRoot']);stop=run/'observer-stop.json'
observers=[];profiles=set()
def launch(script,args,log):
    stream=log.open('w');p=subprocess.Popen(['python3',script,*map(str,args)],stdout=stream,stderr=subprocess.STDOUT)
    observers.append((p,stream,script))
launch('/tmp/story49-build-20261029-native-profile-observe.py',[run],run/'native-observer.log')
while child.poll() is None:
    for name in ('full','ci'):
        bootstrap=run/name/'bootstrap.json'
        if name not in profiles and bootstrap.exists():
            try:b=json.loads(bootstrap.read_text())
            except ValueError:continue
            source=Path(b['platformRoot'])
            if not source.is_dir():continue
            out=run/(name+'-health-observer');out.mkdir()
            launch('/tmp/story49-build-20261029-control-profile-observe.py',[out,source,stop],out/'control.log')
            launch('/tmp/story49-build-20261029-dcp-profile-observe.py',[out,stop],out/'dcp.log')
            profiles.add(name)
    time.sleep(2)
for line in child.stdout:print(line,end='',flush=True)
stop.write_text(json.dumps({'qualifierExitCode':child.returncode,'scope':'observer lifecycle only; not gate acceptance'})+'\n')
result={'qualifierExitCode':child.returncode,'observers':[]}
for p,stream,script in observers:
    try:code=p.wait(timeout=40)
    except subprocess.TimeoutExpired:
        p.terminate();code=p.wait(timeout=10)
    stream.close();result['observers'].append({'script':script,'exitCode':code})
(run/'supervisor-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'runRoot':str(run),**result}),flush=True)
raise SystemExit(child.returncode)
