import datetime, hashlib, json, subprocess, time
from pathlib import Path
root=Path('/tmp/story49-build-20261029-oe7n1gwt')
script=Path('/tmp/story49-build-20261029-audit.py')
digest=hashlib.sha256(script.read_bytes()).hexdigest()
while not (root/'result.json').exists():time.sleep(3)
result=json.loads((root/'result.json').read_text())
if result['status']!='full-and-actual-CI-passed':
    print('Canonical qualification did not pass both profiles; no acceptance audit invoked.',flush=True)
    raise SystemExit(1)
assert hashlib.sha256(script.read_bytes()).hexdigest()==digest, 'Parent audit source drift'
command=['python3',str(script),str(root)]
(root/'parent-audit-invocation.json').write_text(json.dumps({'startedAt':datetime.datetime.now(datetime.UTC).isoformat(),'command':command,'auditorSha256':digest,'terminalResultSha256':hashlib.sha256((root/'result.json').read_bytes()).hexdigest()},indent=2)+'\n')
with (root/'parent-audit.log').open('w') as log:
    outcome=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
print(json.dumps({'auditExitCode':outcome.returncode,'runRoot':str(root)}),flush=True)
raise SystemExit(outcome.returncode)
