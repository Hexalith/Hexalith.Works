"""Keep bounded canonical records; omit generated workspaces and credential files."""
import gzip, hashlib, json, sys
from pathlib import Path
ROOT=Path('/home/administrator/projects/hexalith/works')
PACKET=ROOT/'_bmad-output/implementation-artifacts/evidence/story-4-9/build-resume-2026-10-29'
def sha(b): return hashlib.sha256(b).hexdigest()
def main(run, label="qualification"):
    result=json.loads((run/'result.json').read_text())
    audit=json.loads((run/'parent-audit.json').read_text()) if (run/'parent-audit.json').exists() else None
    if result['status']=='full-and-actual-CI-passed':
        assert audit and audit['status']=='passed', 'Parent audit must pass before packaging acceptance'
    files=[]
    def archive(source, relative):
        if not source.is_file(): return
        raw=source.read_bytes(); output=PACKET/relative
        assert not output.exists(), str(output)
        output.parent.mkdir(parents=True,exist_ok=True)
        encoded=gzip.compress(raw,mtime=0)
        output.write_bytes(encoded)
        files.append(dict(path=str(relative),sha256=sha(encoded),nativePath=str(source),nativeSha256=sha(raw),nativeBytes=len(raw)))
    for name in ['invocation.json','result.json','full-driver.log','ci-driver.log','parent-audit.json','native-observations.jsonl','native-observer-summary.json','native-observer.log','supervisor-result.json','observer-stop.json','parent-audit-invocation.json','parent-audit.log','daemon-resume.json','parent-audit-watcher-adjustment.json','parent-audit-attempt-1.json','parent-audit-attempt-1.log','parent-audit-invocation-attempt-1.json','parent-audit-adjustment.json']:
        archive(run/name,Path(label)/(name+'.gz'))
    for profile in ['full','ci']:
        for name in ['bootstrap.json','platform-source-binding.json']:
            archive(run/profile/name,Path(label)/profile/(name+'.gz'))
        gate=run/profile/'gate'
        if not gate.exists(): continue
        names={p.name for p in gate.iterdir() if p.is_file() and p.suffix in ['.log','.xml']}
        names.update(['ledger.json','host-starts.jsonl','persisted-states.jsonl','retained-preflight-starts.jsonl'])
        for name in sorted(names):
            archive(gate/name,Path(label)/profile/'gate'/(name+'.gz'))
        for launcher in ['isolated-daprd','isolated-daprd-retained-preflight']:
            for name in ['binding.json','launches.jsonl']:
                archive(gate/launcher/name,Path(label)/profile/'gate'/launcher/(name+'.gz'))
    for profile in ['full','ci']:
        observer=run/(profile+'-health-observer')
        if observer.exists():
            for source in sorted(observer.rglob('*')):
                if not source.is_file():continue
                relative=source.relative_to(observer)
                if any(part.startswith('private-') for part in relative.parts):continue
                if source.suffix not in {'.json','.jsonl','.log'}:continue
                archive(source,Path(label)/(profile+'-health-observer')/(str(relative)+'.gz'))
    for name in ['qualify','audit','observe','package','supervise','native-profile-observe','control-profile-observe','dcp-profile-observe','watch-audit','resume-observers','audit-attempt-1']:
        archive(Path('/tmp/story49-build-20261029-'+name+'.py'),Path(label)/'tools'/(name+'.py.gz'))
    manifest=dict(status=result['status'],nativeRoot=str(run),scope='Local full followed by actual CI entry point; no fresh hosted Actions or production acceptance',parentAudit=audit,files=files)
    output=PACKET/(label+'-manifest.json')
    assert not output.exists()
    output.write_bytes((json.dumps(manifest,indent=2)+'\n').replace('\n','\r\n').encode())
    print(json.dumps(dict(status=manifest['status'],files=len(files),storedBytes=sum((PACKET/f['path']).stat().st_size for f in files))))
if __name__=='__main__':main(Path(sys.argv[1]),sys.argv[2] if len(sys.argv)>2 else 'qualification')
