"""Resume only observer lifecycle after daemon restart; never restart canonical tests."""
import datetime,hashlib,json,os,time
from pathlib import Path
ROOT=Path('/tmp/story49-build-20261029-oe7n1gwt')
QUALIFIER=2961832
NAMES={'/tmp/story49-build-20261029-native-profile-observe.py','/tmp/story49-build-20261029-control-profile-observe.py','/tmp/story49-build-20261029-dcp-profile-observe.py'}
def stat(pid):return (Path('/proc')/str(pid)/'stat').read_text().rsplit(')',1)[1].split()[19]
def args(pid):return (Path('/proc')/str(pid)/'cmdline').read_bytes().decode().split('\0')
assert '/tmp/story49-build-20261029-qualify.py' in args(QUALIFIER)
owned_log=str(ROOT/'ci-driver.log')
assert any(os.readlink(fd)==owned_log for fd in (Path('/proc')/str(QUALIFIER)/'fd').iterdir()),'Qualifier lacks this exact run log'
observers=[]
for p in Path('/proc').iterdir():
 if not p.name.isdecimal():continue
 try:
  command=args(p.name);matches=NAMES.intersection(command)
  if matches and any(x==str(ROOT) or x.startswith(str(ROOT)+'/') for x in command):observers.append({'pid':int(p.name),'startTicks':stat(p.name),'script':next(iter(matches))})
 except (OSError,UnicodeError):pass
record={'at':datetime.datetime.now(datetime.UTC).isoformat(),'reason':'daemon restart removed original observer supervisor and audit watcher; canonical qualifier remained active','qualifierPid':QUALIFIER,'qualifierStartTicks':stat(QUALIFIER),'exactOwnedOpenLog':owned_log,'observers':observers,'canonicalTestsRestarted':False}
(ROOT/'daemon-resume.json').write_text(json.dumps(record,indent=2)+'\n')
while not (ROOT/'result.json').exists():time.sleep(3)
result=json.loads((ROOT/'result.json').read_text())
(ROOT/'observer-stop.json').write_text(json.dumps({'scope':'observer lifecycle only; not gate acceptance','resumedAfterDaemonRestart':True,'canonicalStatus':result['status']})+'\n')
deadline=time.monotonic()+45
for observer in observers:
 while time.monotonic()<deadline:
  try:present=stat(observer['pid'])==observer['startTicks'] and observer['script'] in args(observer['pid'])
  except OSError:present=False
  if not present:break
  time.sleep(.5)
 observer['exited']=not present
(ROOT/'supervisor-result.json').write_text(json.dumps({'status':'observer lifecycle resumed after daemon restart','canonicalStatus':result['status'],'canonicalTestsRestarted':False,'observers':observers},indent=2)+'\n')
print(json.dumps({'canonicalStatus':result['status'],'observedHelpersExited':all(x['exited'] for x in observers)}),flush=True)
