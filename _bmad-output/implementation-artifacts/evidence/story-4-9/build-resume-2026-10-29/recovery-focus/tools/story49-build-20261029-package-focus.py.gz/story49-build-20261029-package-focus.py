import collections,gzip,hashlib,json,xml.etree.ElementTree as ET
from pathlib import Path
ROOT=Path('/tmp/story49-recovery-focus-20261029-3in7s8es')
PACKET=Path('/home/administrator/projects/hexalith/works/_bmad-output/implementation-artifacts/evidence/story-4-9/build-resume-2026-10-29')
def sha(b):return hashlib.sha256(b).hexdigest()
r=json.loads((ROOT/'result.json').read_text()); tests=list(ET.parse(ROOT/'result.xml').getroot().iter('test'))
assert r['exitCode']==0 and r['runtimeUnchangedAfter'] and len(tests)==1 and tests[0].get('result')=='Pass'
control=[json.loads(l) for l in (ROOT/'control-observations.jsonl').read_text().splitlines()]
dcp=[json.loads(l) for l in (ROOT/'dcp-observer/snapshots.jsonl').read_text().splitlines()]
summary={'status':'passed focused recovery only; no complete qualification credit','facts':1,'runtimeFilesUnchanged':r['runtimeFiles'],'persistedPhases':len((ROOT/'persisted-states.jsonl').read_text().splitlines()),'hostStarts':len((ROOT/'host-starts.jsonl').read_text().splitlines()),'observedPlatformSentryContainers':len({c['id'] for s in control for c in s['containers']}),'dcpApis':len((ROOT/'dcp-observer/admitted-apis.jsonl').read_text().splitlines()),'controlSamples':len(control),'dcpSamples':len(dcp),'publishedHealthResults':dict(collections.Counter(str(p['result']) for s in control for c in s['containers'] for p in c['publishedHealth'])),'observerScope':'Exact selected Platform config mount; retained-host config is outside that observer admission. Bridge IP probes did not connect and do not prove internal HTTP state. IPv6 proxy refusal alone is not a defect. No recorded outcome diagnoses the previous failed startup.','mutations':0,'helperContainers':0,'containerExecCalls':0,'files':[]}
for source in [*sorted(ROOT.rglob('*')),*map(Path,['/tmp/story49-build-20261029-recovery-diagnostic.py','/tmp/story49-build-20261029-control-observe.py','/tmp/story49-build-20261029-dcp-observe.py','/tmp/story49-build-20261029-package-focus.py'])]:
 if not source.is_file():continue
 if source.is_relative_to(ROOT):
  rel=source.relative_to(ROOT)
  if any(p.startswith('private-') for p in rel.parts):continue
  if rel.parts[0]=='isolated-daprd' and str(rel) not in {'isolated-daprd/binding.json','isolated-daprd/launches.jsonl'}:continue
  assert source.suffix in {'.json','.jsonl','.log','.xml'},source
 else:rel=Path('tools')/source.name
 raw=source.read_bytes(); target=PACKET/'recovery-focus'/(str(rel)+'.gz');target.parent.mkdir(parents=True,exist_ok=True);encoded=gzip.compress(raw,mtime=0)
 if target.exists():assert target.read_bytes()==encoded, 'Existing recorded evidence differs: '+str(target)
 else:target.write_bytes(encoded)
 summary['files'].append({'path':str(target.relative_to(PACKET)),'sha256':sha(encoded),'nativePath':str(source),'nativeSha256':sha(raw),'nativeBytes':len(raw)})
p=PACKET/'recovery-focus-manifest.json';assert not p.exists();p.write_bytes((json.dumps(summary,indent=2)+'\n').replace('\n','\r\n').encode())
print(json.dumps({k:v for k,v in summary.items() if k!='files'}));print('files',len(summary['files']))
