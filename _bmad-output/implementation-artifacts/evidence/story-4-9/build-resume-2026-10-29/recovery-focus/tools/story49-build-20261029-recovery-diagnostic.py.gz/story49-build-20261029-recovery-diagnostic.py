"""Unchanged-binary failed recovery focus with exact config-bound control-plane health observations."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import tempfile
import time
import urllib.error
import urllib.request

SOURCE = Path('/tmp/story49-build-20261029-k7nz0gq6/full')
KEYS = {'DAPR_HTTP_ENDPOINT', 'DAPR_GRPC_ENDPOINT', 'DAPR_HTTP_PORT', 'DAPR_GRPC_PORT', 'ASPNETCORE_URLS'}
FLAGS = {'--app-id', '--app-port', '--dapr-http-port', '--dapr-grpc-port', '--config'}

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def processes():
    result = {}
    for path in Path('/proc').iterdir():
        if not path.name.isdecimal():
            continue
        try:
            fields = (path / 'stat').read_text().rsplit(')', 1)[1].split()
            result[int(path.name)] = (int(fields[1]), fields[19], fields[0])
        except (OSError, ValueError, IndexError):
            pass
    return result

def read_probe(port, suffix):
    try:
        with urllib.request.urlopen('http://127.0.0.1:' + str(port) + suffix, timeout=0.5) as response:
            return {'status': response.status}
    except urllib.error.HTTPError as error:
        return {'status': error.code}
    except Exception as error:
        return {'exception': type(error).__name__}

def main():
    ledger = json.loads((SOURCE / 'gate/ledger.json').read_text())
    bootstrap = json.loads((SOURCE / 'bootstrap.json').read_text())
    platform = Path(bootstrap['platformRoot'])
    baseline = ledger['runtimeArtifacts'] | ledger['consumer']['artifacts']
    if any(sha(path) != digest for path, digest in baseline.items()):
        raise RuntimeError('Original runtime/consumer bytes changed before diagnostic')
    root = Path(tempfile.mkdtemp(prefix='story49-recovery-focus-20261029-'))
    spec = importlib.util.spec_from_file_location('isolated_daprd', platform / 'eng/isolated_daprd.py')
    shim = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(shim)
    binding = shim.prepare(root / 'isolated-daprd', ledger['isolatedRuntime']['runtime'], ledger['controlPlanePorts']['sentry'])
    command = next(row['command'] for row in ledger['commands'] if row['name'] == 'platform-recovery').copy()
    command[command.index('-result-xml') + 1] = str(root / 'result.xml')
    command += ['-method', 'Hexalith.Works.IntegrationTests.WorksSdkRecoveryPipelineSmokeTests.SdkRemindersAndCascadeConvergeThroughPersistedReceiptsAcrossRestart']
    environment = os.environ.copy()
    for name, path in bootstrap['rootDependencies'].items():
        key = {'Hexalith.Builds': 'HexalithBuildsRoot', 'Hexalith.Commons': 'HexalithCommonsRoot', 'Hexalith.Parties': 'HexalithPartiesRoot', 'Hexalith.Tenants': 'HexalithTenantsRoot', 'Hexalith.PolymorphicSerializations': 'HexalithPolymorphicSerializationsRoot'}.get(name)
        if key:
            environment[key] = path
    environment.update(ledger['runtimeEnvironment'])
    environment.update({'DOTNET_USE_POLLING_FILE_WATCHER': '1',
        'WORKS_PLATFORM_DAPRD_RUNTIME_PATH': str(root / 'isolated-daprd'),
        'WORKS_PLATFORM_HOST_EVIDENCE': str(root / 'host-starts.jsonl'),
        'WORKS_SDK_PROOF_EVIDENCE_PATH': str(root / 'persisted-states.jsonl')})
    environment.pop('GITHUB_TOKEN', None)
    environment.pop('GH_TOKEN', None)
    record = {'scope': 'single unchanged-binary failed recovery diagnostic; no complete qualification credit', 'source': str(SOURCE), 'command': command, 'runtimeFiles': len(baseline), 'binding': binding}
    (root / 'invocation.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({'focusRoot': str(root)}), flush=True)
    observer = subprocess.Popen(['python3', '/tmp/story49-build-20261029-control-observe.py', str(root), str(platform)])
    with (root / 'test.log').open('w') as log:
        record['exitCode'] = subprocess.run(command, cwd=platform, env=environment, stdout=log, stderr=subprocess.STDOUT).returncode
    record['runtimeUnchangedAfter'] = all(sha(path) == digest for path, digest in baseline.items())
    if (root / 'host-starts.jsonl').exists():
        starts = [json.loads(line) for line in (root / 'host-starts.jsonl').read_text().splitlines() if line]
        record['launcherBinding'] = shim.verify(root / 'isolated-daprd', binding, starts)
    (root / 'result.json').write_text(json.dumps(record, indent=2) + '\n')
    observer.wait(timeout=15)
    print(json.dumps({'focusRoot': str(root), 'exitCode': record['exitCode'], 'runtimeUnchangedAfter': record['runtimeUnchangedAfter']}), flush=True)
    return record['exitCode']

if __name__ == '__main__':
    raise SystemExit(main())
