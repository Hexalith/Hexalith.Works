from pathlib import Path
import hashlib,json,re,shutil,subprocess
ROOT=Path('/home/administrator/projects/hexalith/works')
SPEC=ROOT/'_bmad-output/implementation-artifacts/spec-4-9-migrate-works-hosting-to-the-platform-boundary.md'
BASE=re.search(rb"^baseline_commit: '([^']+)'",SPEC.read_bytes(),re.M).group(1).decode()
DIFF=Path('/tmp/story49-resume-baseline-x4ifze2s.diff')
REVIEWED=Path('/tmp/story49-resume-baseline-reviewed-input.diff')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
if DIFF.exists() and sha(DIFF)=='8f5869fb261df7e1afcc7c817a419a2ddbc5154f8d771160a915ab0a747ac468':
 if REVIEWED.exists():assert sha(REVIEWED)==sha(DIFF)
 else:shutil.copyfile(DIFF,REVIEWED)
err=Path('/tmp/story49-build-20261029-final-diff.stderr.log')
with DIFF.open('wb') as stream,err.open('wb') as errors:
 subprocess.run(['git','diff','--binary','--no-ext-diff','--submodule=short',BASE,'--'],cwd=ROOT,stdout=stream,stderr=errors,check=True)
 files=subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=ROOT).split(b'\0')
 untracked=[p.decode() for p in files if p]
 for path in untracked:
  result=subprocess.run(['git','diff','--no-index','--binary','--no-ext-diff','--','/dev/null',path],cwd=ROOT,stdout=stream,stderr=errors)
  if result.returncode not in (0,1):raise RuntimeError('Untracked diff failed: '+path)
meta={'baselineCommit':BASE,'diff':str(DIFF),'bytes':DIFF.stat().st_size,'sha256':sha(DIFF),'untrackedFilesIncluded':len(untracked),'reviewedInput':str(REVIEWED),'reviewedInputSha256':sha(REVIEWED),'stderrBytes':err.stat().st_size}
Path('/tmp/story49-build-20261029-final-diff.json').write_text(json.dumps(meta,indent=2)+'\n')
for owner,output,paths in [(ROOT/'references/Hexalith.Platform','platform-current.diff',[]),(ROOT,'works-docs-current.diff',['docs/sdk-projection-query-adoption.md','docs/sdk-reminder-process-adoption.md'])]:
 with Path('/tmp/story49-build-20261029-'+output).open('wb') as f:subprocess.run(['git','diff','--binary','--no-ext-diff','HEAD','--',*paths],cwd=owner,stdout=f,check=True)
print(json.dumps(meta))
