"""Seal bounded final evidence and validate preserved story/owner bytes."""
import gzip,hashlib,json,re,subprocess
from pathlib import Path
ROOT=Path('/home/administrator/projects/hexalith/works')
PACKET=ROOT/'_bmad-output/implementation-artifacts/evidence/story-4-9/build-resume-2026-10-29'
RUN=Path('/tmp/story49-build-20261029-oe7n1gwt')
def sha(raw):return hashlib.sha256(raw).hexdigest()
def require(condition,message):
 if not condition:raise ValueError(message)
audit=json.loads((RUN/'parent-audit.json').read_text());require(audit['status']=='passed','Parent audit')
require(json.loads((RUN/'post-commit-content-equivalence.json').read_text())['status']=='passed','Post-commit content')
spec=ROOT/'_bmad-output/implementation-artifacts/spec-4-9-migrate-works-hosting-to-the-platform-boundary.md';raw=spec.read_bytes()
require(re.search(rb"^status: 'done'$",raw,re.M) is not None or re.search(rb"^status: 'done'\r$",raw,re.M) is not None,'Spec status')
require(b"baseline_commit: '18e94d388ab0abd8be363b361d0b2fee762359e7'" in raw,'Original baseline')
require(not re.search(rb'^- \[ \]',raw,re.M),'Unchecked execution task')
start=raw.index(b'<frozen-after-approval');end=raw.index(b'</frozen-after-approval>')+len(b'</frozen-after-approval>');frozen=sha(raw[start:end]);require(frozen=='de1c74eee26581eab23b760d595d93951471cad0074b3b57eb45a35058f7ef5d','Frozen intent')
require(len(re.findall(rb'^\| R29[RS]-[BEV]\d+:',raw,re.M))==26,'Individual finding rows')
sprint=ROOT/'_bmad-output/implementation-artifacts/sprint-status.yaml';require(b'  4-9-migrate-works-hosting-to-the-platform-boundary: review' in sprint.read_bytes(),'Sprint review status')
ledger=ROOT/'_bmad-output/implementation-artifacts/deferred-work.md';old=subprocess.check_output(['git','show','72b528b5e0aa6f43456cd67915f5f2b157a12f83:'+str(ledger.relative_to(ROOT))],cwd=ROOT);new=ledger.read_bytes();require(new.startswith(old),'Original deferred ledger bytes');require(new[len(old):].count(b'- source_spec:')==10,'Ten appended follow-ups')
archive_hashes={}
for name,expected in [('manifest.json','b8cbf1bb6490b6fc6bb8ad7aa12842c202fb95a9877afd7a0a5fa1caf79caca8'),('works-source.tar.gz','5ce3247ded7ab59ff70d5b25896fed1826b8d78b0728a2d1a4c1f2dceb7ae696')]:
 actual=sha((ROOT/'references/Hexalith.Platform/eng/retained-works-host'/name).read_bytes());require(actual==expected,'Retained '+name);archive_hashes[name]=actual
existing=set();manifest_hashes={}
for manifest in sorted(PACKET.glob('*-manifest.json')):
 data=json.loads(manifest.read_text());manifest_hashes[manifest.name]=sha(manifest.read_bytes())
 for row in data['files']:
  path=PACKET/row['path'];encoded=path.read_bytes();native=gzip.decompress(encoded);require(sha(encoded)==row['sha256'] and sha(native)==row['nativeSha256'] and len(native)==row['nativeBytes'],'Archive hash '+row['path']);require(row['path'] not in existing,'Duplicate evidence member');existing.add(row['path'])
require(existing=={str(p.relative_to(PACKET)) for p in PACKET.rglob('*.gz')},'Unmanifested evidence archive')
require(not list(PACKET.rglob('*.cs')),'Unexpected raw C# evidence')
for owner,name,command in [(ROOT,'works',['git','-c','core.whitespace=cr-at-eol','diff','--check']),(ROOT/'references/Hexalith.Platform','platform',['git','-c','core.whitespace=cr-at-eol','show','--format=','--check','HEAD'])]:
 with Path('/tmp/story49-build-20261029-'+name+'-final-diff-check.log').open('wb') as log:subprocess.run(command,cwd=owner,stdout=log,stderr=subprocess.STDOUT,check=True)
files=[]
def archive(source,relative):
 encoded=gzip.compress(source.read_bytes(),mtime=0);target=PACKET/'completion'/relative;require(not target.exists(),'Existing completion member');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(encoded)
 files.append({'path':str(target.relative_to(PACKET)),'sha256':sha(encoded),'nativePath':str(source),'nativeSha256':sha(source.read_bytes()),'nativeBytes':source.stat().st_size})
names=['complete-notes.py','capture-diff.py','platform-final.diff','works-docs-final.diff','platform-commit-message.txt','pointer-commit-message.txt','works-commit-message.txt','platform-commitlint.log','pointer-commitlint.log','works-commitlint.log','platform-final-diff-check.log','works-final-diff-check.log','platform-commit.log','pointer-commit.log','platform-commit.json','pointer-commit.json','diff-before-present.json','content-equivalence.py','completion.py']
for name in names:archive(Path('/tmp/story49-build-20261029-'+name),Path(name+'.gz'))
archive(RUN/'post-commit-content-equivalence.json',Path('post-commit-content-equivalence.json.gz'))
current=[spec,sprint,ledger,ROOT/'docs/sdk-projection-query-adoption.md',ROOT/'docs/sdk-reminder-process-adoption.md',PACKET/'README.md']
platform_commit=json.loads(Path('/tmp/story49-build-20261029-platform-commit.json').read_text());current += [ROOT/'references/Hexalith.Platform'/p for p in platform_commit['files']]
report={'status':'Verified final evidence prepared for the local Works commit','specStatus':'done','sprintStatus':'review','qualification':'full-and-actual-CI-passed','parentAudit':'passed','directXmlFacts':{'full':659,'ci':512},'rowsPerProfile':11,'proofsPerProfile':44,'phasesPerProfile':33,'startsPerProfile':11,'runtimeArtifactsPerProfile':441,'individualFindingRows':26,'newDeferredEntries':10,'frozenIntentSha256':frozen,'retainedArchiveHashes':archive_hashes,'existingArchiveMembersVerified':len(existing),'boundManifests':manifest_hashes,'platformCommit':platform_commit['commit'],'parentPointerCommit':json.loads(Path('/tmp/story49-build-20261029-pointer-commit.json').read_text())['commit'],'finalWorksCommit':'Created after this manifest; see Git history','currentFileHashes':{str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in current},'files':files}
output=PACKET/'completion-manifest.json';require(not output.exists(),'Existing completion manifest');output.write_bytes((json.dumps(report,indent=2)+'\n').replace('\n','\r\n').encode())
print(json.dumps({'status':report['status'],'existingArchiveMembersVerified':len(existing),'completionMembers':len(files),'allReviewRows':26,'newDefers':10,'spec':'done','sprint':'review'}))
