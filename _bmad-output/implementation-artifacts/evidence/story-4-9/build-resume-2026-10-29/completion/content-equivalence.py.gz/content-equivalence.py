"""Check committed content against qualified overlays; this is not a new gate run."""
import copy,hashlib,importlib.util,json,subprocess,sys,tempfile
from pathlib import Path
WORKS=Path('/home/administrator/projects/hexalith/works')
RUN=Path('/tmp/story49-build-20261029-oe7n1gwt')
ledger=json.loads((RUN/'full/gate/ledger.json').read_text());bootstrap=json.loads((RUN/'full/bootstrap.json').read_text())
platform=Path(bootstrap['platformRoot']);origin=WORKS/'references/Hexalith.Platform'
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def head(path):return subprocess.check_output(['git','rev-parse','HEAD'],cwd=path,text=True).strip()
def require(condition,message):
 if not condition:raise ValueError(message)
report={'scope':'Content equivalence after local commits; canonical results remain bound to their recorded revisions and overlays, not a new execution','status':'incomplete','qualifiedWorksCommit':ledger['worksConsumerSource']['commit'],'qualifiedPlatformCommit':bootstrap['platformCommit'],'currentWorksCommitBeforeFinalEvidenceCommit':head(WORKS),'currentPlatformCommit':head(origin),'checks':{}}
try:
 with tempfile.TemporaryDirectory(prefix='story49-post-commit-content-') as directory:
  private=Path(directory);source=platform/'eng/verify_works_host.py';require(sha(source)==ledger['verifierSha256'],'Qualified verifier source drift')
  (private/source.name).write_bytes(source.read_bytes())
  for name,digest in ledger['verifierHelpers'].items():
   p=platform/'eng'/name;require(sha(p)==digest,'Qualified helper drift: '+name);target=private/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(p.read_bytes())
  sys.path.insert(0,str(private));spec=importlib.util.spec_from_file_location('verify_works_host',private/source.name);verifier=importlib.util.module_from_spec(spec);spec.loader.exec_module(verifier)
  require(verifier.works_host_snapshot.origin_files(origin)==bootstrap['platformSourceFiles'],'Current committed Platform files differ from qualified overlay')
  report['checks']['platformSourceFiles']=len(bootstrap['platformSourceFiles'])
  for name,previous,current in [('worksConsumer',ledger['worksConsumerSource'],verifier.source_snapshot(WORKS)),('worksCanonical',ledger['canonicalSources']['Works'],verifier.canonical_source_snapshot(WORKS))]:
   a,b=copy.deepcopy(previous),copy.deepcopy(current);a.pop('commit');b.pop('commit');require(a==b,name+' content/membership drift beyond Git revision')
   report['checks'][name]={'sourceFiles':len(current['sourceFiles']),'contentAndMembership':'equal; only commit provenance changed'}
  current_linked=verifier.linked_fixture_snapshot(WORKS,platform);previous=ledger['linkedFixtureSources']
  require({k:v for k,v in current_linked.items() if k!='commits'}=={k:v for k,v in previous.items() if k!='commits'},'Linked source content/membership changed')
  report['linkedCommitProvenance']={'qualified':previous['commits'],'current':current_linked['commits']}
  report['checks']['linkedSourceFiles']=len(current_linked['sourceFiles'])
  for producer in ledger['sourceProducers'].values():
   actual=verifier.require_unchanged_runtime_source(producer) if producer['commit'] is None else verifier.source_snapshot(producer['root'],producer=True)
   require(actual==producer,'SDK producer/build inputs changed')
  report['checks']['sdkProducerAndImportedBuildsInputs']='unchanged'
  verifier.require_unchanged_fixture_sources(WORKS,ledger['fixtureSources']);report['checks']['fixtureSources']=len(ledger['fixtureSources'])
  for path,digest in ledger['runtimeArtifacts'].items():require(sha(path)==digest,'Runtime artifact changed: '+path)
  require(verifier.consumer_artifacts(ledger['consumer']['root'])==ledger['consumer']['artifacts'],'Consumer artifacts changed')
  verifier.retained_works_host.verify(ledger['retainedHostSource'])
  report['checks']['runtimeConsumerAndRetainedArchive']='unchanged'
 report['status']='passed'
except Exception as error:
 report['status']='failed';report['error']=str(error);raise
finally:
 (RUN/'post-commit-content-equivalence.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps(report))
