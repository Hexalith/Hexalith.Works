using System.Text.Json;
using Hexalith.EventStore.Client.Projections;
using var dapr = new Dapr.Client.DaprClientBuilder().UseGrpcEndpoint("http://localhost:50110").Build();
var store=new DaprReadModelStore(dapr);
foreach (bool expiring in new[]{false,true})
{
 string key="candidate-receipt-"+Guid.NewGuid();
 var writes=await Task.WhenAll(Enumerable.Range(0,20).Select(async i=> expiring
 ? await store.TrySaveWithTimeToLiveAsync("statestore",key,new Dictionary<string,int>{{"value",42}},string.Empty,TimeSpan.FromMinutes(1))
 : await store.TrySaveAsync("statestore",key,new Dictionary<string,int>{{"value",42}},string.Empty)));
 if(writes.Count(x=>x)!=1)throw new Exception("Create-only race failed.");
 var current=await store.GetAsync<Dictionary<string,int>>("statestore",key);
 if(current.Value!["value"]!=42)throw new Exception("Original receipt changed.");
 if(!await store.TrySaveAsync("statestore",key,new Dictionary<string,int>{{"value",99}},current.ETag!))throw new Exception("Nonempty update failed.");
 if(await store.TrySaveAsync("statestore",key,new Dictionary<string,int>{{"value",999}},current.ETag!))throw new Exception("Stale update accepted.");
 Console.WriteLine(JsonSerializer.Serialize(new{expiring,created=writes.Count(x=>x),conflicts=writes.Count(x=>!x),updated=true,staleRejected=true}));
}
