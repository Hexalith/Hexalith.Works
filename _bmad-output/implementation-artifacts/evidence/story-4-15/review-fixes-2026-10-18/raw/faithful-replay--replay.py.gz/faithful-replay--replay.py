import json,subprocess
from pathlib import Path
p=Path('/tmp/story415-20261018-snapshot-replay')
name='works-story415-closeout-probe'
owned=json.loads(subprocess.check_output(['docker','inspect',name,'--format','{{json .Config.Labels}}']))
assert owned['hexalith.works.sdk-fixture']==name
results=[]
for which in ['original','fixed']:
 subprocess.run(['docker','exec',name,'redis-cli','FLUSHDB'],check=True,stdout=subprocess.PIPE)
 subprocess.run(['docker','exec','-i',name,'redis-cli','--pipe'],input=(p/'restore.resp').read_bytes(),check=True,stdout=subprocess.PIPE)
 with (p/which/'probe.log').open('w') as f:r=subprocess.run(['dotnet',str(p/which/'bin/Release/net10.0/Replay.dll'),which],stdout=f,stderr=subprocess.STDOUT)
 results.append(dict(profile=which,exit=r.returncode,result=json.loads((p/which/'probe.log').read_text().splitlines()[-1])))
 assert r.returncode==0
(p/'results.json').write_text(json.dumps(results,indent=2))
