import subprocess,json,time,hashlib,re
from pathlib import Path
out=Path('/tmp/story415-20261018-runtime-bindings.jsonl')
end=time.monotonic()+1200
seen=set()
while time.monotonic()<end:
 try:
  r=subprocess.run(['aspire','describe','--apphost','/home/administrator/projects/hexalith/works/src/Hexalith.Works.AppHost/Hexalith.Works.AppHost.csproj','--format','Json'],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,text=True,timeout=10)
  if r.returncode==0:
   for v in json.loads(r.stdout)['resources']:
    if v['displayName'] not in ['works','eventstore']:continue
    pid=v.get('properties',{}).get('executable.pid')
    if not pid or (v['displayName'],pid) in seen:continue
    paths=set();pending=[pid];visited=[]
    while pending and len(visited)<32:
     current=pending.pop(0);visited.append(current)
     base=Path('/proc')/str(current)
     children=base/'task'/str(current)/'children'
     if children.exists():pending += [int(v) for v in children.read_text().split()]
     m=base/'maps'
     if not m.exists():continue
     for line in m.read_text().splitlines():
      if '/Hexalith.EventStore.' in line and '.dll' in line:paths.add(line.split(None,5)[-1])
    if not paths:continue
    rows=[]
    for name in sorted(paths):
     f=Path(name)
     if f.exists():rows.append(dict(path=name,sha256=hashlib.sha256(f.read_bytes()).hexdigest()))
    with out.open('a') as f:f.write(json.dumps(dict(time=time.time(),resource=v['displayName'],pid=pid,assemblies=rows))+'\n')
    seen.add((v['displayName'],pid))
 except Exception:pass
 time.sleep(10)
