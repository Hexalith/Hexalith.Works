import subprocess,json,hashlib,time
from pathlib import Path
root=Path('/home/administrator/projects/hexalith/works')
producer=root/'references/Hexalith.EventStore'
feed=root/'.artifacts/story-4-15/feed';feed.mkdir(parents=True,exist_ok=True)
version='3.124.1-story415.20261018.1'
packages=['Contracts','Client','ServiceDefaults','DomainService','Server','Admin.Abstractions','Testing','Gateway','Aspire']
for name in packages:
 if (feed/f'Hexalith.EventStore.{name}.{version}.nupkg').exists():raise SystemExit('Immutable candidate already exists: '+name)
results=[]
for name in packages:
 cmd=['dotnet','pack',f'src/Hexalith.EventStore.{name}/Hexalith.EventStore.{name}.csproj','--configuration','Release','--output',str(feed),'-m:1','-p:Version='+version,'-p:PackageVersion='+version,'-p:HexalithEventStoreVersion='+version,'-p:UseHexalithProjectReferences=false','-p:UseNuGetDeps=true']
 log=Path('/tmp')/('story415-20261018-pack-'+name+'.log');t=time.time()
 with log.open('w') as f:r=subprocess.run(cmd,cwd=producer,stdout=f,stderr=subprocess.STDOUT)
 results.append(dict(command=cmd,cwd=str(producer),exit=r.returncode,seconds=time.time()-t,log=str(log)))
 Path('/tmp/story415-20261018-pack-results.json').write_text(json.dumps(results,indent=2))
 if r.returncode:raise SystemExit(r.returncode)
archives={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in feed.glob('*.'+version+'.nupkg')}
Path('/tmp/story415-20261018-pack-archives.json').write_text(json.dumps(archives,indent=2))
