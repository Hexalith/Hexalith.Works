#!/usr/bin/env python3
"""Read-only snapshots from one exact, ownership-checked synthetic Story 4.15 Redis."""
import argparse,base64,datetime,hashlib,json,re,subprocess,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--container',required=True);p.add_argument('--out',required=True);p.add_argument('--seconds',type=float,default=900);p.add_argument('--interval',type=float,default=5)
a=p.parse_args()
def run(args):
 return subprocess.check_output(args,text=True,timeout=5)
if not re.fullmatch(r'works-sdk415-[0-9a-f]{32}',a.container):raise SystemExit('Expected exact synthetic fixture name')
identity=json.loads(run(['docker','inspect',a.container,'--format','{{json .}}']))
if identity['Config']['Labels'].get('hexalith.works.sdk-fixture')!=a.container:raise SystemExit('Fixture ownership label mismatch')
container_id=identity['Id'];out=Path(a.out);out.parent.mkdir(parents=True,exist_ok=True)
patterns=['works||eventstore:process:v1:*','works||eventstore:reminders:v1:*','works||shared-*','works||hxrmb:v1:*','works||story415:*','eventstore||projection*','eventstore||AggregateActor||sdk415-*:work:work-sdk415-*']
lua='''local seen={} local names={} local function add(k) if not seen[k] then seen[k]=true names[#names+1]=k end end for _,pattern in ipairs(cjson.decode(ARGV[1])) do local cursor="0" local scans=0 repeat local page=redis.call("SCAN",cursor,"MATCH",pattern,"COUNT",1000) cursor=page[1] for _,k in ipairs(page[2]) do add(k) end scans=scans+1 if scans>256 or #names>8192 then return redis.error_reply("observer-snapshot-limit") end until cursor=="0" end for _,k in ipairs(cjson.decode(ARGV[2])) do add(k) end table.sort(names) local rows={} for _,k in ipairs(names) do local t=redis.call("TYPE",k).ok local fields={} if t=="hash" then fields=redis.call("HGETALL",k) elseif t=="string" then fields={"value",redis.call("GET",k)} end rows[#rows+1]={k,t,redis.call("PTTL",k),fields} end return rows'''
def sha(s):return hashlib.sha256(s.encode()).hexdigest().upper()
def b64(b):return base64.urlsafe_b64encode(b).decode().rstrip('=')
def prop(o,name,default=None):
 return next((v for k,v in o.items() if k.lower()==name.lower()),default) if isinstance(o,dict) else default
index='works||shared-control-index:'+sha('works-runtime-v3-tenants')
expected={'works||eventstore:process:v1:control:sweep','works||eventstore:process:v1:control:tenants:0','works||eventstore:process:v1:control:tenants:tail','works||eventstore:reminders:v1:WorksSdkReminderActor:control:tenants',index}
tenants=set();known=set();start=time.monotonic()
def emit(d):
 with out.open('a') as f:f.write(json.dumps(d,separators=(',',':'))+'\n')
def visible(rows,k):
 row=rows.get(k);raw=None if row is None else row['fields'].get('data',row['fields'].get('value'))
 if raw is None:return None,'absent'
 try:value=json.loads(raw)
 except (ValueError,TypeError):return None,'non-json'
 if isinstance(value,dict) and '$hxrmb' in value:
  marker=rows.get('works||hxrmb:v1:marker:'+value.get('scope',''));mraw=None if marker is None else marker['fields'].get('data')
  try:m=json.loads(mraw) if mraw else None
  except ValueError:m=None
  committed=isinstance(m,dict) and m.get('fp')==value.get('fp') and m.get('st') in [1,4]
  selected=value.get('cand') if committed and not value.get('del',False) else None if committed else value.get('prev')
  if selected is None:return None,'committed-delete' if committed else 'previous-absent'
  try:return json.loads(base64.b64decode(selected)),'candidate' if committed else 'previous'
  except (ValueError,TypeError):return None,'invalid-selected-json'
 return value,'raw'
emit({'kind':'observer-start','time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'container':a.container,'container_id':container_id,'created':identity['Created'],'patterns':patterns,'mode':'EVAL_RO SCAN TYPE PTTL HGETALL GET; diagnostic decoding only; no domain/provider calls'})
while time.monotonic()-start<a.seconds:
 stamp=datetime.datetime.now(datetime.timezone.utc).isoformat()
 try:
  raw=run(['docker','exec',container_id,'redis-cli','--json','EVAL_RO',lua,'0',json.dumps(patterns),json.dumps(sorted(expected))]);snap=json.loads(raw)
  if not isinstance(snap,list):raise ValueError('Expected Redis snapshot rows')
  rows={k:{'key':k,'type':t,'pttl':ttl,'fields':dict(zip(fields[::2],fields[1::2]))} for k,t,ttl,fields in snap}
  for k in rows:
   m=re.search(r'\|\|AggregateActor\|\|(sdk415-[0-9a-f]{10}):work:',k)
   if m:tenants.add(m.group(1))
  summaries=[]
  for tenant in sorted(tenants):
   suffix=tenant[len('sdk415-'):];enc=b64(tenant.encode());prefix='works||eventstore:process:v1:tenant:'+enc
   shared=b64(hashlib.sha256(''.join(str(len(x))+':'+x for x in ['statestore',tenant,'work','works-runtime-v3','works-runtime-v3','shared-epoch']).encode()).digest())
   epoch='works||shared-epoch:'+shared;ev,evmode=visible(rows,epoch);gen=prop(ev,'ActiveGeneration',0);queue='works||shared-generation:'+shared+':'+str(gen)+':'+sha('works-runtime-v3:queue');qv,qmode=visible(rows,queue);membership=prop(qv,'Value',{})
   expected.update([epoch,queue,prefix+':candidates:0',prefix+':candidates:tail',prefix+':published','works||shared-control-index-tombstone:'+sha('works-runtime-v3-tenants')+':'+sha(tenant),'works||eventstore:reminders:v1:WorksSdkReminderActor:tenant:'+tenant+':candidates'])
   source_summary=[]
   aggregates=['work-sdk415-'+kind+'-'+suffix for kind in ['rescheduled','expiry','date','parent','child','await-parent','completed-child']]+['work-sdk415-child-'+suffix+'-'+str(i) for i in range(1,5)]
   for agg in aggregates:
    key=prefix+':source:'+sha(tenant+'\0work\0'+agg);marker=key+':candidate';expected.update([key,marker]);v,mode=visible(rows,key);mv,mmode=visible(rows,marker)
    source_summary.append({'aggregate':agg,'source_key':key,'visibility':mode,'state':v,'candidate_key':marker,'candidate_visibility':mmode,'candidate':mv})
   summaries.append({'tenant':tenant,'epoch_key':epoch,'epoch_visibility':evmode,'phase':prop(ev,'Phase'),'active_generation':gen,'journal':prop(ev,'Journal'),'parking':prop(ev,'ParkingEvidence'),'conflicts':prop(ev,'DeliveryConflicts'),'offboarding_audit':prop(ev,'OffboardingAuditId'),'queue_key':queue,'queue_visibility':qmode,'kind':prop(qv,'Kind'),'membership':prop(membership,'MemberWorkItemIds'),'last_sequences':prop(membership,'LastSequences'),'sources':source_summary})
  # Newly derived expectations missing from the atomic snapshot are explicitly marked unobserved,
  # never asserted absent; the next EVAL_RO includes them even when physically absent.
  for summary in summaries:
   for source in summary['sources']:
    for field,visibility in [('source_key','visibility'),('candidate_key','candidate_visibility')]:
     if source[field] not in rows:source[visibility]='not-yet-observed'
  sw,swmode=visible(rows,'works||eventstore:process:v1:control:sweep');iv,imode=visible(rows,index)
  deleted=sorted(known-rows.keys());known=set(rows)
  emit({'kind':'snapshot','time':stamp,'container':a.container,'container_id':container_id,'raw_sha256':hashlib.sha256(raw.encode()).hexdigest(),'rows':list(rows.values()),'no_longer_returned':deleted,'sweep_visibility':swmode,'sweep':sw,'control_index_visibility':imode,'control_index':iv,'families':summaries})
 except (subprocess.SubprocessError,ValueError,KeyError,TypeError) as e:
  emit({'kind':'observer-error','time':stamp,'container':a.container,'error':str(e)[:1500]})
 time.sleep(min(a.interval,max(0,a.seconds-(time.monotonic()-start))))
emit({'kind':'observer-end','time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'container_id':container_id})
