using System.Text.Json.Nodes;
using Hexalith.EventStore.Client.Projections;
using var dapr=new Dapr.Client.DaprClientBuilder().UseGrpcEndpoint("http://localhost:50110").Build();
var store=new DaprReadModelStore(dapr);
var scope=new SharedProjectionScope("statestore","sdk415-65eced8a2c","work","works-runtime-v3",["works-runtime-v3-writer"]);
var coordinator=new SharedProjectionEpochCoordinator(store,store);
var before=await store.GetAsync<JsonObject>("statestore","shared-epoch:"+scope.ComputeHash());
string beforeHead=before.Value!["journal"]![0]!["sourceStream"]!.GetValue<string>();
string receiptKey="shared-receipt:"+scope.ComputeHash()+":0:93EC9C729D96A737775B7D0B48668B94DE19A3FC0A81B16238BDA1CBC9518B1F";
var (receiptBefore,_) = await dapr.GetByteStateAndETagAsync("statestore",receiptKey);
int pendingBefore=(await coordinator.GetStatusAsync(scope)).PendingDeliveryCount;
string outcome="";
try {await coordinator.CatchUpAsync(scope,(delivery,_,_)=>throw new Exception("next-parent-fold:"+delivery.SourceStream));}
catch(Exception e){outcome=e.GetType().Name+":"+e.Message;Console.WriteLine(e);}
var after=await store.GetAsync<JsonObject>("statestore","shared-epoch:"+scope.ComputeHash());
string afterHead=after.Value!["journal"]![0]!["sourceStream"]!.GetValue<string>();
var (receiptAfter,_) = await dapr.GetByteStateAndETagAsync("statestore",receiptKey);
if(!receiptBefore.Span.SequenceEqual(receiptAfter.Span))throw new Exception("Receipt was changed.");
var checkpoint=await coordinator.GetCheckpointAsync(scope,beforeHead);
if(checkpoint?.Position!=11 || checkpoint.OwnerSequenceNumber!=5)throw new Exception("Checkpoint changed.");
int pendingAfter=(await coordinator.GetStatusAsync(scope)).PendingDeliveryCount;
Console.WriteLine(System.Text.Json.JsonSerializer.Serialize(new{beforeHead,afterHead,outcome,pendingBefore,pendingAfter,checkpoint,
 receiptSha256=Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(receiptAfter.Span))}));
if(args[0]=="fixed" ? !afterHead.Contains("parent") : beforeHead!=afterHead || !outcome.StartsWith("DaprException"))throw new Exception("Unexpected replay outcome.");
