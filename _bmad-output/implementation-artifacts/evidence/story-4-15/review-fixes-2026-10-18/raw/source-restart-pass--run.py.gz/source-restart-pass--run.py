import os,subprocess,json,time
from pathlib import Path
root=Path('/home/administrator/projects/hexalith/works')
out=Path('/tmp/story415-20261018-fixed-live-1')
original=Path('/proc/sys/fs/inotify/max_user_watches').read_text().strip()
cmd=['dotnet',str(root/'tests/Hexalith.Works.IntegrationTests/bin/Debug/net10.0/Hexalith.Works.IntegrationTests.dll'),'-method','*SdkRemindersAndCascadeConvergeThroughPersistedReceiptsAcrossRestart','-longRunning','45','-result-xml',str(out/'restart.xml')]
env=dict(os.environ,WORKS_APPHOST_TEST_STARTUP_TIMEOUT_SECONDS='180',WORKS_SDK_PROOF_DAPR_CONFIG_DIRECTORY='/tmp/story415-20261018-live/dapr-configs',WORKS_SDK_PROOF_EVIDENCE_PATH=str(out/'runtime.jsonl'))
t=time.time()
try:
 subprocess.run(['sudo','-n','sysctl','-w','fs.inotify.max_user_watches=2097152'],check=True,stdout=subprocess.PIPE)
 with (out/'restart.log').open('w') as f: result=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 (out/'result.json').write_text(json.dumps(dict(command=cmd,exit=result.returncode,elapsed=time.time()-t,originalWatchLimit=original),indent=2))
finally:
 subprocess.run(['sudo','-n','sysctl','-w','fs.inotify.max_user_watches='+original],check=True,stdout=subprocess.PIPE)
