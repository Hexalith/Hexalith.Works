from pathlib import Path
import json,shutil,subprocess,tempfile
root=Path('/home/administrator/projects/hexalith/works')
packet=root/'_bmad-output/implementation-artifacts/evidence/story-4-15/review-fixes-2026-10-18/post-review-patch-requalification'
checks=[]
with tempfile.TemporaryDirectory(prefix='story415-portable-') as temp:
 copy=Path(temp)/'packet';shutil.copytree(packet,copy)
 def run(name,want):
  p=subprocess.run(['python3',str(copy/'verify.py')],cwd=temp,capture_output=True,text=True)
  if (p.returncode==0)!=want: raise ValueError(name+' outcome wrong: '+p.stdout+p.stderr)
  checks.append({'name':name,'command':['python3',str(copy/'verify.py')],'exitCode':p.returncode,'expected':'pass' if want else 'reject','output':p.stdout if want else p.stderr.splitlines()[-1]})
 run('portable-outside-repository',True)
 report=(copy/'report.json').read_bytes()
 r=json.loads(report)
 r['commands'][3]['tests']['passed']=886
 (copy/'report.json').write_text(json.dumps(r))
 run('reject-XML-count-mismatch',False)
 (copy/'report.json').write_bytes(report)
 r=json.loads(report);r['matrix'][0]['cases'][0]='missing-test-case'
 (copy/'report.json').write_text(json.dumps(r))
 run('reject-missing-matrix-case',False)
 (copy/'report.json').write_bytes(report)
 r=json.loads(report);r['archiveTag']['pushPending']=False
 (copy/'report.json').write_text(json.dumps(r))
 run('reject-unperformed-push-claim',False)
 (copy/'report.json').write_bytes(report)
 f=copy/'raw/debug-integration.xml.gz';b=f.read_bytes();f.write_bytes(b[:-1]+bytes([b[-1]^1]))
 run('reject-altered-raw-archive',False)
Path('/tmp/story415-requalification-51am5Z/verification-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps(checks,indent=2))
