import hashlib,json,os,subprocess,threading,time
from pathlib import Path
import xml.etree.ElementTree as ET
ROOT=Path('/home/administrator/projects/hexalith/works')
OUT=Path(__file__).resolve().parent
APPHOST=ROOT/'src/Hexalith.Works.AppHost/Hexalith.Works.AppHost.csproj'
PROJECT='tests/Hexalith.Works.IntegrationTests/Hexalith.Works.IntegrationTests.csproj'
VERSION='3.124.1-story415.20261018.1'
RESULTS=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def binding_snapshot(label, stop):
    records={}
    while not stop.is_set():
        try:
            r=subprocess.run(['aspire','describe','--apphost',str(APPHOST),'--format','Json'],cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,text=True,timeout=10)
            if r.returncode==0:
                for item in json.loads(r.stdout)['resources']:
                    resource=item.get('displayName')
                    if resource not in ['works','eventstore']:continue
                    pid=item.get('properties',{}).get('executable.pid')
                    if not pid:continue
                    pending=[int(pid)]; visited=set(); paths=set()
                    while pending and len(visited)<32:
                        current=pending.pop(0)
                        if current in visited:continue
                        visited.add(current); base=Path('/proc')/str(current)
                        children=base/'task'/str(current)/'children'
                        if children.exists():pending.extend(int(v) for v in children.read_text().split())
                        maps=base/'maps'
                        if maps.exists():
                            for line in maps.read_text().splitlines():
                                if '/Hexalith.EventStore.' in line and '.dll' in line:paths.add(line.split(None,5)[-1])
                    if not paths:continue
                    key=(resource,int(pid)); previous=records.get(key,{'stage':label,'resource':resource,'pid':int(pid),'assemblies':{}})
                    for value in paths:
                        f=Path(value)
                        if f.exists():previous['assemblies'][value]=sha(f)
                    records[key]=previous
                    (OUT/(label+'-bindings.json')).write_text(json.dumps(list(records.values()),indent=2))
        except Exception:pass
        stop.wait(8)
def run(label, cmd, env=None, xml=None, live=False):
    print('START '+label,flush=True); started=time.time(); stop=threading.Event(); watcher=None
    if live:
        watcher=threading.Thread(target=binding_snapshot,args=(label,stop),daemon=True); watcher.start()
    try:
        with (OUT/(label+'.log')).open('w') as f:r=subprocess.run(cmd,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT)
    finally:
        stop.set()
        if watcher:watcher.join(15)
    result={'label':label,'command':cmd,'exit':r.returncode,'seconds':round(time.time()-started,3),'log':label+'.log'}
    if xml and Path(xml).exists():
        a=ET.parse(xml).getroot().find('assembly'); result['tests']={k:a.get(k) for k in ['total','passed','failed','errors','skipped','not-run','time']}; result['xml']=Path(xml).name
    RESULTS.append(result); (OUT/'results.json').write_text(json.dumps(RESULTS,indent=2)); print(json.dumps(result),flush=True)
    if xml and 'tests' in result:assert all(int(result['tests'].get(k,'0'))==0 for k in ['failed','errors','skipped','not-run']),result
    if r.returncode:raise RuntimeError(label+' exited '+str(r.returncode))
def tests(config,label,live_method=None):
    xml=OUT/(label+'.xml'); assembly=ROOT/f'tests/Hexalith.Works.IntegrationTests/bin/{config}/net10.0/Hexalith.Works.IntegrationTests.dll'
    cmd=['dotnet',str(assembly)]
    if live_method:
        cmd+=['-method','*'+live_method,'-longRunning','45']
        env=dict(os.environ,WORKS_APPHOST_TEST_STARTUP_TIMEOUT_SECONDS='180',WORKS_SDK_PROOF_DAPR_CONFIG_DIRECTORY='/tmp/story415-20261018-live/dapr-configs',WORKS_SDK_PROOF_EVIDENCE_PATH=str(OUT/(label+'-runtime.jsonl')))
        binaries={str(f.relative_to(ROOT)):sha(f) for folder in [assembly.parent,ROOT/f'src/Hexalith.Works/bin/{config}/net10.0'] for f in folder.glob('Hexalith*.dll')}
        (OUT/(label+'-binaries.json')).write_text(json.dumps(binaries,indent=2))
    else:cmd+=['-class-','*SmokeTests','-class-','*Platform*']; env=None
    cmd+=['-result-xml',str(xml)]; run(label,cmd,env,xml,live=bool(live_method))
original=Path('/proc/sys/fs/inotify/max_user_watches').read_text().strip()
(OUT/'source-bindings-before.json').write_text(json.dumps({str(f.relative_to(ROOT)):sha(f) for f in [ROOT/'src/Hexalith.Works/Recovery/WorksRecoveryEventDecoder.cs',ROOT/'tests/Hexalith.Works.IntegrationTests/WorksSdkIteration4Tests.cs',ROOT/'tests/Hexalith.Works.IntegrationTests/WorksSdkIntentTranslationTests.cs']},indent=2))
try:
    run('debug-build',['dotnet','build',PROJECT,'--configuration','Debug','-m:1'])
    tests('Debug','debug-integration')
    subprocess.run(['sudo','-n','sysctl','-w','fs.inotify.max_user_watches=2097152'],check=True,stdout=subprocess.PIPE)
    tests('Debug','debug-restart','SdkRemindersAndCascadeConvergeThroughPersistedReceiptsAcrossRestart')
    tests('Debug','debug-callback','SuccessfulCallbacksRegisterSdkReminderAndProcessWithoutPeriodicRecovery')
    run('candidate-build',['dotnet','build',PROJECT,'--configuration','Release','-m:1','-p:HexalithEventStoreVersion='+VERSION,'-p:RestoreAdditionalProjectSources='+str(ROOT/'.artifacts/story-4-15/feed')])
    tests('Release','candidate-integration')
    tests('Release','candidate-restart','SdkRemindersAndCascadeConvergeThroughPersistedReceiptsAcrossRestart')
    for name in ['UnitTests','ArchitectureTests','PropertyTests']:
        xml=OUT/(name+'.xml'); run(name,['dotnet',str(ROOT/f'tests/Hexalith.Works.{name}/bin/Debug/net10.0/Hexalith.Works.{name}.dll'),'-result-xml',str(xml)],xml=xml)
finally:
    subprocess.run(['sudo','-n','sysctl','-w','fs.inotify.max_user_watches='+original],check=True,stdout=subprocess.PIPE)
    cleanup={'watchLimit':Path('/proc/sys/fs/inotify/max_user_watches').read_text().strip(),'aspirePs':subprocess.run(['aspire','ps','--format','Json'],cwd=ROOT,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE).stdout,'runningContainers':subprocess.check_output(['docker','ps','--format','{{.Names}}'],text=True).splitlines()}
    (OUT/'cleanup.json').write_text(json.dumps(cleanup,indent=2))
