from pathlib import Path
import ast,base64,gzip,hashlib,json,subprocess,zipfile
import xml.etree.ElementTree as ET
from datetime import datetime
ROOT=Path('/home/administrator/projects/hexalith/works')
OUT=Path(__file__).resolve().parent
BASE=ROOT/'_bmad-output/implementation-artifacts/evidence/story-4-15/review-fixes-2026-10-18'
FINAL=BASE/'root-closeout'
results=json.loads((OUT/'results.json').read_text())
assert len(results)==10 and all(x['exit']==0 for x in results)
assert all(all(int(x['tests'][k])==0 for k in ['failed','errors','skipped','not-run']) for x in results if 'tests' in x)
for name in ['debug-integration','candidate-integration']:
    assert next(x for x in results if x['label']==name)['tests']['passed']=='848'
# Reuse the reviewed semantic assertions without executing its historical-data main body.
tree=ast.parse((BASE/'verify-evidence.py').read_text())
nodes=[x for x in tree.body if isinstance(x,(ast.Import,ast.ImportFrom,ast.FunctionDef)) or isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='EXPECTED_PHASES' for t in x.targets)]
ns={};exec(compile(ast.Module(body=nodes,type_ignores=[]),'<reviewed semantic assertions>','exec'),ns)
for label in ['debug-restart','candidate-restart']:
    ns['verify_restart']([json.loads(x) for x in (OUT/(label+'-runtime.jsonl')).read_text().splitlines()])
callback=json.loads((OUT/'debug-callback-runtime.jsonl').read_text().splitlines()[0])['state']
assert callback['processCandidate'] and len(callback['witness']['entries'])==1 and callback['witness']['entries'][0]['status']=='Armed'
prod=json.loads((BASE/'producers.json').read_text())
archive_sha={Path(name).name:sha for item in prod['archives'] for name,sha in item['assemblies'].items()}
for item in prod['archives']:
    f=ROOT/item['path'];assert hashlib.sha256(f.read_bytes()).hexdigest()==item['sha256']
    with zipfile.ZipFile(f) as z:
        for name,sha in item['assemblies'].items():assert hashlib.sha256(z.read(name)).hexdigest()==sha
bindings=json.loads((OUT/'candidate-restart-bindings.json').read_text())
assert len(bindings)==8
assert sum(x['resource']=='works' for x in bindings)==4 and sum(x['resource']=='eventstore' for x in bindings)==4
client_sha=archive_sha['Hexalith.EventStore.Client.dll']; packaged=0
for host in bindings:
    assert next(sha for name,sha in host['assemblies'].items() if Path(name).name=='Hexalith.EventStore.Client.dll')==client_sha
    if host['resource']=='works':
        assert len(host['assemblies'])==5
        for name,sha in host['assemblies'].items():assert archive_sha[Path(name).name]==sha;packaged+=1
assert packaged==20
source_before=json.loads((OUT/'source-bindings-before.json').read_text())
for name,sha in source_before.items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==sha,name
sources=dict(prod['sourceSha256']);sources.update(source_before)
for name in sources:
    digest=hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
    if name not in source_before:assert digest==sources[name],name
    sources[name]=digest
assert len(sources)==16
cleanup=json.loads((OUT/'cleanup.json').read_text()); assert cleanup['watchLimit']=='1048576' and json.loads(cleanup['aspirePs'])==[]
assert not any('story415' in name or name.startswith('works-') for name in cleanup['runningContainers'])
old_matrix=json.loads((ROOT/'_bmad-output/implementation-artifacts/evidence/story-4-15/post-review-verification-2026-10-17/matrix.json').read_text())
matrix=[]
for mode,file in [('debug','debug-integration.xml'),('release','candidate-integration.xml')]:
    names={x.get('name').replace('\\',''):x.get('result') for x in ET.parse(OUT/file).getroot().iter('test')}
    for row in old_matrix:
        cases=row['executed'][mode]['passing_test_cases']
        assert all(names.get(x.replace('\\',''))=='Pass' for x in cases)
        matrix.append({'mode':mode,'scenario':row['scenario'],'passingCases':len(cases),'cases':cases})
FINAL.mkdir(exist_ok=True); (FINAL/'raw').mkdir(exist_ok=True)
manifest=[]
def retain(name,value):
    compressed=gzip.compress(value,mtime=0); target=FINAL/'raw'/(name+'.gz');target.write_bytes(compressed)
    manifest.append({'path':'raw/'+target.name,'bytes':len(value),'sha256':hashlib.sha256(value).hexdigest(),'compressedSha256':hashlib.sha256(compressed).hexdigest()})
for f in sorted(OUT.iterdir()):
    if f.is_file() and f.suffix in ['.json','.jsonl','.xml','.log','.py']:retain(f.name,f.read_bytes())
for i,(name,sha) in enumerate(sorted(sources.items())):retain('source-'+str(i)+'-'+Path(name).name,(ROOT/name).read_bytes())
(FINAL/'raw-artifacts.json').write_text(json.dumps(manifest,indent=2)+'\n')
report={'worksHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'sdkHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT/'references/Hexalith.EventStore',text=True).strip(),'candidate':prod['candidate'],'published':False,'defaultRelease':prod['defaultRelease'],'defaultReleaseContainsCorrection':False,'results':results,'sourceSha256':sources,'sourceSnapshots':16,'persistedRestartPhases':20,'packagedHostDllChecks':20,'candidateHostStarts':8,'matrixObservations':sum(x['passingCases'] for x in matrix),'matrix':matrix,'cleanup':cleanup}
(FINAL/'report.json').write_text(json.dumps(report,indent=2)+'\n')
(FINAL/'verify-final.py').write_bytes((OUT/'verify-final.py').read_bytes())
print(json.dumps({k:v for k,v in report.items() if k not in ['results','sourceSha256','matrix','cleanup']},indent=2))
