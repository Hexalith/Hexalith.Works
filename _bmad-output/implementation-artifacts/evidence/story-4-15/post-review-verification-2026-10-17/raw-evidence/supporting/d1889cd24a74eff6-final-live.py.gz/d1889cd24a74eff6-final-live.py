from pathlib import Path
import os,sys,json,subprocess,time,hashlib,signal,xml.etree.ElementTree as ET
root=Path('/home/administrator/projects/hexalith/works');out=Path(__file__).parent
setting=Path('/proc/sys/fs/inotify/max_user_watches');original=int(setting.read_text());temporary=max(original,2097152)
state={'setting':'fs.inotify.max_user_watches','original':original,'temporary':temporary,'persistent_configuration_changed':False,'existing_applications_stopped':False}
records=json.loads((out/'results-manifest.json').read_text());failed=False
signal.signal(signal.SIGTERM,lambda signum,frame: (_ for _ in ()).throw(KeyboardInterrupt()))
try:
    r=subprocess.run(['sudo','-n','sysctl','-w',f'fs.inotify.max_user_watches={temporary}'],capture_output=True,text=True)
    state['set_exit_code']=r.returncode;state['set_output']=r.stdout+r.stderr;assert r.returncode==0,state['set_output']
    (out/'watch-limit-adjustment-final.json').write_text(json.dumps(state,indent=2)+'\n')
    common={'DOTNET_USE_POLLING_FILE_WATCHER':'1','WORKS_APPHOST_TEST_STARTUP_TIMEOUT_SECONDS':'180','WORKS_SDK_PROOF_DAPR_CONFIG_DIRECTORY':str(out/'dapr-configs')}
    gates=[('final-restart',['*SdkRemindersAndCascadeConvergeThroughPersistedReceiptsAcrossRestart'],'live-restart-state.jsonl',1),('final-callback-helpers',['*SuccessfulCallbacksRegisterSdkReminderAndProcessWithoutPeriodicRecovery','*RetryStorePreservesCoordinatedBatchCapability','*RetainedPlanWaitBoundsNonCooperativeStoreAcquisition'],'live-callback-state.jsonl',3)]
    for name,methods,evidence,expected in gates:
        xml=out/(name+'.xml');log=out/(name+'.log');assert not xml.exists()
        command=['dotnet','tests/Hexalith.Works.IntegrationTests/bin/Debug/net10.0/Hexalith.Works.IntegrationTests.dll']
        for method in methods:command+=['-method',method]
        command+=['-longRunning','45','-result-xml',str(xml)]
        environment={**common,'WORKS_SDK_PROOF_EVIDENCE_PATH':str(out/evidence)}
        print(json.dumps({'gate':name,'status':'running'}),flush=True);started=time.monotonic()
        with log.open('w') as stream:r=subprocess.run(command,cwd=root,env={**os.environ,**environment},stdout=stream,stderr=subprocess.STDOUT)
        row={'gate':name,'command':command,'environment_overrides':environment,'exit_code':r.returncode,'seconds':round(time.monotonic()-started,3),'log':str(log),'sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
        if xml.exists():
            tree=ET.parse(xml);tests=tree.findall('.//test');row.update({'xml':str(xml),'xml_sha256':hashlib.sha256(xml.read_bytes()).hexdigest(),'total':len(tests),'passed':sum(t.attrib.get('result')=='Pass' for t in tests),'failed':sum(t.attrib.get('result')=='Fail' for t in tests),'skipped':sum(t.attrib.get('result')=='Skip' for t in tests),'errors':sum(int(a.attrib.get('errors',0)) for a in tree.findall('.//assembly'))})
        records.append(row);(out/'results-manifest.json').write_text(json.dumps(records,indent=2)+'\n')
        print(json.dumps({k:v for k,v in row.items() if k in ['gate','exit_code','seconds','total','passed','failed','skipped','errors']}),flush=True)
        if row['exit_code'] or row.get('total')!=expected or row.get('failed') or row.get('skipped') or row.get('errors'):failed=True;break
finally:
    current=int(setting.read_text());state['observed_before_restore']=current
    if current==temporary:
        r=subprocess.run(['sudo','-n','sysctl','-w',f'fs.inotify.max_user_watches={original}'],capture_output=True,text=True);state['restore_exit_code']=r.returncode;state['restore_output']=r.stdout+r.stderr
    else:state['external_change_preserved']=True
    state['final']=int(setting.read_text());(out/'watch-limit-adjustment-final.json').write_text(json.dumps(state,indent=2)+'\n')
    print(json.dumps({'watch_limit_final':state['final'],'original':original}),flush=True)
before=json.loads((out/'source-bindings-before.json').read_text());after={k:hashlib.sha256((root/k).read_bytes()).hexdigest() for k in before}
(out/'source-bindings-after.json').write_text(json.dumps(after,indent=2)+'\n');assert before==after,'Source/build inputs changed.'
assert state['final']==original,'Watch limit not restored.'
if failed:sys.exit(1)
print(json.dumps({'status':'complete','source_bindings':len(after)}),flush=True)
