from pathlib import Path
import os,sys,json,subprocess,time,hashlib,signal,xml.etree.ElementTree as ET
root=Path('/home/administrator/projects/hexalith/works');out=Path(__file__).parent
setting=Path('/proc/sys/fs/inotify/max_user_watches');original=int(setting.read_text());temporary=max(original,2097152)
env_record={'setting':'fs.inotify.max_user_watches','original':original,'temporary':temporary,'persistent_configuration_changed':False,'existing_applications_stopped':False}
records=json.loads((out/'results-manifest.json').read_text())
record=None

def interrupt(signum,frame):raise KeyboardInterrupt()
signal.signal(signal.SIGTERM,interrupt)
try:
    changed=subprocess.run(['sudo','-n','sysctl','-w',f'fs.inotify.max_user_watches={temporary}'],capture_output=True,text=True)
    env_record['set_exit_code']=changed.returncode;env_record['set_output']=changed.stdout+changed.stderr
    assert changed.returncode==0,env_record['set_output']
    (out/'watch-limit-adjustment.json').write_text(json.dumps(env_record,indent=2)+'\n')
    environment={'DOTNET_USE_POLLING_FILE_WATCHER':'1','WORKS_APPHOST_TEST_STARTUP_TIMEOUT_SECONDS':'180','WORKS_SDK_PROOF_DAPR_CONFIG_DIRECTORY':str(out/'dapr-configs'),'WORKS_SDK_PROOF_EVIDENCE_PATH':str(out/'live-retry-state.jsonl')}
    xml=out/'live-sdk-retry.xml';log=out/'live-sdk-retry.log'
    command=['dotnet','tests/Hexalith.Works.IntegrationTests/bin/Debug/net10.0/Hexalith.Works.IntegrationTests.dll','-class','*WorksSdkRecoveryPipelineSmokeTests','-longRunning','45','-result-xml',str(xml)]
    print(json.dumps({'gate':'live-sdk-retry','status':'running','temporary_watch_limit':temporary}),flush=True)
    started=time.monotonic()
    with log.open('w') as stream:r=subprocess.run(command,cwd=root,env={**os.environ,**environment},stdout=stream,stderr=subprocess.STDOUT)
    record={'gate':'live-sdk-retry','command':command,'environment_overrides':environment,'exit_code':r.returncode,'seconds':round(time.monotonic()-started,3),'log':str(log),'sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
    if xml.exists():
        tree=ET.parse(xml);tests=tree.findall('.//test');record.update({'xml':str(xml),'xml_sha256':hashlib.sha256(xml.read_bytes()).hexdigest(),'total':len(tests),'passed':sum(t.attrib.get('result')=='Pass' for t in tests),'failed':sum(t.attrib.get('result')=='Fail' for t in tests),'skipped':sum(t.attrib.get('result')=='Skip' for t in tests),'errors':sum(int(a.attrib.get('errors',0)) for a in tree.findall('.//assembly'))})
    records.append(record);(out/'results-manifest.json').write_text(json.dumps(records,indent=2)+'\n')
finally:
    current=int(setting.read_text());env_record['observed_before_restore']=current
    if current==temporary:
        restored=subprocess.run(['sudo','-n','sysctl','-w',f'fs.inotify.max_user_watches={original}'],capture_output=True,text=True)
        env_record['restore_exit_code']=restored.returncode;env_record['restore_output']=restored.stdout+restored.stderr
    else:env_record['external_change_preserved']=True
    env_record['final']=int(setting.read_text())
    (out/'watch-limit-adjustment.json').write_text(json.dumps(env_record,indent=2)+'\n')
    print(json.dumps({'watch_limit_final':env_record['final'],'original':original}),flush=True)
if record:
    print(json.dumps({k:v for k,v in record.items() if k in ['gate','exit_code','seconds','total','passed','failed','skipped','errors']}),flush=True)
    before=json.loads((out/'source-bindings-before.json').read_text());after={k:hashlib.sha256((root/k).read_bytes()).hexdigest() for k in before}
    (out/'source-bindings-after.json').write_text(json.dumps(after,indent=2)+'\n');assert before==after,'Source/build inputs changed during final verification.'
    assert record['exit_code']==0 and record.get('total')==4 and not record.get('failed') and not record.get('skipped') and not record.get('errors'),str(out/'live-sdk-retry.log')
    assert env_record['final']==original,'Watch limit was not restored.'
    print(json.dumps({'status':'complete','source_bindings':len(after),'directory':str(out)}),flush=True)
