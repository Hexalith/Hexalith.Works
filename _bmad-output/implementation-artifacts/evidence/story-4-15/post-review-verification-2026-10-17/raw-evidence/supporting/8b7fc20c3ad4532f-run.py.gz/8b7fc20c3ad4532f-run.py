from pathlib import Path
import os,sys,json,hashlib,subprocess,time,shutil,xml.etree.ElementTree as ET
root=Path('/home/administrator/projects/hexalith/works')
out=Path(__file__).parent
records=[]
def bindings():
    files=[]
    for directory in [root/'src',root/'tests',root/'references/Hexalith.EventStore/src']:
        for path in directory.rglob('*'):
            if path.is_file() and path.suffix in ('.cs','.csproj','.props','.targets','.json','.yaml','.yml') and not {'bin','obj','.aspire'}.intersection(path.relative_to(directory).parts): files.append(path)
    files.extend(root/name for name in ['Directory.Build.props','Directory.Build.targets','Directory.Packages.props','Directory.Solution.props','Directory.Solution.targets','global.json','.editorconfig'])
    return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
before=bindings()
(out/'source-bindings-before.json').write_text(json.dumps(before,indent=2)+'\n')
def gate(name,command,minimum=None,environment=None):
    log=out/(name+'.log'); xml=out/(name+'.xml')
    args=list(command)
    if minimum is not None: args+=['-result-xml',str(xml)]
    started=time.monotonic()
    print(json.dumps({'gate':name,'status':'running'}),flush=True)
    with log.open('w') as stream:
        result=subprocess.run(args,cwd=root,env={**os.environ,**(environment or {})},stdout=stream,stderr=subprocess.STDOUT)
    record={'gate':name,'command':args,'environment_overrides':environment or {},'exit_code':result.returncode,'seconds':round(time.monotonic()-started,3),'log':str(log),'sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
    if minimum is not None and xml.exists():
        assemblies=ET.parse(xml).findall('.//assembly'); tests=ET.parse(xml).findall('.//test')
        record['xml']=str(xml);record['xml_sha256']=hashlib.sha256(xml.read_bytes()).hexdigest()
        record['total']=len(tests);record['passed']=sum(t.attrib.get('result')=='Pass' for t in tests)
        record['failed']=sum(t.attrib.get('result')=='Fail' for t in tests);record['skipped']=sum(t.attrib.get('result')=='Skip' for t in tests)
        record['errors']=sum(int(a.attrib.get('errors',0)) for a in assemblies)
    records.append(record);(out/'results-manifest.json').write_text(json.dumps(records,indent=2)+'\n')
    print(json.dumps({k:v for k,v in record.items() if k in ['gate','exit_code','seconds','total','passed','failed','skipped','errors']}),flush=True)
    if result.returncode or (minimum is not None and (record.get('total',0)<minimum or record.get('failed',0) or record.get('skipped',0) or record.get('errors',0))):
        print('FAILED: '+str(log),flush=True);sys.exit(1)
project='tests/Hexalith.Works.IntegrationTests/Hexalith.Works.IntegrationTests.csproj'
for mode in ['Debug','Release']:
    gate(mode.lower()+'-build',['dotnet','build',project,'--configuration',mode,'-m:1','-p:NuGetAudit=false','-p:MinVerVersionOverride=1.0.0'])
    gate(mode.lower()+'-integration',['dotnet',f'tests/Hexalith.Works.IntegrationTests/bin/{mode}/net10.0/Hexalith.Works.IntegrationTests.dll','-class-','*SmokeTests'],889)
for name,minimum in [('UnitTests',589),('ArchitectureTests',269),('PropertyTests',3)]:
    gate(name,['dotnet',f'tests/Hexalith.Works.{name}/bin/Debug/net10.0/Hexalith.Works.{name}.dll'],minimum)
configs=out/'dapr-configs';shutil.copytree('/tmp/story415-review-20261017/dapr-configs',configs)
environment={'DOTNET_USE_POLLING_FILE_WATCHER':'1','WORKS_APPHOST_TEST_STARTUP_TIMEOUT_SECONDS':'180','WORKS_SDK_PROOF_DAPR_CONFIG_DIRECTORY':str(configs),'WORKS_SDK_PROOF_EVIDENCE_PATH':str(out/'live-state.jsonl')}
gate('live-sdk',['dotnet','tests/Hexalith.Works.IntegrationTests/bin/Debug/net10.0/Hexalith.Works.IntegrationTests.dll','-class','*WorksSdkRecoveryPipelineSmokeTests','-longRunning','45'],4,environment)
after=bindings();(out/'source-bindings-after.json').write_text(json.dumps(after,indent=2)+'\n')
assert before==after,'Source/build inputs changed during final verification.'
print(json.dumps({'status':'complete','source_bindings':len(after),'directory':str(out)}),flush=True)
